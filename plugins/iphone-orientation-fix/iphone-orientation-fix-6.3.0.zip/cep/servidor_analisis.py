#!/usr/bin/env python3
"""
iPhone Orientation Fix - Servidor de Analisis v6.3.0

Cambios clave:
- Fallback de container rotation corregido: ya no termina en rotacion 0 accidentalmente.
- Segmentos con duracion corta/faltante se extienden hasta el siguiente cambio o clip_out.
- Segmentos adyacentes con la misma rotacion se fusionan para evitar cortes innecesarios.
"""

import os, sys, re, json, subprocess, argparse
from flask import Flask, request, jsonify

EXIFTOOL  = r'C:\Program Files\exiftool\exiftool.exe'
WIN_FLAGS = getattr(subprocess, 'CREATE_NO_WINDOW', 0)

# ── Puerto dinamico: depsoTOYS lo inyecta via DEPSO_PORT o --port ──
def _get_port():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--port', type=int, default=None)
    args, _ = parser.parse_known_args()
    if args.port:
        return args.port
    env_port = os.environ.get('DEPSO_PORT')
    if env_port:
        try:
            return int(env_port)
        except Exception:
            pass
    return 7788  # fallback historico

PORT = _get_port()

ORIENT_DEG = {
    'horizontal (normal)':           0,
    'rotate 90 cw':                 90,
    'rotate 180':                  180,
    'rotate 90 ccw':               270,
    'rotate 270 cw':               270,
    'vertical (top is right side)':  90,
    'vertical (top is left side)':  270,
}

app = Flask(__name__)

try:
    from flask_cors import CORS
    CORS(app)
except ImportError:
    @app.after_request
    def _add_cors_headers(response):
        response.headers['Access-Control-Allow-Origin']  = '*'
        response.headers['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS'
        response.headers['Access-Control-Allow-Headers'] = 'Content-Type'
        return response

# ── Utilidades ────────────────────────────────────────────────────────
def to_secs(s):
    s = (s or '').strip()
    if s.endswith(' s'):
        try: return float(s[:-2])
        except Exception: return 0.0
    if ':' in s:
        p = s.split(':')
        try:
            if len(p) == 2: return int(p[0]) * 60 + float(p[1])
            if len(p) == 3: return int(p[0]) * 3600 + int(p[1]) * 60 + float(p[2])
        except Exception:
            return 0.0
    try:
        return float(s)
    except Exception:
        return 0.0

def norm_deg(deg):
    """Normaliza a rango -180..180, conservando 180."""
    try:
        rot = float(deg)
    except Exception:
        rot = 0.0
    while rot > 180:
        rot -= 360
    while rot < -180:
        rot += 360
    # evitar -0.0
    if abs(rot) < 0.0001:
        rot = 0
    return int(rot) if abs(rot - int(rot)) < 0.0001 else round(rot, 3)

def parse_segs(output):
    """
    Parsea el output de ExifTool -ee -G3.

    Doc1, Doc2, Doc3 pueden aparecer consecutivos sin lineas vacias; por eso
    guardamos el grupo actual cuando cambia el numero DocN.
    """
    segs, cur = [], {}
    prev_doc_num = None

    def save_cur():
        if 'Video Orientation' in cur and 'Sample Time' in cur:
            segs.append({
                'start':       to_secs(cur.get('Sample Time', '0 s')),
                'duration':    to_secs(cur.get('Sample Duration', '0 s')),
                'orientation': cur.get('Video Orientation', '')
            })

    for line in (output or '').splitlines():
        line = line.strip()
        if not line:
            save_cur()
            cur = {}
            prev_doc_num = None
            continue
        m = re.match(r'\[Doc(\d+)\]\s+(.+?)\s*:\s*(.+)', line)
        if m:
            doc_num = int(m.group(1))
            field   = m.group(2).strip()
            value   = m.group(3).strip()
            if prev_doc_num is not None and doc_num != prev_doc_num:
                save_cur()
                cur = {}
            prev_doc_num = doc_num
            cur[field] = value
    save_cur()
    return segs

def get_container_rotation(file_path):
    try:
        r = subprocess.run(
            [EXIFTOOL, '-json', '-m', '-Rotation', '-Make', '-Model', file_path],
            capture_output=True, timeout=30, creationflags=WIN_FLAGS
        )
        meta = json.loads(r.stdout.decode('utf-8', 'replace'))[0]
        return int(float(meta.get('Rotation', 0) or 0)), meta.get('Model', '')
    except Exception as e:
        print(f'  [container_rot error] {e}')
        return 0, ''

def compute_rot(orientation, container_rot):
    key = (orientation or '').lower().strip()
    rs = next((d for k, d in ORIENT_DEG.items() if k in key), None)
    if rs is None:
        return 0
    return norm_deg(rs - container_rot)

def deg2orient(deg):
    d = int(((float(deg) % 360) + 360) % 360)
    if d == 0:   return 'Horizontal (normal)'
    if d == 90:  return 'Rotate 90 CW'
    if d == 180: return 'Rotate 180'
    return 'Rotate 90 CCW'

def prepare_raw_segments(raw_segs, clip_in, clip_out, container_rot):
    """
    Limpia segmentos de ExifTool y arregla casos mañosos:
    - duraciones de 1 frame / 0s se interpretan como eventos de cambio.
    - el ultimo segmento dura hasta clip_out.
    - si solo tenemos container rotation, creamos un segmento con rotacion explicita.
    """
    raw_segs = [dict(s) for s in (raw_segs or []) if s.get('orientation')]
    raw_segs.sort(key=lambda s: float(s.get('start', 0) or 0))

    fallback = False
    fallback_reason = ''

    # Caso tipico: no hay orientacion por sample; solo Rotation del contenedor.
    # El bug viejo hacia deg2orient(container_rot) y despues compute_rot(..., container_rot),
    # lo que daba 0. Aqui guardamos rotacion explicita para no restarla otra vez.
    if (not raw_segs) or (
        len(raw_segs) == 1
        and container_rot != 0
        and 'horizontal' in (raw_segs[0].get('orientation', '').lower())
    ):
        fallback = True
        fallback_reason = 'container_rotation'
        raw_segs = [{
            'start': clip_in,
            'duration': max(0.0, clip_out - clip_in),
            'orientation': deg2orient(container_rot),
            'explicit_rotation': norm_deg(container_rot)
        }]

    # Inferir duraciones faltantes/cortas usando el siguiente cambio.
    fixed = []
    for i, seg in enumerate(raw_segs):
        start = float(seg.get('start', 0) or 0)
        dur = float(seg.get('duration', 0) or 0)
        next_start = None
        if i + 1 < len(raw_segs):
            next_start = float(raw_segs[i + 1].get('start', 0) or 0)

        # Si ExifTool nos da duracion de frame/evento, extender hasta el siguiente cambio.
        if next_start is not None and next_start > start + 0.01:
            if dur <= 0.08 or start + dur < next_start - 0.05:
                dur = next_start - start
        elif dur <= 0.08:
            dur = max(0.0, clip_out - start)

        fixed.append({
            'start': start,
            'duration': dur,
            'orientation': seg.get('orientation', ''),
            'explicit_rotation': seg.get('explicit_rotation')
        })

    return fixed, fallback, fallback_reason

def build_timeline_segments(raw_segs, clip_in, clip_out, clip_start, container_rot):
    final = []
    for seg in raw_segs:
        ss = max(float(seg.get('start', 0) or 0), clip_in)
        se = min(float(seg.get('start', 0) or 0) + float(seg.get('duration', 0) or 0), clip_out)
        if ss >= se - 0.01:
            continue
        if seg.get('explicit_rotation') is not None:
            rot = norm_deg(seg.get('explicit_rotation'))
        else:
            rot = compute_rot(seg.get('orientation'), container_rot)
        final.append({
            'srcStart':      round(ss, 3),
            'srcEnd':        round(se, 3),
            'timelineStart': round(clip_start + (ss - clip_in), 3),
            'timelineEnd':   round(clip_start + (se - clip_in), 3),
            'orientation':   seg.get('orientation', ''),
            'rotation':      rot
        })

    # Fusionar segmentos contiguos con la misma rotacion para evitar cortes inutiles.
    merged = []
    for seg in final:
        if merged and merged[-1]['rotation'] == seg['rotation'] and abs(merged[-1]['timelineEnd'] - seg['timelineStart']) <= 0.05:
            merged[-1]['srcEnd'] = seg['srcEnd']
            merged[-1]['timelineEnd'] = seg['timelineEnd']
        else:
            merged.append(seg)
    return merged

# ── Rutas ─────────────────────────────────────────────────────────────
@app.route('/health')
def health():
    return jsonify({
        'status':   'ok',
        'service':  'iphone-orientation-fix',
        'version':  '6.3.0',
        'exiftool': os.path.isfile(EXIFTOOL),
        'port':     PORT
    })

@app.route('/analyze', methods=['POST'])
def analyze():
    data       = request.get_json() or {}
    file_path  = data.get('filePath', '')
    clip_in    = float(data.get('clipIn', 0) or 0)
    clip_out   = float(data.get('clipOut', 999999) or 999999)
    clip_start = float(data.get('clipStart', 0) or 0)

    print(f'\n{"="*52}')
    print(f'  Archivo : {os.path.basename(file_path)}')
    print(f'  Tamano  : {os.path.getsize(file_path)//1024//1024} MB' if os.path.isfile(file_path) else '')
    print(f'  Source  : {clip_in:.3f}s - {clip_out:.3f}s | TL start {clip_start:.3f}s')
    print(f'{"="*52}')

    if not os.path.isfile(file_path):
        return jsonify({'error': f'Archivo no encontrado: {file_path}'}), 400

    container_rot, model = get_container_rotation(file_path)
    print(f'  Container rotation : {container_rot} deg | {model}')

    print('  Ejecutando ExifTool -ee ...')
    try:
        r = subprocess.run(
            [EXIFTOOL, '-charset', 'UTF8', '-ee', '-G3', file_path],
            capture_output=True, timeout=240, creationflags=WIN_FLAGS
        )
        output    = r.stdout.decode('utf-8', 'replace')
        parsed    = parse_segs(output)
        doc_lines = sum(1 for l in output.splitlines() if re.match(r'\s*\[Doc\d+\]', l))
        print(f'  Output: {len(r.stdout):,} bytes | {doc_lines:,} lineas [DocN]')
    except Exception as e:
        print(f'  ExifTool error: {e}')
        parsed = []

    print(f'  Segmentos ExifTool: {len(parsed)}')
    for s in parsed[:12]:
        print(f'    {s["start"]:.3f}s + {s["duration"]:.3f}s | {s["orientation"]}')
    if len(parsed) > 12:
        print(f'    ... {len(parsed)-12} mas')

    raw_segs, fallback, fallback_reason = prepare_raw_segments(parsed, clip_in, clip_out, container_rot)
    final_segs = build_timeline_segments(raw_segs, clip_in, clip_out, clip_start, container_rot)

    # Segundo seguro: si todo quedo vacio y hay container rotation, devolver un segmento completo.
    if not final_segs and container_rot != 0:
        fallback = True
        fallback_reason = 'empty_final_container_rotation'
        final_segs = [{
            'srcStart': round(clip_in, 3),
            'srcEnd': round(clip_out, 3),
            'timelineStart': round(clip_start, 3),
            'timelineEnd': round(clip_start + (clip_out - clip_in), 3),
            'orientation': deg2orient(container_rot),
            'rotation': norm_deg(container_rot)
        }]

    print(f'  Fallback: {fallback} {fallback_reason}')
    print(f'\n  Segmentos timeline ({len(final_segs)}):')
    for s in final_segs:
        print(f'    tl={s["timelineStart"]:.3f}-{s["timelineEnd"]:.3f}s | {s["orientation"]} | rot={s["rotation"]}')

    return jsonify({
        'containerRotation': container_rot,
        'model':             model,
        'rawSegments':       len(parsed),
        'segments':          final_segs,
        'fallback':          fallback,
        'fallbackReason':    fallback_reason,
        'serverVersion':     '6.3.0'
    })

# ── Arrancar ──────────────────────────────────────────────────────────
if __name__ == '__main__':
    print(f'[autorotar] iniciando en :{PORT}', flush=True)
    print(f'[autorotar] exiftool: {"OK" if os.path.isfile(EXIFTOOL) else "NO ENCONTRADO en " + EXIFTOOL}', flush=True)

    if not os.path.isfile(EXIFTOOL):
        print('[autorotar] ERROR: ExifTool no encontrado. Instala desde https://exiftool.org', flush=True)
        sys.exit(1)

    app.run(host='127.0.0.1', port=PORT, debug=False, threaded=True)
