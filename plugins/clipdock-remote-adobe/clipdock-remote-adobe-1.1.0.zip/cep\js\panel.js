(function () {
  'use strict';

  var BRIDGE_PORTS = [];
  for (var bridgePort = 7788; bridgePort <= 7808; bridgePort++) BRIDGE_PORTS.push(bridgePort);
  var bridgeUrl = 'http://127.0.0.1:7788';
  var APP_NAME = 'ClipDock';
  var TARGET_BIN = 'ClipDock';
  var DEFAULT_EXE = 'C:\\Program Files\\ClipDock\\ClipDock.bat';
  var cs = new CSInterface();
  var env = {};
  try { env = cs.getHostEnvironment() || {}; } catch (_) { env = {}; }
  var appId = env.appId === 'AEFT' ? 'aftereffects' : 'premiere';
  var hostName = appId === 'aftereffects' ? 'After Effects' : 'Premiere Pro';
  var clientId = localStorage.getItem('clipdock.panelClientId');
  if (!clientId) {
    clientId = appId + '_' + Date.now() + '_' + Math.random().toString(16).slice(2);
    localStorage.setItem('clipdock.panelClientId', clientId);
  }
  var socket = null;
  var apiBase = '';
  var activeTarget = null;
  var activeClientId = null;
  var lastInfo = null;
  var lastJobId = null;
  var pollTimer = null;
  var importDeliveries = {};
  var bridgeConnecting = false;
  var recodePresets = [];
  var remoteSelection = [];
  var remoteAssets = [];
  var remoteAssetFilter = 'all';
  var hydratedApiBase = '';

  function $(id) { return document.getElementById(id); }

  function log(message) {
    var node = $('log-line');
    if (node) node.textContent = message;
  }

  function escapeHtml(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, function (character) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[character];
    });
  }

  function escapeForExtendScript(value) {
    return String(value || '').replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/'/g, "\\'");
  }

  function appPath() {
    return localStorage.getItem('clipdock.exePath') || DEFAULT_EXE;
  }

  function setAppPath(path) {
    if (path && path !== 'cancel' && path.indexOf('Error:') !== 0) localStorage.setItem('clipdock.exePath', path);
  }

  function setBusy(button, busy, label) {
    if (!button) return;
    button.disabled = !!busy;
    button.classList.toggle('is-busy', !!busy);
    if (!label) return;
    var node = button.querySelector('span') || button;
    // Evita repintados constantes en CEP: el botón ya no parpadea si el texto no cambió.
    if (node.textContent !== label) node.textContent = label;
  }

  function updateUi() {
    var appOpen = socket && socket.connected;
    var bridgeReady = appOpen && activeTarget === appId && (!activeClientId || activeClientId === clientId);
    var apiReady = appOpen && !!apiBase;
    var text = bridgeReady ? 'Puente listo' : appOpen ? 'App abierta' : 'Abrir ClipDock';

    $('host-label').textContent = hostName;
    $('compact-status').className = 'status-pill ' + (bridgeReady ? 'bridge' : appOpen ? 'online' : 'offline');
    $('compact-status').querySelector('span').textContent = text;
    $('mini-orb').className = 'mini-orb ' + (bridgeReady ? 'bridge' : appOpen ? 'online' : 'offline');
    if ($('bridge-orb')) $('bridge-orb').className = 'mini-orb compact ' + (bridgeReady ? 'bridge' : appOpen ? 'online' : 'offline');
    $('mini-title').textContent = appOpen ? 'ClipDock' : 'Abrir ClipDock';
    $('mini-subtitle').textContent = bridgeReady ? 'Puente listo' : appOpen ? 'App abierta · clic para enlazar' : 'App cerrada · clic para abrir y continuar';
    $('bridge-title').textContent = bridgeReady ? 'Proyecto enlazado.' : appOpen ? 'ClipDock está abierto.' : 'Abrir ClipDock para continuar.';
    $('bridge-description').textContent = bridgeReady ? 'Las descargas terminadas se importan directo a este proyecto.' : appOpen ? 'Enlaza el puente para importar descargas y enviar selección.' : 'La extensión necesita la app abierta para usar cookies, cola y carpeta de salida.';
    $('api-state').textContent = apiReady ? 'API lista' : 'API esperando';
    $('api-state').className = 'tiny-state ' + (apiReady ? 'ready' : '');
    $('analyze-url').disabled = !apiReady;
    $('download-send').disabled = !apiReady;
    $('send-selection').disabled = !appOpen;
    $('link-bridge').disabled = !appOpen;
    if ($('ai-run')) $('ai-run').disabled = !apiReady;
    if ($('workshop-run')) $('workshop-run').disabled = !apiReady;
    if ($('asset-refresh')) $('asset-refresh').disabled = !apiReady;
  }

  async function discoverBridge() {
    for (var i = 0; i < BRIDGE_PORTS.length; i++) {
      var candidate = 'http://127.0.0.1:' + BRIDGE_PORTS[i];
      try {
        var response = await Promise.race([
          fetch(candidate + '/bridge/status', { cache: 'no-store' }),
          new Promise(function (_resolve, reject) { setTimeout(function () { reject(new Error('timeout')); }, 350); })
        ]);
        if (!response.ok) continue;
        var status = await response.json();
        if (status && status.ready && status.appName === APP_NAME && status.apiPort) return candidate;
      } catch (_) {}
    }
    return '';
  }

  async function connectBridge(force) {
    if (socket && socket.connected && !force) return;
    if (bridgeConnecting) return;
    bridgeConnecting = true;
    if (socket) {
      try { socket.removeAllListeners(); socket.disconnect(); } catch (_) {}
      socket = null;
    }
    log('Buscando ClipDock local…');
    var discovered = await discoverBridge();
    bridgeConnecting = false;
    if (!discovered) {
      apiBase = '';
      activeTarget = null;
      activeClientId = null;
      log('ClipDock no está abierto. Usa Abrir app o inicia ClipDock manualmente.');
      updateUi();
      return;
    }
    bridgeUrl = discovered;
    socket = io(bridgeUrl, { transports: ['polling', 'websocket'], reconnection: true, reconnectionDelay: 900, timeout: 4500 });
    socket.on('connect', function () {
      log('ClipDock detectado. Puedes enlazar el puente.');
      socket.emit('register', { appIdentifier: appId, clientId: clientId }, function () {
        if (localStorage.getItem('clipdock.autoLink') === '1') {
          socket.emit('set_active_target', { targetApp: appId, clientId: clientId });
        }
        socket.emit('get_active_target');
        socket.emit('get_bridge_status');
      });
      updateUi();
    });
    socket.on('connect_error', function () {
      apiBase = '';
      activeTarget = null;
      activeClientId = null;
      log('ClipDock no está abierto. Usa Abrir app o inicia ClipDock manualmente.');
      updateUi();
    });
    socket.on('disconnect', function () {
      apiBase = '';
      activeTarget = null;
      activeClientId = null;
      log('Se perdió conexión con ClipDock.');
      updateUi();
    });
    socket.on('active_target_update', function (data) {
      data = data || {};
      activeTarget = data.activeTarget || null;
      activeClientId = data.activeClientId || null;
      apiBase = data.apiPort ? 'http://127.0.0.1:' + data.apiPort : apiBase;
      if (apiBase && apiBase !== hydratedApiBase) hydrateRemoteControl();
      updateUi();
    });
    socket.on('new_file', function (data) {
      var pkg = data && data.filePackage;
      if (!pkg) return;
      var files = [pkg.video, pkg.thumbnail, pkg.subtitle].filter(Boolean);
      handleImportCommand({ deliveryId: data.deliveryId, files: files, targetBin: pkg.targetBin || TARGET_BIN, addToTimeline: Boolean(pkg.addToTimeline) });
    });
    socket.on('import_files', function (data) {
      if (data && data.files && data.files.length) handleImportCommand(data);
    });
  }

  function ensureThisPanelActive() {
    if (!socket || !socket.connected) return Promise.resolve(false);
    return socketEmitAck('set_active_target', { targetApp: appId, clientId: clientId }, 2200).then(function (ack) {
      var active = Boolean(ack && ack.active);
      if (active) localStorage.setItem('clipdock.autoLink', '1');
      return active;
    });
  }

  async function api(path, options) {
    if (!apiBase) throw new Error('ClipDock está cerrado o la API todavía no está lista.');
    var res = await fetch(apiBase + path, Object.assign({ headers: { 'Content-Type': 'application/json' } }, options || {}));
    var text = await res.text();
    var data = text ? JSON.parse(text) : {};
    if (!res.ok || data.error) {
      var err = new Error(data.error || ('Error ' + res.status));
      err.status = res.status;
      err.code = data.code || '';
      err.components = data.components || [];
      err.action = data.action || '';
      throw err;
    }
    return data;
  }

  async function bridgePost(path, body) {
    var res = await fetch(bridgeUrl + path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body || {})
    });
    var text = await res.text();
    var data = text ? JSON.parse(text) : {};
    if (!res.ok || data.error) {
      var err = new Error(data.error || ('Bridge error ' + res.status));
      err.status = res.status;
      err.code = data.code || '';
      err.components = data.components || [];
      throw err;
    }
    return data;
  }

  function socketEmitAck(eventName, payload, timeoutMs) {
    return new Promise(function (resolve) {
      if (!socket || !socket.connected) return resolve(null);
      var finished = false;
      var timer = setTimeout(function () {
        if (finished) return;
        finished = true;
        resolve(null);
      }, timeoutMs || 1400);
      try {
        socket.emit(eventName, payload, function (response) {
          if (finished) return;
          finished = true;
          clearTimeout(timer);
          resolve(response || { accepted: true });
        });
      } catch (_) {
        if (!finished) {
          finished = true;
          clearTimeout(timer);
          resolve(null);
        }
      }
    });
  }

  function normalizeUrl(value) {
    var text = String(value || '').trim();
    var matches = text.match(/https?:\/\/\S+/ig);
    return matches && matches.length ? matches[matches.length - 1] : text;
  }

  function friendlyDownloadError(error) {
    var message = String((error && error.message) || error || 'Error desconocido');
    if (/cookies|confirmar|sign in|bot|sesión|session|login|youtube/i.test(message)) {
      return 'YouTube rechazó la sesión. La extensión ya usa las cookies que ClipDock tiene guardadas; abre ClipDock > Ajustes > Cookies, pulsa Probar cookies y reexporta el cookies.txt si falla. También puedes descargar desde la app y marcar Enviar a Premiere.';
    }
    if (/ClipDock está cerrado|API todavía/i.test(message)) {
      return 'Abre ClipDock primero para usar su motor, cookies y carpeta de salida.';
    }
    return message;
  }

  function isAuthDownloadMessage(message) {
    return /cookies|confirmar|sign in|not a bot|sesión|session|login|youtube rechaz/i.test(String(message || ''));
  }

  function buildDownloadRequest(autoStart) {
    var title = lastInfo && lastInfo.title ? lastInfo.title : 'Descarga desde Adobe';
    var preset = $('download-recode') ? $('download-recode').value : 'h264_standard';
    return {
      url: normalizeUrl($('url-input').value),
      thumbnail: $('save-thumb').checked,
      subtitles: $('download-subs').checked ? ['all'] : [],
      subtitleFormat: 'srt',
      addToTimeline: $('add-timeline').checked,
      autoStart: autoStart !== false,
      title: title,
      sourceThumbnail: (lastInfo && lastInfo.thumbnail) || '',
      formatSelector: 'bv*+ba/b',
      recode: preset === 'off' ? { mode: 'off' } : { mode: 'quick', preset: preset, keepOriginal: false },
      source: 'adobe-extension',
      requestId: 'cep_' + Date.now() + '_' + Math.random().toString(16).slice(2)
    };
  }

  async function handOffDownloadToClipDock(error, existingRequest) {
    var request = existingRequest || buildDownloadRequest(true);
    if (!request.url) return false;
    if (apiBase) {
      try {
        await ensureThisPanelActive();
        var accepted = await api('/api/adobe/remote-download', { method: 'POST', body: JSON.stringify(request) });
        var requestId = accepted.requestId || request.requestId;
        log('ClipDock recibió el enlace. Si falta FFmpeg u otro motor, aparecerá en la app en Componentes.');
        if (accepted.jobId) startPollingJob(accepted.jobId, request);
        else if (requestId) startPollingRemoteRequest(requestId, request);
        return true;
      } catch (apiError) {
        // Intentamos por puente/socket abajo.
      }
    }
    try {
      var bridgeResponse = await bridgePost('/adobe/download-request', request);
      if (bridgeResponse && bridgeResponse.accepted) {
        log('Enlace entregado al puente. Abre ClipDock para continuar la descarga e instalar componentes si hacen falta.');
        return true;
      }
    } catch (_) {}
    if (socket && socket.connected) {
      socket.emit('adobe_download_request', request);
      log('Enlace enviado a ClipDock. Abre la app para ver la descarga y cualquier componente pendiente.');
      return true;
    }
    $('compact-status').className = 'status-pill offline';
    if ($('bridge-orb')) $('bridge-orb').className = 'mini-orb compact offline';
    log('Abrir ClipDock para continuar con la descarga. La extensión no instala motores sola; ClipDock los baja en Documentos\ClipDock\Componentes. ' + friendlyDownloadError(error));
    updateUi();
    return false;
  }

  async function clipdockCookiesStatus() {
    try { return await api('/api/cookies/status'); } catch (_) { return null; }
  }

  async function analyzeUrl() {
    try {
      var url = normalizeUrl($('url-input').value);
      if (!url) throw new Error('Pega primero un enlace.');
      $('url-input').value = url;
      setBusy($('analyze-url'), true, 'Analizando…');
      log('Analizando enlace desde ClipDock…');
      var cookieStatus = await clipdockCookiesStatus();
      if (cookieStatus && !cookieStatus.looksValid && /youtube|youtu\.be/i.test(url)) log('ClipDock no tiene cookies válidas; si YouTube bloquea, abre la app para importarlas.');
      lastInfo = await api('/api/analyze', { method: 'POST', body: JSON.stringify({ url: url, source: 'adobe-extension', useClipDockCookies: true }) });
      var title = lastInfo.title || 'Video listo';
      var meta = [lastInfo.uploader || lastInfo.channel, lastInfo.duration_string || lastInfo.duration, lastInfo.resolution].filter(Boolean).join(' · ');
      $('media-title').textContent = title;
      $('media-meta').textContent = meta || 'Preparado para descargar e importar';
      if (lastInfo.thumbnail) $('media-thumb').style.backgroundImage = 'url("' + String(lastInfo.thumbnail).replace(/"/g, '%22') + '")';
      $('media-card').classList.remove('hidden');
      log('Listo. Puedes descargar e importar al proyecto.');
    } catch (error) {
      log(friendlyDownloadError(error));
    } finally {
      setBusy($('analyze-url'), false, 'Analizar enlace');
      updateUi();
    }
  }

  async function downloadAndSend() {
    try {
      var request = buildDownloadRequest(true);
      if (!request.url) throw new Error('Pega primero un enlace.');
      setBusy($('download-send'), true, 'Enviando…');
      var formatLabel = $('download-recode') && $('download-recode').selectedIndex >= 0 ? $('download-recode').options[$('download-recode').selectedIndex].text : 'Formato elegido';
      log('Mandando a ClipDock · ' + formatLabel + '…');
      if (!apiBase) {
        await handOffDownloadToClipDock(new Error('ClipDock está cerrado o la API todavía no está lista.'), request);
        setBusy($('download-send'), false, 'Descargar en ClipDock');
        return;
      }
      var settings = await api('/api/settings');
      request.outputDir = settings.outputDir;
      var linked = await ensureThisPanelActive();
      if (!linked) throw new Error('No se pudo enlazar este panel de Adobe con ClipDock.');
      var accepted = await api('/api/adobe/remote-download', { method: 'POST', body: JSON.stringify(request) });
      log('ClipDock recibió el enlace. Entrega: ' + formatLabel + '.');
      if (accepted.jobId) startPollingJob(accepted.jobId, request);
      else startPollingRemoteRequest(accepted.requestId || request.requestId, request);
    } catch (error) {
      await handOffDownloadToClipDock(error, request);
      if (!/ClipDock recibió|ClipDock continuará|Enlace enviado|Abrir ClipDock/i.test(($('log-line') || {}).textContent || '')) log(friendlyDownloadError(error));
      setBusy($('download-send'), false, 'Descargar en ClipDock');
    }
  }

  function startPollingRemoteRequest(requestId, originalRequest) {
    if (!requestId) {
      log('ClipDock recibió el enlace. Abre la app para ver el progreso en Descargas/Cola.');
      setBusy($('download-send'), false, 'Descargar en ClipDock');
      return;
    }
    if (pollTimer) clearInterval(pollTimer);
    var ticks = 0;
    pollTimer = setInterval(async function () {
      try {
        var jobs = await api('/api/jobs');
        var job = jobs.find(function (item) { return item.context && item.context.requestId === requestId; });
        if (!job) {
          ticks += 1;
          setBusy($('download-send'), true, ticks % 2 ? 'Esperando ClipDock…' : 'Preparando…');
          if (ticks === 4) log('Esperando que ClipDock inicie la descarga. Si aparece un aviso de componentes, instálalos desde la app.');
          if (ticks > 45) {
            clearInterval(pollTimer);
            pollTimer = null;
            setBusy($('download-send'), false, 'Descargar en ClipDock');
            log('ClipDock recibió el enlace, pero aún no inició. Abre la app: puede estar esperando FFmpeg en Componentes.');
          }
          return;
        }
        if (job.state === 'cancelled') {
          clearInterval(pollTimer);
          pollTimer = null;
          setBusy($('download-send'), false, 'Descargar en ClipDock');
          log('Descarga cancelada desde ClipDock.');
          return;
        }
        startPollingJob(job.id, originalRequest);
      } catch (error) {
        if (pollTimer) clearInterval(pollTimer);
        pollTimer = null;
        setBusy($('download-send'), false, 'Descargar en ClipDock');
        log(friendlyDownloadError(error));
      }
    }, 1000);
  }

  function startPollingJob(jobId, originalRequest) {
    if (pollTimer) clearInterval(pollTimer);
    var missingTicks = 0;
    var lastButtonLabel = '';
    pollTimer = setInterval(async function () {
      try {
        var jobs = await api('/api/jobs');
        var job = jobs.find(function (item) { return item.id === jobId; });
        if (!job) {
          missingTicks += 1;
          if (missingTicks > 5) {
            clearInterval(pollTimer);
            pollTimer = null;
            setBusy($('download-send'), false, 'Descargar en ClipDock');
            log('El trabajo ya no está en ClipDock. Puede haber sido cancelado o limpiado de la cola.');
          }
          return;
        }
        missingTicks = 0;
        if (job.state === 'cancelled') {
          clearInterval(pollTimer);
          pollTimer = null;
          setBusy($('download-send'), false, 'Descargar en ClipDock');
          log('Descarga cancelada desde ClipDock.');
          return;
        }
        var pct = Math.round((job.progress && job.progress.percent) || 0);
        var msg = (job.progress && job.progress.message) || 'Procesando';
        var buttonLabel = pct ? ('ClipDock ' + pct + '%') : 'ClipDock…';
        if (buttonLabel !== lastButtonLabel) {
          setBusy($('download-send'), true, buttonLabel);
          lastButtonLabel = buttonLabel;
        }
        log(msg);
        if (isAuthDownloadMessage(msg)) {
          clearInterval(pollTimer);
          pollTimer = null;
          setBusy($('download-send'), false, 'Descargar en ClipDock');
          log(friendlyDownloadError(new Error(msg)));
          return;
        }
        if (job.state === 'completed' && job.result) {
          clearInterval(pollTimer);
          pollTimer = null;
          setBusy($('download-send'), true, 'Importando…');
          var deliveryId = 'download_' + ((originalRequest && originalRequest.requestId) || jobId);
          var importRequest = {
            files: [job.result],
            targetBin: TARGET_BIN,
            addToTimeline: originalRequest ? Boolean(originalRequest.addToTimeline) : $('add-timeline').checked,
            deliveryId: deliveryId,
            waitTimeout: 12
          };
          var delivered = null;
          try {
            delivered = await api('/api/adobe/send', { method: 'POST', body: JSON.stringify(importRequest) });
          } catch (_) {
            delivered = null;
          }
          if (!delivered || !delivered.confirmed) {
            var localResult = await importFilesToAdobe(importRequest.files, importRequest.targetBin, importRequest.addToTimeline, deliveryId);
            if (!localResult.success) throw new Error(localResult.result || 'Premiere no confirmó la importación.');
          }
          log('Listo: Premiere confirmó la importación.');
          setBusy($('download-send'), false, 'Descargar en ClipDock');
        } else if (job.state === 'failed') {
          clearInterval(pollTimer);
          pollTimer = null;
          var failedError = new Error(job.error || 'La descarga falló.');
          throw failedError;
        } else if (job.state === 'cancelled') {
          clearInterval(pollTimer);
          pollTimer = null;
          setBusy($('download-send'), false, 'Descargar en ClipDock');
          log('Descarga cancelada desde ClipDock.');
        }
      } catch (error) {
        if (pollTimer) clearInterval(pollTimer);
        pollTimer = null;
        if (!/ClipDock continuará|Enlace enviado/i.test(($('log-line') || {}).textContent || '')) log(friendlyDownloadError(error));
        setBusy($('download-send'), false, 'Descargar en ClipDock');
      }
    }, 1100);
  }

  function evalAdobe(script, timeoutMs) {
    return new Promise(function (resolve) {
      var done = false;
      var timer = setTimeout(function () {
        if (!done) { done = true; resolve('Error: Premiere no respondió a tiempo.'); }
      }, timeoutMs || 120000);
      cs.evalScript(script, function (result) {
        if (done) return;
        done = true;
        clearTimeout(timer);
        resolve(String(result || ''));
      });
    });
  }

  function importFilesToAdobe(files, targetBin, addToTimeline, deliveryId) {
    if (!files || !files.length) return Promise.resolve({ success: false, result: 'No se recibieron archivos.' });
    if (deliveryId && importDeliveries[deliveryId]) return importDeliveries[deliveryId];

    var task = (async function () {
      var json = escapeForExtendScript(JSON.stringify(files));
      var bin = targetBin ? '"' + escapeForExtendScript(targetBin) + '"' : 'null';
      var insertTimeline = Boolean(addToTimeline);
      var playhead = 0;
      if (insertTimeline) {
        var timelineResult = await evalAdobe('getActiveTimelineInfo()', 10000);
        var info = { hasActiveTimeline: false, playheadTime: 0 };
        try { info = JSON.parse(timelineResult || '{}'); } catch (_) {}
        if (!info.hasActiveTimeline) {
          insertTimeline = false;
          log('No hay secuencia/composición activa; importando solo al bin.');
        } else {
          playhead = Number(info.playheadTime || 0);
        }
      }
      var result = await evalAdobe('importFiles("' + json + '", ' + insertTimeline + ', ' + playhead + ', true, ' + bin + ')', 120000);
      var success = result === 'success';
      if (success) log('Importado correctamente en Adobe.');
      else log(result || 'Premiere no confirmó la importación.');
      return { success: success, result: result || 'Sin respuesta', deliveryId: deliveryId || '' };
    }());
    if (deliveryId) importDeliveries[deliveryId] = task;
    return task;
  }

  function handleImportCommand(data) {
    data = data || {};
    var deliveryId = String(data.deliveryId || 'legacy_' + Date.now() + '_' + Math.random().toString(16).slice(2));
    importFilesToAdobe(data.files || [], data.targetBin || TARGET_BIN, Boolean(data.addToTimeline), deliveryId).then(function (outcome) {
      if (socket && socket.connected) {
        socket.emit('import_result', {
          deliveryId: deliveryId,
          success: Boolean(outcome.success),
          result: outcome.result || ''
        });
      }
    });
  }

  function linkBridge() {
    if (!socket || !socket.connected) return log('Abre ClipDock primero.');
    ensureThisPanelActive().then(function (active) {
      socket.emit('get_active_target');
      log(active ? 'Este proyecto quedó enlazado.' : 'No se pudo enlazar este proyecto.');
    });
  }

  function sendSelection() {
    if (!socket || !socket.connected) return log('Abre ClipDock primero.');
    cs.evalScript('getSelectedFilePathsFromAdobe()', async function (result) {
      var files = [];
      try { files = JSON.parse(result || '[]'); } catch (parseError) {
        log('No pude leer la selección de Adobe: ' + parseError.message);
        return;
      }
      if (!files.length) return log('No hay archivos seleccionados en Adobe. Selecciona clips reales en timeline o archivos en el panel Proyecto.');
      var clean = [];
      var seen = {};
      for (var i = 0; i < files.length; i++) {
        var key = String(files[i] || '').replace(/^file:\/\/\/?/i, '');
        try { key = decodeURIComponent(key); } catch (_) {}
        if (/^\/[A-Za-z]:\//.test(key)) key = key.slice(1);
        if (key && !seen[key.toLowerCase()]) { seen[key.toLowerCase()] = true; clean.push(key); }
      }
      if (!clean.length) return log('Adobe entregó una selección vacía. Selecciona clips con archivo de origen.');

      var requestId = 'selection_' + Date.now() + '_' + Math.random().toString(16).slice(2);
      var payload = { files: clean, source: appId, requestId: requestId, host: hostName };
      var receipts = [];

      // 1) Nuevo canal más confiable: POST directo al puente 7788.
      try {
        var bridgeResponse = await bridgePost('/adobe/receive', payload);
        if (bridgeResponse && Number(bridgeResponse.received || 0) > 0) receipts.push('puente HTTP');
      } catch (bridgeError) {
        console.log('ClipDock bridge HTTP no confirmó:', bridgeError);
      }

      // 2) API del motor si ya tenemos el puerto.
      if (apiBase) {
        try {
          var apiResponse = await api('/api/adobe/receive', { method: 'POST', body: JSON.stringify(payload) });
          if (apiResponse && Number(apiResponse.received || 0) > 0) receipts.push('API');
        } catch (apiError) {
          console.log('ClipDock API no confirmó:', apiError);
        }
      }

      // 3) Socket con ACK. Si el ACK no regresa, no lo contamos como confirmado.
      try {
        var ack = await socketEmitAck('adobe_push_files', payload, 1400);
        if (ack && Number(ack.received || 0) > 0) receipts.push('socket');
      } catch (_) {}

      // 4) Archivo inbox como último respaldo. Usamos APPDATA explícito si está disponible.
      try {
        var inboxScript = 'writeClipDockInbox("' + escapeForExtendScript(JSON.stringify(clean)) + '", "' + escapeForExtendScript(appId) + '")';
        var inboxResult = await new Promise(function (resolve) { cs.evalScript(inboxScript, resolve); });
        if (String(inboxResult || '').indexOf('success:') === 0) receipts.push('inbox');
        else if (String(inboxResult || '').indexOf('Error:') === 0) console.log('Inbox falló:', inboxResult);
      } catch (inboxError) {
        console.log('No pude escribir inbox:', inboxError);
      }

      if (receipts.length) {
        log(clean.length + ' archivo(s) enviados a ClipDock por ' + receipts.join(' + ') + '. Primer archivo: ' + clean[0]);
      } else {
        log('No se pudo confirmar la entrega. Abre ClipDock, enlaza el puente y vuelve a intentar. Primer archivo detectado: ' + clean[0]);
      }
    });
  }

  function fileName(path) {
    var parts = String(path || '').split(/[\\/]/);
    return parts[parts.length - 1] || 'archivo';
  }

  function fileStem(path) {
    return fileName(path).replace(/\.[^.]+$/, '') || 'ClipDock';
  }

  function outputPath(folder, name) {
    var clean = String(folder || '').replace(/[\\/]+$/, '');
    return clean + (clean.indexOf('\\') >= 0 ? '\\' : '/') + name;
  }

  function normalizeAdobeFiles(files) {
    var clean = [];
    var seen = {};
    for (var i = 0; i < (files || []).length; i++) {
      var value = String(files[i] || '').replace(/^file:\/\/\/?/i, '');
      try { value = decodeURIComponent(value); } catch (_) {}
      if (/^\/[A-Za-z]:\//.test(value)) value = value.slice(1);
      if (value && !seen[value.toLowerCase()]) {
        seen[value.toLowerCase()] = true;
        clean.push(value);
      }
    }
    return clean;
  }

  async function readAdobeSelection() {
    var result = await evalAdobe('getSelectedFilePathsFromAdobe()', 12000);
    var files = [];
    try { files = JSON.parse(result || '[]'); } catch (_) { files = []; }
    files = normalizeAdobeFiles(files);
    if (!files.length) throw new Error('Selecciona un clip o archivo real en Premiere.');
    remoteSelection = files;
    return files;
  }

  async function chooseRemoteSelection(labelId) {
    try {
      var files = await readAdobeSelection();
      var label = fileName(files[0]) + (files.length > 1 ? ' +' + (files.length - 1) : '');
      if ($('ai-source')) $('ai-source').textContent = label;
      if ($('workshop-source')) $('workshop-source').textContent = label;
      log(files.length + ' archivo(s) listos para el control remoto.');
      return files;
    } catch (error) {
      log(error.message || String(error));
      return [];
    }
  }

  function presetById(id) {
    for (var i = 0; i < recodePresets.length; i++) if (recodePresets[i].id === id) return recodePresets[i];
    return null;
  }

  function updatePresetHelp(selectId, helpId) {
    var preset = presetById($(selectId).value);
    $(helpId).textContent = preset ? preset.description : 'Conservar el formato descargado sin una segunda conversión.';
  }

  async function hydrateRemoteControl() {
    if (!apiBase || hydratedApiBase === apiBase) return;
    try {
      recodePresets = await api('/api/recode-presets');
      var options = recodePresets.map(function (preset) {
        return '<option value="' + escapeHtml(preset.id) + '">' + escapeHtml(preset.name) + '</option>';
      }).join('');
      $('download-recode').innerHTML = '<option value="off">Sin recodificar · original</option>' + options;
      $('workshop-preset').innerHTML = options;
      $('download-recode').value = localStorage.getItem('clipdock.downloadPreset') || 'h264_standard';
      if (!$('download-recode').value) $('download-recode').value = 'h264_standard';
      $('workshop-preset').value = localStorage.getItem('clipdock.workshopPreset') || 'prores_lt';
      if (!$('workshop-preset').value) $('workshop-preset').value = 'h264_standard';
      updatePresetHelp('download-recode', 'download-recode-help');
      updatePresetHelp('workshop-preset', 'workshop-preset-help');
      hydratedApiBase = apiBase;
    } catch (error) {
      console.log('No pude cargar presets remotos:', error);
    }
  }

  function wait(ms) {
    return new Promise(function (resolve) { setTimeout(resolve, ms); });
  }

  async function waitForRemoteJob(jobId, statusNode) {
    while (true) {
      var jobs = await api('/api/jobs');
      var job = jobs.find(function (item) { return item.id === jobId; });
      if (!job) throw new Error('ClipDock perdió el trabajo de la cola.');
      var percent = Math.round((job.progress && job.progress.percent) || 0);
      var message = (job.progress && job.progress.message) || 'Procesando';
      if (statusNode) statusNode.textContent = (percent ? percent + '% · ' : '') + message;
      if (job.state === 'completed' && job.result) return job;
      if (job.state === 'failed' || job.state === 'cancelled') throw new Error(job.error || 'El trabajo no pudo completarse.');
      await wait(900);
    }
  }

  async function importRemoteResult(job, addToTimeline, prefix) {
    var deliveryId = prefix + '_' + job.id;
    await ensureThisPanelActive();
    var response = null;
    try {
      response = await api('/api/adobe/send', { method: 'POST', body: JSON.stringify({
        files: [job.result], targetBin: TARGET_BIN, addToTimeline: Boolean(addToTimeline), deliveryId: deliveryId, waitTimeout: 12
      }) });
    } catch (_) { response = null; }
    if (response && response.confirmed) return true;
    var localResult = await importFilesToAdobe([job.result], TARGET_BIN, Boolean(addToTimeline), deliveryId);
    if (!localResult.success) throw new Error(localResult.result || 'Premiere no confirmó la importación.');
    return true;
  }

  async function runAiLab() {
    var button = $('ai-run');
    var status = $('ai-status');
    try {
      if (!remoteSelection.length) await chooseRemoteSelection('ai-source');
      if (!remoteSelection.length) return;
      var input = remoteSelection[0];
      var settings = await api('/api/settings');
      if (!settings.outputDir) throw new Error('Elige una carpeta de salida en ClipDock > Ajustes.');
      var mode = $('ai-mode').value;
      var scale = $('ai-scale').value;
      var imageFile = /\.(png|jpe?g|webp|bmp|tiff?|avif)$/i.test(input);
      var videoFile = /\.(mp4|mov|mkv|webm|avi|m4v)$/i.test(input);
      setBusy(button, true, 'Preparando IA…');
      var stamp = Date.now();
      var job;
      if (mode === 'remove-bg' || mode === 'upscale-image') {
        if (!imageFile) throw new Error('Este proceso necesita una imagen seleccionada en Premiere.');
        var imageOutput = outputPath(settings.outputDir, fileStem(input) + '_ClipDock_IA_' + stamp + '.png');
        var imageOptions = { format: 'PNG', png_compression: 3 };
        if (mode === 'remove-bg') {
          imageOptions.rembg_enabled = true;
          imageOptions.rembg_model = 'isnet-general-use.onnx';
          imageOptions.rembg_gpu = true;
        } else {
          imageOptions.upscale_enabled = true;
          imageOptions.upscale_engine = 'Real-ESRGAN';
          imageOptions.upscale_model_friendly = '';
          imageOptions.upscale_scale = scale;
          imageOptions.upscale_tile = '0';
        }
        job = await api('/api/jobs/image', { method: 'POST', body: JSON.stringify({ input: input, output: imageOutput, options: imageOptions }) });
      } else {
        if (!videoFile) throw new Error('Selecciona un video compatible en Premiere.');
        var videoOutput = outputPath(settings.outputDir, fileStem(input) + '_ClipDock_IA_' + stamp + '.mp4');
        var videoOptions = { upscale_engine: 'Real-ESRGAN', upscale_model_friendly: '', upscale_scale: scale, upscale_container: 'mp4', upscale_codec: 'h264', upscale_quality: 20, upscale_preset: 'fast', upscale_tile: '0', upscale_denoise: '-1' };
        job = await api('/api/jobs/video-upscale', { method: 'POST', body: JSON.stringify({ input: input, output: videoOutput, options: videoOptions }) });
      }
      var completed = await waitForRemoteJob(job.id, status);
      status.textContent = 'Importando resultado en Premiere…';
      await importRemoteResult(completed, $('ai-add-timeline').checked, 'ai');
      status.textContent = 'Listo · resultado importado en el proyecto.';
      log('Laboratorio IA terminó e importó el resultado.');
    } catch (error) {
      status.textContent = 'Error · ' + friendlyDownloadError(error);
      log(friendlyDownloadError(error));
    } finally {
      setBusy(button, false, 'Procesar e importar');
    }
  }

  async function runWorkshop() {
    var button = $('workshop-run');
    var status = $('workshop-status');
    try {
      if (!remoteSelection.length) await chooseRemoteSelection('workshop-source');
      if (!remoteSelection.length) return;
      var settings = await api('/api/settings');
      if (!settings.outputDir) throw new Error('Elige una carpeta de salida en ClipDock > Ajustes.');
      setBusy(button, true, 'Recodificando…');
      var preset = $('workshop-preset').value;
      var job = await api('/api/jobs/recode', { method: 'POST', body: JSON.stringify({ input: remoteSelection[0], recode: { mode: 'quick', preset: preset, outputDir: settings.outputDir } }) });
      var completed = await waitForRemoteJob(job.id, status);
      status.textContent = 'Importando resultado en Premiere…';
      await importRemoteResult(completed, $('workshop-add-timeline').checked, 'workshop');
      status.textContent = 'Listo · recodificación importada.';
      log('Taller terminó e importó el archivo recodificado.');
    } catch (error) {
      status.textContent = 'Error · ' + friendlyDownloadError(error);
      log(friendlyDownloadError(error));
    } finally {
      setBusy(button, false, 'Recodificar e importar');
    }
  }

  function renderRemoteAssets() {
    var list = $('remote-asset-list');
    var items = remoteAssets.filter(function (item) { return remoteAssetFilter === 'all' || item.kind === remoteAssetFilter; });
    if (!items.length) {
      list.innerHTML = '<div class="empty-state">No hay recursos en esta categoría todavía.</div>';
      return;
    }
    list.innerHTML = items.map(function (item) {
      var size = item.size ? (Number(item.size) / 1048576).toFixed(1) + ' MB' : 'Archivo local';
      return '<article class="asset-item"><span class="asset-kind">' + escapeHtml(String(item.kind || '').toUpperCase()) + '</span><div><strong>' + escapeHtml(item.name || fileName(item.path)) + '</strong><small>' + escapeHtml(size + ' · ' + (item.modifiedLabel || '')) + '</small></div><button class="asset-import" data-remote-asset="' + encodeURIComponent(item.path) + '">Importar</button></article>';
    }).join('');
  }

  async function loadRemoteAssets() {
    if (!apiBase) {
      $('remote-asset-list').innerHTML = '<div class="empty-state">Abre ClipDock para cargar tu biblioteca.</div>';
      return;
    }
    try {
      var data = await api('/api/assets');
      remoteAssets = data.assets || [];
      renderRemoteAssets();
    } catch (error) {
      $('remote-asset-list').innerHTML = '<div class="empty-state">' + escapeHtml(error.message || String(error)) + '</div>';
    }
  }

  async function importRemoteAsset(button) {
    var path = decodeURIComponent(button.getAttribute('data-remote-asset') || '');
    if (!path) return;
    var oldText = button.textContent;
    button.disabled = true;
    button.textContent = 'Enviando…';
    try {
      await ensureThisPanelActive();
      var deliveryId = 'asset_' + Date.now() + '_' + Math.random().toString(16).slice(2);
      var response = await api('/api/adobe/send', { method: 'POST', body: JSON.stringify({ files: [path], targetBin: 'ClipDock SFX VFX', addToTimeline: true, deliveryId: deliveryId, waitTimeout: 12 }) });
      if (!response.confirmed) {
        var localResult = await importFilesToAdobe([path], 'ClipDock SFX VFX', true, deliveryId);
        if (!localResult.success) throw new Error(localResult.result || 'Premiere no confirmó la importación.');
      }
      button.textContent = 'Importado';
      log(fileName(path) + ' importado en Premiere.');
    } catch (error) {
      button.textContent = 'Reintentar';
      log(error.message || String(error));
    } finally {
      button.disabled = false;
      if (button.textContent === 'Enviando…') button.textContent = oldText;
    }
  }

  function activateTab(name) {
    var buttons = document.querySelectorAll('[data-tab]');
    var panels = document.querySelectorAll('[data-panel]');
    for (var i = 0; i < buttons.length; i++) buttons[i].classList.toggle('active', buttons[i].getAttribute('data-tab') === name);
    for (var j = 0; j < panels.length; j++) panels[j].classList.toggle('active', panels[j].getAttribute('data-panel') === name);
    localStorage.setItem('clipdock.remoteTab', name);
    if (name === 'assets') loadRemoteAssets();
  }

  function launchApp() {
    var path = appPath();
    var safe = escapeForExtendScript(path);
    log('Abriendo ClipDock…');
    cs.evalScript('executeClipDock("' + safe + '", "' + appId + '")', function (result) {
      if (String(result).indexOf('Error:') === 0) {
        cs.evalScript('selectClipDockExecutable()', function (selected) {
          if (!selected || selected === 'cancel') return log('Selecciona ClipDock.exe cuando quieras abrirlo desde Adobe.');
          setAppPath(selected);
          cs.evalScript('executeClipDock("' + escapeForExtendScript(selected) + '", "' + appId + '")');
          setTimeout(function () { connectBridge(true); }, 1800);
        });
      } else {
        setTimeout(function () { connectBridge(true); }, 1800);
      }
    });
  }

  function setup() {
    $('compact-status').addEventListener('click', function () { if (socket && socket.connected) linkBridge(); else launchApp(); });
    $('mini-open').addEventListener('click', function () { if (socket && socket.connected) linkBridge(); else launchApp(); });
    $('launch-app').addEventListener('click', launchApp);
    $('link-bridge').addEventListener('click', linkBridge);
    $('send-selection').addEventListener('click', sendSelection);
    $('analyze-url').addEventListener('click', analyzeUrl);
    $('download-send').addEventListener('click', downloadAndSend);
    $('url-input').addEventListener('keydown', function (event) { if (event.key === 'Enter') analyzeUrl(); });
    $('paste-url').addEventListener('click', async function () {
      try {
        var text = await navigator.clipboard.readText();
        $('url-input').value = normalizeUrl(text);
      } catch (_) { log('No pude leer el portapapeles desde CEP.'); }
    });
    var tabButtons = document.querySelectorAll('[data-tab]');
    for (var i = 0; i < tabButtons.length; i++) {
      tabButtons[i].addEventListener('click', function () { activateTab(this.getAttribute('data-tab')); });
    }
    $('download-recode').addEventListener('change', function () {
      localStorage.setItem('clipdock.downloadPreset', this.value);
      updatePresetHelp('download-recode', 'download-recode-help');
    });
    $('workshop-preset').addEventListener('change', function () {
      localStorage.setItem('clipdock.workshopPreset', this.value);
      updatePresetHelp('workshop-preset', 'workshop-preset-help');
    });
    $('ai-pick-source').addEventListener('click', function () { chooseRemoteSelection('ai-source'); });
    $('workshop-pick-source').addEventListener('click', function () { chooseRemoteSelection('workshop-source'); });
    $('ai-run').addEventListener('click', runAiLab);
    $('workshop-run').addEventListener('click', runWorkshop);
    $('ai-mode').addEventListener('change', function () { $('ai-scale').disabled = this.value === 'remove-bg'; });
    $('ai-scale').disabled = $('ai-mode').value === 'remove-bg';
    $('asset-refresh').addEventListener('click', loadRemoteAssets);
    var assetFilters = document.querySelectorAll('[data-asset-filter]');
    for (var j = 0; j < assetFilters.length; j++) {
      assetFilters[j].addEventListener('click', function () {
        remoteAssetFilter = this.getAttribute('data-asset-filter') || 'all';
        for (var k = 0; k < assetFilters.length; k++) assetFilters[k].classList.toggle('active', assetFilters[k] === this);
        renderRemoteAssets();
      });
    }
    $('remote-asset-list').addEventListener('click', function (event) {
      var button = event.target.closest('[data-remote-asset]');
      if (button) importRemoteAsset(button);
    });
    activateTab(localStorage.getItem('clipdock.remoteTab') || 'download');
    updateUi();
    connectBridge();
    setInterval(function () {
      if (socket && socket.connected) socket.emit('get_bridge_status');
      else connectBridge(true);
    }, 2500);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', setup);
  else setup();
}());
