// @target aftereffects
/**
 * Layout adaptativo (basado en la guía oficial Adobe ScriptUI / AutoLayoutManager):
 *  - Grupos con alignment / alignChildren = "fill" para que crezcan con el panel.
 *  - En contenedores se evita preferredSize (rompe AutoLayoutManager).
 *  - En onResizing se usa this.layout.resize() (no layout(true) en cada pixel).
 *  - Solo se reconstruye la jerarquía de botones cuando cambia de "modo"
 *    (fila / rejilla 3+2 / columna), porque cambiar orientación o estructura
 *    sí requiere layout(true) según la documentación.
 *  - Iconos vectoriales con factor de escala s = min(bw,bh)/baseSize para que
 *    también el dibujo crezca con el botón.
 */
(function (thisObj) {
    var panel = (thisObj instanceof Panel)
        ? thisObj
        : new Window("palette", "CacheAE", undefined, { resizeable: true });

    panel.alignment = ["fill", "fill"];
    panel.minimumSize = [60, 60];
    panel.orientation = "column";
    panel.alignChildren = ["fill", "fill"];
    panel.spacing = 4;
    panel.margins = [6, 6, 6, 6];

    var theme = {
        bg: [0.12, 0.12, 0.13],
        button: [0.26, 0.26, 0.28],
        buttonHover: [0.38, 0.38, 0.42],
        color1: [0.14, 0.12, 0.42],
        color2: [0.32, 0.18, 0.52],
        color3: [0.55, 0.22, 0.48],
        color4: [0.65, 0.2, 0.32],
        color5: [0.92, 0.52, 0.08],
        text: [0.94, 0.94, 0.96],
        textDisabled: [0.42, 0.42, 0.45]
    };

    var gPanel = panel.graphics;
    gPanel.backgroundColor = gPanel.newBrush(gPanel.BrushType.SOLID_COLOR, theme.bg);

    /** Dibujos vectoriales. Reciben factor "s" para escalar coordenadas y trazo. */
    var VECTORS = {
        FX: function (g, bw, bh, pen, s) {
            var cx = bw / 2;
            var cy = bh / 2;
            g.newPath();
            g.moveTo(cx - 9 * s, cy + 7 * s);
            g.lineTo(cx - 3 * s, cy - 1 * s);
            g.lineTo(cx + 1 * s, cy + 3 * s);
            g.lineTo(cx + 10 * s, cy - 9 * s);
            g.strokePath(pen);
        },
        PURGE: function (g, bw, bh, pen, s) {
            var cx = bw / 2;
            var cy = bh / 2;
            g.newPath();
            g.moveTo(cx - 10 * s, cy + 8 * s);
            g.lineTo(cx + 10 * s, cy - 8 * s);
            g.strokePath(pen);
            g.newPath();
            g.moveTo(cx - 12 * s, cy + 10 * s);
            g.lineTo(cx - 4 * s, cy + 10 * s);
            g.lineTo(cx + 2 * s, cy + 4 * s);
            g.lineTo(cx + 12 * s, cy + 4 * s);
            g.strokePath(pen);
        },
        FILM: function (g, bw, bh, pen, s) {
            var cx = bw / 2;
            var cy = bh / 2;
            var w = 20 * s;
            var h = 14 * s;
            g.newPath();
            g.rectPath(cx - w / 2, cy - h / 2, w, h);
            g.strokePath(pen);
            var i;
            for (i = -8; i <= 8; i += 4) {
                g.newPath();
                g.moveTo(cx + i * s, cy - h / 2);
                g.lineTo(cx + i * s, cy - h / 2 + 3 * s);
                g.strokePath(pen);
                g.newPath();
                g.moveTo(cx + i * s, cy + h / 2 - 3 * s);
                g.lineTo(cx + i * s, cy + h / 2);
                g.strokePath(pen);
            }
        },
        TRASH: function (g, bw, bh, pen, s) {
            var cx = bw / 2;
            var cy = bh / 2 + 1 * s;
            g.newPath();
            g.moveTo(cx - 9 * s, cy - 8 * s);
            g.lineTo(cx + 9 * s, cy - 8 * s);
            g.strokePath(pen);
            g.newPath();
            g.moveTo(cx - 7 * s, cy - 8 * s);
            g.lineTo(cx - 5 * s, cy + 8 * s);
            g.lineTo(cx + 5 * s, cy + 8 * s);
            g.lineTo(cx + 7 * s, cy - 8 * s);
            g.strokePath(pen);
            g.newPath();
            g.moveTo(cx - 4 * s, cy - 4 * s);
            g.lineTo(cx - 4 * s, cy + 4 * s);
            g.moveTo(cx, cy - 4 * s);
            g.lineTo(cx, cy + 4 * s);
            g.moveTo(cx + 4 * s, cy - 4 * s);
            g.lineTo(cx + 4 * s, cy + 4 * s);
            g.strokePath(pen);
        },
        SAVE: function (g, bw, bh, pen, s) {
            var cx = bw / 2;
            var cy = bh / 2;
            g.newPath();
            g.rectPath(cx - 10 * s, cy - 6 * s, 20 * s, 14 * s);
            g.strokePath(pen);
            g.newPath();
            g.moveTo(cx - 10 * s, cy - 2 * s);
            g.lineTo(cx + 10 * s, cy - 2 * s);
            g.strokePath(pen);
            g.newPath();
            g.rectPath(cx - 6 * s, cy - 10 * s, 12 * s, 5 * s);
            g.strokePath(pen);
        }
    };

    function tryPurgeEnum(memberName) {
        try {
            if (typeof PurgeTarget === "undefined") return false;
            var t = PurgeTarget[memberName];
            if (t === undefined) return false;
            app.purge(t);
            return true;
        } catch (e) {
            return false;
        }
    }

    function executeAllMemoryDiskMenu() {
        var labels = [
            "All Memory & Disk Cache...",
            "Toda la memoria y la caché del disco...",
            "Toda la memoria y la cach\u00e9 del disco..."
        ];
        var commandId = 0;
        var li;
        for (li = 0; li < labels.length; li++) {
            try {
                commandId = app.findMenuCommandId(labels[li]);
            } catch (eF) {
                commandId = 0;
            }
            if (commandId !== 0) {
                break;
            }
        }
        if (commandId === 0) commandId = 10200;
        try {
            app.executeCommand(commandId);
        } catch (e1) {
            try {
                app.executeCommand(10200);
            } catch (e2) { }
        }
    }

    function buildUsedSources(proj) {
        var used = {};
        var i;
        var j;
        var comp;
        var layer;
        for (i = 1; i <= proj.numItems; i++) {
            var item = proj.item(i);
            if (item instanceof CompItem) {
                comp = item;
                for (j = 1; j <= comp.numLayers; j++) {
                    layer = comp.layer(j);
                    if (layer.source) {
                        used[layer.source.id] = true;
                    }
                }
            }
        }
        return used;
    }

    function removeUnusedFootageAndEmptyFolders(proj) {
        var used = buildUsedSources(proj);
        var toRemove = [];
        var i;
        var item;
        for (i = 1; i <= proj.numItems; i++) {
            item = proj.item(i);
            if (item instanceof FootageItem && !used[item.id]) {
                toRemove.push(item);
            }
        }
        for (i = 0; i < toRemove.length; i++) {
            try {
                toRemove[i].remove();
            } catch (eR) { }
        }

        var found;
        do {
            found = false;
            toRemove = [];
            for (i = 1; i <= proj.numItems; i++) {
                item = proj.item(i);
                if (item instanceof FolderItem && item.numItems === 0 &&
                    item.parentFolder !== proj.rootFolder) {
                    toRemove.push(item);
                    found = true;
                }
            }
            for (i = 0; i < toRemove.length; i++) {
                try {
                    toRemove[i].remove();
                } catch (eF) { }
            }
        } while (found);
    }

    function fxAction() {
        app.beginUndoGroup("Toggle FX");
        try {
            var comp = app.project.activeItem;
            if (!(comp && comp instanceof CompItem)) return;
            var selectedLayers = comp.selectedLayers;
            if (selectedLayers.length === 0) return;
            var i;
            var j;
            var layer;
            var effects;
            var fx;
            for (i = 0; i < selectedLayers.length; i++) {
                layer = selectedLayers[i];
                effects = layer.property("ADBE Effect Parade");
                if (effects) {
                    for (j = 1; j <= effects.numProperties; j++) {
                        fx = effects.property(j);
                        fx.enabled = !fx.enabled;
                    }
                }
            }
        } finally {
            app.endUndoGroup();
        }
    }

    function purgeAction() {
        executeAllMemoryDiskMenu();
    }

    function imageCacheAction() {
        tryPurgeEnum("IMAGE_CACHES");
    }

    function removeAction() {
        app.beginUndoGroup("Limpiar footage no usado");
        try {
            removeUnusedFootageAndEmptyFolders(app.project);
        } finally {
            app.endUndoGroup();
        }
    }

    function saveAction() {
        try {
            var proj = app.project;
            if (!proj || !proj.file) {
                alert("Guarda el proyecto al menos una vez antes de usar el versionado automático.");
                return;
            }

            var currentFile = proj.file;
            var folder = currentFile.parent;
            var baseName = currentFile.name.replace(/\.aep$/i, "");
            baseName = baseName.replace(/_\d+$/, "");

            var maxVersion = 0;
            var files = folder.getFiles("*.aep");
            var i;
            var fileName;
            var pattern;
            var match;
            var versionNum;

            for (i = 0; i < files.length; i++) {
                fileName = files[i].name.replace(/\.aep$/i, "");
                pattern = new RegExp("^" + baseName + "_(\\d+)$");
                match = fileName.match(pattern);
                if (match) {
                    versionNum = parseInt(match[1], 10);
                    if (versionNum > maxVersion) maxVersion = versionNum;
                }
            }

            var newVersion = maxVersion + 1;
            var versionStr = (newVersion < 10 ? "0" : "") + newVersion;
            var newFileName = baseName + "_" + versionStr + ".aep";
            var newFile = new File(folder.fsName + "/" + newFileName);

            proj.save(newFile);
            alert("Proyecto guardado como:\n" + newFileName);
        } catch (err) {
            alert("Error al guardar: " + err.toString());
        }
    }

    var BUTTON_DEFS = [
        { id: "FX",    color: "color5", tip: "Activar / desactivar efectos",  action: fxAction },
        { id: "PURGE", color: "color1", tip: "Memoria y caché en disco (AE)", action: purgeAction },
        { id: "FILM",  color: "color2", tip: "Solo caché de imagen",          action: imageCacheAction },
        { id: "TRASH", color: "color3", tip: "Borrar footage no usado",       action: removeAction },
        { id: "SAVE",  color: "color4", tip: "Guardar copia con versión",     action: saveAction }
    ];

    var MIN_BTN = 28;       // tamaño mínimo lado cuadrado
    var DESIGN_BASE = 46;   // tamaño base donde los iconos se diseñaron

    function makeIconButton(parent, def) {
        var btn = parent.add("button", undefined, "");
        btn.helpTip = def.tip;
        btn.minimumSize = [MIN_BTN, MIN_BTN];
        btn.preferredSize = [DESIGN_BASE, DESIGN_BASE];
        btn.alignment = ["fill", "fill"];
        btn.active = false;
        btn.colorKey = def.color;
        btn.drawId = def.id;

        btn.onDraw = function () {
            var gfx = this.graphics;
            var bw = this.size[0];
            var bh = this.size[1];
            var s = Math.min(bw, bh) / DESIGN_BASE;
            if (s < 0.55) s = 0.55;
            if (s > 2.5) s = 2.5;

            var base = theme.button;
            if (this.enabled) {
                base = this.active ? theme.buttonHover : theme[this.colorKey];
            }
            gfx.newPath();
            gfx.rectPath(0, 0, bw, bh);
            gfx.fillPath(gfx.newBrush(gfx.BrushType.SOLID_COLOR, base));

            var ink = this.enabled ? theme.text : theme.textDisabled;
            var penWidth = Math.max(1.25, 1.6 * s);
            var pen = gfx.newPen(gfx.PenType.SOLID_COLOR, ink, penWidth);
            if (VECTORS[this.drawId]) {
                VECTORS[this.drawId](gfx, bw, bh, pen, s);
            }
        };

        try {
            btn.addEventListener("mouseover", function () {
                this.active = true;
                try { this.notify("onDraw"); } catch (eN1) { }
            });
            btn.addEventListener("mouseout", function () {
                this.active = false;
                try { this.notify("onDraw"); } catch (eN2) { }
            });
        } catch (eL) { }

        btn.onClick = def.action;
        return btn;
    }

    var buttonsHost = panel.add("group");
    buttonsHost.alignment = ["fill", "fill"];
    buttonsHost.alignChildren = ["fill", "fill"];
    buttonsHost.orientation = "column";
    buttonsHost.spacing = 4;
    buttonsHost.margins = 0;

    var currentMode = null;

    function clearGroup(g) {
        while (g.children.length > 0) {
            try {
                g.remove(g.children[0]);
            } catch (eC) {
                break;
            }
        }
    }

    function makeRow(host) {
        var r = host.add("group");
        r.orientation = "row";
        r.alignment = ["fill", "fill"];
        r.alignChildren = ["fill", "fill"];
        r.spacing = 4;
        r.margins = 0;
        return r;
    }

    /** Reconstruye los botones según el "mode" (row | grid | column). */
    function buildButtons(mode) {
        clearGroup(buttonsHost);
        var i;
        if (mode === "row") {
            buttonsHost.orientation = "row";
            for (i = 0; i < BUTTON_DEFS.length; i++) {
                makeIconButton(buttonsHost, BUTTON_DEFS[i]);
            }
        } else if (mode === "column") {
            buttonsHost.orientation = "column";
            for (i = 0; i < BUTTON_DEFS.length; i++) {
                makeIconButton(buttonsHost, BUTTON_DEFS[i]);
            }
        } else {
            buttonsHost.orientation = "column";
            var row1 = makeRow(buttonsHost);
            var row2 = makeRow(buttonsHost);
            makeIconButton(row1, BUTTON_DEFS[0]);
            makeIconButton(row1, BUTTON_DEFS[1]);
            makeIconButton(row1, BUTTON_DEFS[2]);
            makeIconButton(row2, BUTTON_DEFS[3]);
            makeIconButton(row2, BUTTON_DEFS[4]);
        }
        try {
            panel.layout.layout(true);
        } catch (eLO) { }
    }

    function computeMode(w, h) {
        var spacing = 4;
        var margins = 12;
        var fits5InRow = w >= (5 * MIN_BTN + 4 * spacing + margins);
        var fits3InRow = w >= (3 * MIN_BTN + 2 * spacing + margins);
        var aspect = w / Math.max(1, h);

        if (fits5InRow && aspect >= 1.4) return "row";
        if (!fits3InRow || aspect <= 0.55) return "column";
        return "grid";
    }

    buildButtons("row");
    currentMode = "row";

    panel.onResizing = panel.onResize = function () {
        try {
            var w = this.size[0];
            var h = this.size[1];
            var nextMode = computeMode(w, h);
            if (nextMode !== currentMode) {
                currentMode = nextMode;
                buildButtons(nextMode);
            } else {
                this.layout.resize();
            }
        } catch (eR) { }
    };

    if (panel instanceof Window) {
        panel.center();
        panel.show();
    } else {
        try { panel.layout.layout(true); } catch (eLI) { }
    }
})(this);
