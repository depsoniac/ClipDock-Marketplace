/* --- GraphEditor main.js (Integrated Version) --- */
(function () {
    'use strict';

    var csInterface = new CSInterface();

    (function setupPanelFlyoutMenu() {
        try {
            var menuXml = '<Menu><MenuItem Id="ge_reload_panel" Label="Recargar panel" Enabled="true"/></Menu>';
            csInterface.setPanelFlyoutMenu(menuXml);
            csInterface.addEventListener('com.adobe.csxs.events.flyoutMenuClicked', function (evt) {
                var id = null;
                var d = evt && evt.data;
                if (d !== undefined && d !== null) {
                    if (typeof d === 'object') {
                        id = d.menuId || d.menuID;
                    } else if (typeof d === 'string') {
                        try {
                            var o = JSON.parse(d);
                            id = o.menuId || o.menuID;
                        } catch (e1) {
                            id = d;
                        }
                    }
                }
                if (id === 'ge_reload_panel') {
                    location.reload();
                }
            });
        } catch (e2) { }
    })();

    // Referencias UI
    const mainLayout = document.getElementById('mainLayout');
    const primaryColumn = document.getElementById('primaryColumn');
    const resizeGutter = document.getElementById('resizeGutter');
    const sliderOut = document.getElementById('sliderOut');
    const sliderIn = document.getElementById('sliderIn');
    const outValDisplay = document.getElementById('outValDisplay');
    const inValDisplay = document.getElementById('inValDisplay');
    const applyBtn = document.getElementById('applyBtn');
    const presetsGrid = document.getElementById('presetsGrid');
    const btnModeVel = document.getElementById('btnModeVelocity');
    const btnModeVal = document.getElementById('btnModeValue');
    const copyBtn = document.getElementById('copyBtn');

    const presetsToggle = document.getElementById('presetsToggle');
    const presetsPanel = document.getElementById('presetsPanel');
    const reverseBtn = document.getElementById('reverseBtn');
    const guideBtn = document.getElementById('guideBtn');
    const presetFilterAll = document.getElementById('presetFilterAll');
    const presetFilterFav = document.getElementById('presetFilterFav');
    const addPresetBtn = document.getElementById('addPresetBtn');
    const removePresetBtn = document.getElementById('removePresetBtn');

    // Referencias SVG
    const baseLineL = document.getElementById('graphBaseLeft');
    const baseLineR = document.getElementById('graphBaseRight');
    const graphContainer = document.getElementById('graphContainer');
    const speedGraphSVG = document.getElementById('speedGraphSVG');
    const graphCurve = document.getElementById('graphCurve');
    const graphFill = document.getElementById('graphFill');
    const hLineL = document.getElementById('handleLineLeft');
    const hLineR = document.getElementById('handleLineRight');
    const pointL = document.getElementById('handlePointLeft');
    const pointR = document.getElementById('handlePointRight');
    const dragAreaL = document.getElementById('dragAreaLeft');
    const dragAreaR = document.getElementById('dragAreaRight');
    const dragGroupLeft = document.getElementById('dragGroupLeft');
    const dragGroupRight = document.getElementById('dragGroupRight');
    const guideLine = document.getElementById('graphGuideVertical');
    const guideDot = document.getElementById('graphGuideDot');
    const specialGuideV = document.getElementById('specialGuideV');
    const specialGuideH = document.getElementById('specialGuideH');
    const specialReadout = document.getElementById('specialReadout');
    const specialReadoutText = document.getElementById('specialReadoutText');
    // Custom tab removed
    const refLinearDiag = document.getElementById('refLinearDiag');
    const modeSelectorRow = document.getElementById('modeSelectorRow');
    const presetFavToggleBtn = document.getElementById('presetFavToggleBtn');

    // Constantes Visuales
    const SVG_WIDTH = 300;
    const SVG_HEIGHT = 300;
    const HANDLE_PADDING = 20;

    // Estado
    let isLocked = false;
    let isDraggingLeft = false;
    let isDraggingRight = false;
    let handleLeftY = 0;
    let handleRightY = 0;
    let favoritesSet = new Set();
    /** Preset seleccionado en la grilla (para borrar con −) */
    let selectedPresetId = null;
    let customPresets = [];
    let allPresets = [];
    let graphMode = 'velocity';
    let currentViewScale = 1;
    let dragStartX = 0;
    let dragStartY = 0;
    let dragStartValX = 0;
    let dragStartValY = 0;
    let dragStartScale = 1;
    let isGuideEnabled = false;
    let playheadGuideTimer = null;

    /** graph | elastic | bounce | step (solo AE / panel CEP) */
    let curveFamily = 'graph';
    let specialElastic = { amp: 0.55, decay: 0.48 };
    // Bounce: peak = amplitud (vertical), damp = cantidad de rebotes (horizontal)
    let specialBounce = { peak: 0.55, damp: 0.45 };
    let specialStep = { steps: 5 };
    let isDraggingCustom = false;
    let customDragRef = null;
    let dragStartSpecial = {};

    // Estado Layout
    let isDraggingGutter = false;
    let layoutMode = '';
    const LAYOUT_THRESHOLD = 520;
    /** Altura guardada al arrastrar el gutter (para restaurar al volver a expandir presets) */
    let userSplitHeightPx = null;
    /** Ancho columna gráfica en layout horizontal */
    let userSplitWidthPx = null;

    // --- 1. PRESETS POR DEFECTO ---
    const DEFAULT_PRESETS = [
        { id: 'ease_in', family: 'graph', name: 'Ease In', o: 0, i: 70 },
        { id: 'ease_out', family: 'graph', name: 'Ease Out', o: 70, i: 0 },
        { id: 'ease_in_out', family: 'graph', name: 'Ease In Out', o: 70, i: 70 },
        { id: 'linear', family: 'graph', name: 'Linear', o: 0.1, i: 0.1 },
        { id: 'steep_in', family: 'graph', name: 'Steep In', o: 0, i: 100 },
        { id: 'steep_out', family: 'graph', name: 'Steep Out', o: 100, i: 0 },
        { id: 'expo_in', family: 'graph', name: 'Expo In', o: 0, i: 90 },
        { id: 'expo_out', family: 'graph', name: 'Expo Out', o: 90, i: 0 },
        { id: 'sharp_in', family: 'graph', name: 'Sharp In', o: 50, i: 100 },
        { id: 'sharp_out', family: 'graph', name: 'Sharp Out', o: 100, i: 50 }
    ];

    // --- 2. MOTOR GRÁFICO & ICONOS ---
    function cubicBezier(t, p0, p1, p2, p3) {
        const u = 1 - t; const tt = t * t; const uu = u * u; const uuu = uu * u; const ttt = tt * t;
        return (uuu * p0) + (3 * uu * t * p1) + (3 * u * tt * p2) + (ttt * p3);
    }
    function cubicBezierDerivative(t, p0, p1, p2, p3) {
        const u = 1 - t; return (3 * u * u * (p1 - p0)) + (6 * u * t * (p2 - p1)) + (3 * t * t * (p3 - p2));
    }

    function getStandardizedPath(o, i, vO, vI, mode) {
        let mcp1x = o / 100; let mcp2x = 1 - (i / 100);
        let mcp1y = (mode === 'velocity') ? 0 : vO; let mcp2y = (mode === 'velocity') ? 0 : vI;
        const steps = 25; let points = []; let minVal = 0, maxVal = 1;
        for (let s = 0; s <= steps; s++) {
            let t = s / steps;
            let bx = cubicBezier(t, 0, mcp1x, mcp2x, 1);
            let by = 0;
            if (mode === 'value') { by = cubicBezier(t, 0, mcp1y, mcp2y, 1); }
            else {
                let dx = cubicBezierDerivative(t, 0, mcp1x, mcp2x, 1); let dy = cubicBezierDerivative(t, 0, 0, 1, 1);
                if (dx > 0.0001) by = dy / dx; if (by > 25) by = 25;
            }
            if (by > maxVal) maxVal = by; if (by < minVal) minVal = by;
            points.push({ x: bx, y: by });
        }
        let rangeY = maxVal - minVal; if (rangeY < 0.001) rangeY = 1;
        const pad = 0.2;
        let visualMinY = minVal - (rangeY * pad);
        let visualMaxY = maxVal + (rangeY * pad);
        let visualRangeY = visualMaxY - visualMinY;
        const mapX = (x) => 10 + (x * 280);
        const mapY = (y) => 290 - ((y - visualMinY) / visualRangeY * 280);
        let d = "";
        points.forEach((p, idx) => { d += (idx === 0 ? "M" : "L") + " " + mapX(p.x).toFixed(1) + "," + mapY(p.y).toFixed(1); });
        return d;
    }

    function buildPathFromNormalizedPoints(raw) {
        const usableSize = SVG_WIDTH - (HANDLE_PADDING * 2);
        const mapX = function (u) { return HANDLE_PADDING + clamp01(u) * usableSize; };
        const mapYv = function (v) { return SVG_HEIGHT - HANDLE_PADDING - clamp01(v) * usableSize; };
        let dCurve = '';
        let dFill = '';
        const floorY = mapYv(0);
        let idx;
        for (idx = 0; idx < raw.length; idx++) {
            const p = raw[idx];
            const px = mapX(p.x);
            const py = mapYv(p.y);
            dCurve += (idx === 0 ? 'M' : 'L') + ' ' + px + ',' + py;
            if (idx === 0) dFill = 'M ' + px + ',' + floorY + ' L ' + px + ',' + py;
            else dFill += ' L ' + px + ',' + py;
        }
        const endX = mapX(1);
        dFill += ' L ' + endX + ',' + floorY + ' Z';
        return { dCurve: dCurve, dFill: dFill };
    }

    function clamp01(v) { return Math.max(0, Math.min(1, v)); }

    function easeOutBouncePenner(t) {
        const n1 = 7.5625, d1 = 2.75;
        if (t < 1 / d1) return n1 * t * t;
        if (t < 2 / d1) return n1 * (t -= 1.5 / d1) * t + 0.75;
        if (t < 2.5 / d1) return n1 * (t -= 2.25 / d1) * t + 0.9375;
        return n1 * (t -= 2.625 / d1) * t + 0.984375;
    }

    /** Penner ease-out elastic 0..1 (termina en 1 sin reescalado raro) */
    function easeOutElasticPenner(t) {
        if (t <= 0) return 0;
        if (t >= 1) return 1;
        const p = 0.3;
        return Math.pow(2, -10 * t) * Math.sin((t - p / 4) * (2 * Math.PI) / p) + 1;
    }

    // Elastic preview/apply curve: frequency+amplitude controlled, ends exactly at 1.
    function easeOutElasticControlled(u, freq, amp) {
        const t = clamp01(u);
        if (t <= 0) return 0;
        if (t >= 1) return 1;
        const A = clamp01(amp) * 0.95;
        const f = clamp01(freq);
        // Spread the action a bit so the first peak isn't a vertical spike.
        const tt = Math.pow(t, 0.78);
        // More useful range: ~1..6 cycles controlled by horizontal handle
        const omega = (Math.PI * 2) * (1.0 + f * 5.0); // ~1..6 cycles
        // Damping: mostly controlled by amplitude (bigger amp => less damping)
        const damping = 8.5 - (clamp01(amp) * 5.2);
        // Base: 1 - A*e^{-d t}*cos(w t)
        const y = 1 - A * Math.exp(-damping * tt) * Math.cos(omega * tt);
        // Normalize so y(1)=1
        const y1 = 1 - A * Math.exp(-damping) * Math.cos(omega);
        const denom = Math.max(1e-6, y1);
        // NOTE: do NOT clamp to 0..1 here; elastic needs overshoot (e.g. 1.22) to look correct.
        return (y / denom);
    }

    // Bounce-style (no spring): repeated "hits" that converge to 1 from below
    function easeOutBounceControlled(u, bounces, amp) {
        const t = clamp01(u);
        if (t <= 0) return 0;
        if (t >= 1) return 1;

        // Slightly later hit so it doesn't feel cramped
        const hit = 0.42;
        if (t <= hit) {
            const a = t / hit;
            return a * a * (3 - 2 * a);
        }

        const rem = 1 - hit;
        const tt = (t - hit) / rem;
        const n = Math.max(1, Math.min(8, bounces | 0));
        // Smooth repeated arcs: (1-cos)/2
        // Tune for "readable mountains" (not too dense / not spiky).
        const omega = n * Math.PI * 1.05;
        const decay = 1.55 + n * 0.34;
        const envelope = Math.exp(-decay * tt);
        const dip = (1 - Math.cos(omega * tt)) * 0.5; // 0..1
        const depth = clamp01(amp) * 0.92;
        const y = 1 - (depth * envelope * dip);
        return clamp01(y);
    }

    // Damped spring that starts at 0 and ends at 1 (normalized by f(1))
    function easeOutSpring01(u, omega, zeta) {
        const t = clamp01(u);
        if (t <= 0) return 0;
        if (t >= 1) return 1;
        const w = Math.max(0.0001, omega);
        const d = Math.max(0.0001, zeta);
        function f(tt) {
            return 1 - Math.exp(-d * tt) * (Math.cos(w * tt) + (d / w) * Math.sin(w * tt));
        }
        const f1 = Math.max(0.0001, f(1));
        return f(t) / f1;
    }

    function catmullRomSample(controls, numSegSamples) {
        if (!controls || controls.length < 2) return [];
        const pts = controls.slice().sort(function (a, b) { return a.x - b.x; });
        const out = [];
        let si;
        for (si = 0; si < pts.length - 1; si++) {
            const p0 = pts[Math.max(0, si - 1)];
            const p1 = pts[si];
            const p2 = pts[si + 1];
            const p3 = pts[Math.min(pts.length - 1, si + 2)];
            let j;
            for (j = 0; j <= numSegSamples; j++) {
                if (si > 0 && j === 0) continue;
                const tt = j / numSegSamples;
                const tt2 = tt * tt;
                const tt3 = tt2 * tt;
                const x = 0.5 * ((2 * p1.x) + (-p0.x + p2.x) * tt + (2 * p0.x - 5 * p1.x + 4 * p2.x - p3.x) * tt2 + (-p0.x + 3 * p1.x - 3 * p2.x + p3.x) * tt3);
                const y = 0.5 * ((2 * p1.y) + (-p0.y + p2.y) * tt + (2 * p0.y - 5 * p1.y + 4 * p2.y - p3.y) * tt2 + (-p0.y + 3 * p1.y - 3 * p2.y + p3.y) * tt3);
                out.push({ x: clamp01(x), y: clamp01(y) });
            }
        }
        out.sort(function (a, b) { return a.x - b.x; });
        return out;
    }

    function sampleCustomPolyline(u, pts) {
        const sorted = pts.slice().sort(function (a, b) { return a.x - b.x; });
        let j;
        for (j = 0; j < sorted.length - 1; j++) {
            if (u >= sorted[j].x && u <= sorted[j + 1].x) {
                const seg = sorted[j + 1].x - sorted[j].x;
                const tt = seg < 1e-8 ? 0 : (u - sorted[j].x) / seg;
                return sorted[j].y + (sorted[j + 1].y - sorted[j].y) * tt;
            }
        }
        return sorted[sorted.length - 1].y;
    }

    function sampleSpecialCurvePoints() {
        const num = 96;
        const out = [];
        let i, u, y;
        for (i = 0; i <= num; i++) {
            u = i / num;
            if (curveFamily === 'elastic') {
                y = sampleSpecialYAtU(u);
                if (u >= 1) y = 1;
                if (u <= 0) y = 0;
            } else if (curveFamily === 'bounce') {
                y = sampleSpecialYAtU(u);
                if (u >= 1) y = 1;
                if (u <= 0) y = 0;
            } else if (curveFamily === 'step') {
                const steps = Math.max(2, Math.min(16, Math.round(specialStep.steps)));
                y = steps <= 2 ? u : Math.min(1, Math.floor(u * steps) / (steps - 1));
            } else {
                y = u;
            }
            out.push({ x: u, y: y });
        }
        return out;
    }

    function sampleCurvePointsForPreset(p) {
        const oldFamily = curveFamily;
        const oldElastic = { amp: specialElastic.amp, decay: specialElastic.decay };
        const oldBounce = { peak: specialBounce.peak, damp: specialBounce.damp };
        const oldStep = { steps: specialStep.steps };
        const oldCustom = null;
        try {
            curveFamily = p.family || 'graph';
            if (curveFamily === 'elastic' && p.elastic) specialElastic = { amp: p.elastic.amp, decay: p.elastic.decay };
            if (curveFamily === 'bounce' && p.bounce) specialBounce = { peak: p.bounce.peak, damp: p.bounce.damp };
            if (curveFamily === 'step' && p.step) specialStep = { steps: p.step.steps };
            const raw = sampleSpecialCurvePoints();
            return raw;
        } finally {
            curveFamily = oldFamily;
            specialElastic = oldElastic;
            specialBounce = oldBounce;
            specialStep = oldStep;
        }
    }

    function sampleSpecialYAtU(u) {
        const uu = clamp01(u);
        if (curveFamily === 'step') {
            const steps = Math.max(2, Math.min(16, Math.round(specialStep.steps)));
            return steps <= 2 ? uu : Math.min(1, Math.floor(uu * steps) / (steps - 1));
        }
        if (curveFamily === 'bounce') {
            const amp = clamp01(specialBounce.peak);
            const freq = clamp01(specialBounce.damp);
            // Limit a bit so it stays readable and matches reference "mountains"
            const bounces = Math.max(1, Math.min(7, Math.round(1 + freq * 6)));
            return easeOutBounceControlled(uu, bounces, amp);
        }
        if (curveFamily === 'elastic') {
            // allow overshoot for preview; cap extreme values to avoid crazy view
            const yy = easeOutElasticControlled(uu, specialElastic.decay, specialElastic.amp);
            if (yy < -0.25) return -0.25;
            if (yy > 1.45) return 1.45;
            return yy;
        }
        return uu;
    }

    function buildBakePointsFromSamples(raw) {
        const pts = [];
        let k;
        for (k = 0; k < raw.length; k++) {
            pts.push({ t: raw[k].x, y: raw[k].y });
        }
        return pts;
    }

    const BAKE_MAX_INTERIOR = 28;

    function normalizeBakeEndpoints(pts) {
        if (!pts || pts.length < 2) return pts;
        const out = pts.map(function (p) {
            return { t: clamp01(parseFloat(p.t)), y: clamp01(parseFloat(p.y)) };
        });
        out.sort(function (a, b) { return a.t - b.t; });
        out[0] = { t: 0, y: 0 };
        out[out.length - 1] = { t: 1, y: 1 };
        return out;
    }

    function downsampleBakePoints(pts, maxInterior) {
        if (!pts || pts.length <= 2) return pts;
        const inner = pts.slice(1, -1);
        if (inner.length <= maxInterior) return pts;
        const step = (inner.length - 1) / (maxInterior - 1);
        const pick = [];
        let i;
        for (i = 0; i < maxInterior; i++) {
            pick.push(inner[Math.round(i * step)]);
        }
        return [pts[0]].concat(pick).concat([pts[pts.length - 1]]);
    }

    function updateGraphSpecialModes() {
        const usableSize = SVG_WIDTH - (HANDLE_PADDING * 2);
        const mapX = function (u) { return HANDLE_PADDING + u * usableSize; };

        baseLineL.style.display = 'none';
        baseLineR.style.display = 'none';

        const raw = sampleSpecialCurvePoints();

        // Auto-scale Y for all special modes so previews don't look "stuck at the top".
        // Also avoid leaving big empty space below 0 when curve never goes negative.
        let minY = 0;
        let maxY = 1;
        let i;
        for (i = 0; i < raw.length; i++) {
            const yy = raw[i].y;
            if (yy < minY) minY = yy;
            if (yy > maxY) maxY = yy;
        }
        // Safety caps
        if (minY < -0.35) minY = -0.35;
        if (maxY > 1.65) maxY = 1.65;
        let rangeY = maxY - minY;
        if (rangeY < 0.0001) rangeY = 1;

        // Padding tuned to feel like reference screenshots (tight framing / more zoom).
        const padTop = rangeY * 0.08;

        // IMPORTANT (per UX reference):
        // Do NOT move the baseline (y=0 must stay at the bottom like Graph).
        // Keep framing tight but not "over-zoomed" (which makes it feel too tall).
        let viewMinY = 0;
        let viewMaxY = maxY + padTop;

        // Gentle de-zoom for Elastic/Bounce only (keeps curve readable, reduces "too tall" feeling)
        if (curveFamily === 'elastic' || curveFamily === 'bounce') {
            viewMaxY = viewMaxY * 1.12;
        }

        // Always keep 0..1 visible
        if (viewMaxY < 1) viewMaxY = 1;

        // Ensure minimum visible range
        if (viewMaxY - viewMinY < 0.6) {
            const mid = (viewMinY + viewMaxY) / 2;
            viewMinY = mid - 0.3;
            viewMaxY = mid + 0.3;
            if (viewMinY > 0) viewMinY = 0;
            if (viewMaxY < 1) viewMaxY = 1;
        }
        const viewRangeY = viewMaxY - viewMinY;
        const mapYv = function (v) {
            const norm = (v - viewMinY) / viewRangeY;
            return SVG_HEIGHT - HANDLE_PADDING - (norm * usableSize);
        };

        // Grid (same 0..1 background, STATIC like Graph)
        // Do NOT map the grid with viewMinY/viewMaxY; only the curve is auto-framed.
        let dGrid = '';
        const FAR_PIXEL = 3000;
        const gridStep = 0.125;
        const mapYFixed01 = function (v01) {
            return SVG_HEIGHT - HANDLE_PADDING - (clamp01(v01) * usableSize);
        };
        let gx;
        for (gx = 0; gx <= 1.0001; gx += gridStep) {
            const xPos = mapX(gx);
            dGrid += 'M ' + xPos + ',' + (-FAR_PIXEL) + ' L ' + xPos + ',' + FAR_PIXEL + ' ';
        }
        let gy;
        for (gy = 0; gy <= 1.0001; gy += gridStep) {
            const yPos = mapYFixed01(gy);
            dGrid += 'M ' + (-FAR_PIXEL) + ',' + yPos + ' L ' + FAR_PIXEL + ',' + yPos + ' ';
        }
        document.getElementById('gridPath').setAttribute('d', dGrid);

        if (refLinearDiag) {
            // Keep diagonal aligned with the framed curve (like before).
            refLinearDiag.setAttribute('x1', mapX(0));
            refLinearDiag.setAttribute('y1', mapYv(0));
            refLinearDiag.setAttribute('x2', mapX(1));
            refLinearDiag.setAttribute('y2', mapYv(1));
            refLinearDiag.style.display = 'block';
        }

        let dCurve = '', dFill = '';
        // Keep fill baseline aligned with framed y=0 (like before).
        const floorY = mapYv(0);
        let idx;
        for (idx = 0; idx < raw.length; idx++) {
            const p = raw[idx];
            const px = mapX(p.x);
            const py = mapYv(p.y);
            dCurve += (idx === 0 ? 'M' : 'L') + ' ' + px + ',' + py;
            if (idx === 0) dFill = 'M ' + px + ',' + floorY + ' L ' + px + ',' + py;
            else dFill += ' L ' + px + ',' + py;
        }
        const endX = mapX(1);
        dFill += ' L ' + endX + ',' + floorY + ' Z';
        graphCurve.setAttribute('d', dCurve);
        graphFill.setAttribute('d', dFill);

        hLineL.setAttribute('display', 'none');
        hLineR.setAttribute('display', 'none');

        // Helper lines + readout (only Elastic/Bounce)
        if (specialGuideV) specialGuideV.style.display = 'none';
        if (specialGuideH) specialGuideH.style.display = 'none';
        if (specialReadout) specialReadout.style.display = 'none';
        if (specialReadoutText) specialReadoutText.textContent = '';

        // Bigger, nicer handles in special modes
        try { pointL.setAttribute('r', '6'); } catch (eR1) { }
        try { pointR.setAttribute('r', '6'); } catch (eR2) { }

        if (curveFamily === 'step') {
            dragGroupRight.style.display = 'none';
            const steps = Math.max(2, Math.min(16, Math.round(specialStep.steps)));
            const uKnob = (steps - 2) / 14;
            const px = mapX(0.12 + uKnob * 0.76);
            const py = mapYv(0.15);
            pointL.setAttribute('cx', px);
            pointL.setAttribute('cy', py);
            dragAreaL.setAttribute('x', px - 20);
            dragAreaL.setAttribute('y', py - 20);
        } else {
            dragGroupLeft.style.display = '';
            dragGroupRight.style.display = '';
            if (curveFamily === 'elastic') {
                // Elastic (tipo Neucurve):
                // - Punto sobre la curva: SOLO horizontal (timing/decay)
                // - Punto abajo: SOLO vertical (amplitud)
                const uH = 0.18 + (specialElastic.decay * 0.64); // 0.18..0.82
                const yH = sampleSpecialYAtU(uH);
                const pxH = mapX(uH);
                const pyH = mapYv(yH);

                const uV = 0.18;
                const yV = 0.12 + (specialElastic.amp * 0.70); // 0.12..0.82
                const pxV = mapX(uV);
                const pyV = mapYv(yV);

                pointL.setAttribute('cx', pxH);
                pointL.setAttribute('cy', pyH);
                pointR.setAttribute('cx', pxV);
                pointR.setAttribute('cy', pyV);

                if (specialGuideV) {
                    specialGuideV.setAttribute('x1', pxH);
                    specialGuideV.setAttribute('x2', pxH);
                    specialGuideV.style.display = 'block';
                }
                if (specialGuideH) {
                    specialGuideH.setAttribute('y1', pyV);
                    specialGuideH.setAttribute('y2', pyV);
                    specialGuideH.style.display = 'block';
                }
                if (specialReadout) {
                    const f = (1 + specialElastic.decay * 5);
                    if (specialReadoutText) specialReadoutText.textContent = 'F:' + f.toFixed(2) + '  A:' + (specialElastic.amp).toFixed(2);
                    specialReadout.style.display = 'block';
                }
            } else {
                // Bounce: como tu referencia
                // - Punto sobre la curva: SOLO horizontal (cantidad de rebotes)
                // - Punto abajo: SOLO vertical (amplitud)
                const uH = 0.26 + (specialBounce.damp * 0.60);
                const yH = sampleSpecialYAtU(uH);
                pointL.setAttribute('cx', mapX(uH));
                pointL.setAttribute('cy', mapYv(yH));

                const uV = 0.18;
                const yV = 0.14 + (specialBounce.peak * 0.68);
                pointR.setAttribute('cx', mapX(uV));
                pointR.setAttribute('cy', mapYv(yV));

                const pxH = parseFloat(pointL.getAttribute('cx'));
                const pyV = parseFloat(pointR.getAttribute('cy'));
                if (specialGuideV) {
                    specialGuideV.setAttribute('x1', pxH);
                    specialGuideV.setAttribute('x2', pxH);
                    specialGuideV.style.display = 'block';
                }
                if (specialGuideH) {
                    specialGuideH.setAttribute('y1', pyV);
                    specialGuideH.setAttribute('y2', pyV);
                    specialGuideH.style.display = 'block';
                }
                if (specialReadout) {
                    const bounces = Math.max(1, Math.min(7, Math.round(1 + clamp01(specialBounce.damp) * 6)));
                    if (specialReadoutText) specialReadoutText.textContent = 'R:' + bounces + '  A:' + (specialBounce.peak).toFixed(2);
                    specialReadout.style.display = 'block';
                }
            }
            dragAreaL.setAttribute('x', parseFloat(pointL.getAttribute('cx')) - 20);
            dragAreaL.setAttribute('y', parseFloat(pointL.getAttribute('cy')) - 20);
            dragAreaR.setAttribute('x', parseFloat(pointR.getAttribute('cx')) - 20);
            dragAreaR.setAttribute('y', parseFloat(pointR.getAttribute('cy')) - 20);
        }
    }

    function updateGraphVisuals() {
        // Make sure special HUD never leaks into Graph modes
        if (specialReadout) specialReadout.style.display = (curveFamily === 'elastic' || curveFamily === 'bounce') ? '' : 'none';
        if (curveFamily === 'graph' && specialReadoutText) specialReadoutText.textContent = '';
        // custom removed

        primaryColumn.classList.toggle('curve-family-graph', curveFamily === 'graph');
        primaryColumn.classList.toggle('curve-family-elastic', curveFamily === 'elastic');
        primaryColumn.classList.toggle('curve-family-bounce', curveFamily === 'bounce');
        primaryColumn.classList.toggle('curve-family-step', curveFamily === 'step');
        primaryColumn.classList.toggle('curve-family-custom', false);
        if (modeSelectorRow) {
            // Solo mostramos CURVE/VALUE en el modo Graph. En Custom es VALUE+ implícito.
            modeSelectorRow.style.display = (curveFamily === 'graph') ? '' : 'none';
            modeSelectorRow.classList.toggle('mode-locked-value', false);
        }
        if (refLinearDiag) refLinearDiag.style.display = curveFamily !== 'graph' ? 'block' : 'none';

        if (curveFamily !== 'graph') {
            updateGraphSpecialModes();
            if (isGuideEnabled) tickGuideFromAEPlayhead();
            return;
        }

        if (refLinearDiag) refLinearDiag.style.display = 'none';
        if (dragGroupLeft) dragGroupLeft.style.display = '';
        if (dragGroupRight) dragGroupRight.style.display = '';
        hLineL.removeAttribute('display');
        hLineR.removeAttribute('display');

        let o = parseFloat(sliderOut.value);
        let i = parseFloat(sliderIn.value);
        outValDisplay.textContent = Math.round(o) + '%';
        inValDisplay.textContent = Math.round(i) + '%';

        let mcp1x = o / 100; let mcp2x = 1 - (i / 100);
        let mcp1y = (graphMode === 'velocity') ? 0 : handleLeftY;
        let mcp2y = (graphMode === 'velocity') ? 0 : handleRightY;

        const steps = 120; let rawPoints = []; let minVal = 0, maxVal = 1;
        if (graphMode === 'value') { minVal = Math.min(0, handleLeftY, handleRightY); maxVal = Math.max(1, handleLeftY, handleRightY); } else { maxVal = 2.0; }

        for (let s = 0; s <= steps; s++) {
            let t = s / steps;
            let bx = cubicBezier(t, 0, mcp1x, mcp2x, 1);
            let by = 0;
            if (graphMode === 'value') { by = cubicBezier(t, 0, mcp1y, mcp2y, 1); }
            else {
                let dx = cubicBezierDerivative(t, 0, mcp1x, mcp2x, 1); let dy = cubicBezierDerivative(t, 0, 0, 1, 1);
                if (dx > 0.0001) by = dy / dx; if (by > 100) by = 100;
            }
            if (by > maxVal) maxVal = by; if (by < minVal) minVal = by;

            // Solo agreamos el punto si es significativamente diferente al anterior para evitar "3 líneas"
            if (rawPoints.length > 0) {
                let prev = rawPoints[rawPoints.length - 1];
                if (Math.abs(bx - prev.x) < 0.0001 && Math.abs(by - prev.y) < 0.0001) continue;
            }
            rawPoints.push({ x: bx, y: by });
        }

        let rangeY = maxVal - minVal; if (rangeY < 0.001) rangeY = 1;
        const paddingMultiplier = 0.2;
        let visualMinY = minVal - (rangeY * paddingMultiplier);
        let visualMaxY = maxVal + (rangeY * paddingMultiplier);
        let visualRangeY = visualMaxY - visualMinY;

        if (graphMode === 'value') currentViewScale = Math.max(1.0 + (paddingMultiplier * 2), visualRangeY); else currentViewScale = 1.0;

        let centerY = (visualMinY + visualMaxY) / 2;
        let viewMinY = centerY - (currentViewScale / 2); let viewMaxY = centerY + (currentViewScale / 2);
        let centerX = 0.5; let viewMinX = centerX - (currentViewScale / 2); let viewMaxX = centerX + (currentViewScale / 2);
        const usableSize = SVG_WIDTH - (HANDLE_PADDING * 2);

        const mapY = (val) => { let normalized = (graphMode === 'value') ? (val - viewMinY) / currentViewScale : (val - visualMinY) / visualRangeY; return SVG_HEIGHT - HANDLE_PADDING - (normalized * usableSize); };
        const mapX = (val) => { let normalized = (graphMode === 'value') ? (val - viewMinX) / currentViewScale : val; return HANDLE_PADDING + (normalized * usableSize); };

        let dCurve = "", dFill = ""; const floorY = mapY(0);
        for (let idx = 0; idx < rawPoints.length; idx++) {
            let p = rawPoints[idx]; let px = mapX(p.x); let py = mapY(p.y);
            let cmd = (idx === 0) ? "M" : "L"; dCurve += `${cmd} ${px},${py}`;
            if (idx === 0) dFill += `M ${px},${floorY} L ${px},${py}`; else dFill += ` L ${px},${py}`;
        }
        let endX = mapX(1); dFill += ` L ${endX},${floorY} Z`;
        graphCurve.setAttribute('d', dCurve); graphFill.setAttribute('d', dFill);

        // Grid (solo fondo cuadriculado, igual para todos los modos)
        let dGrid = '';
        const FAR_PIXEL = 3000;
        const gridStep = 0.125;
        let gx;
        for (gx = 0; gx <= 1.0001; gx += gridStep) {
            const xPos = HANDLE_PADDING + gx * usableSize;
            dGrid += `M ${xPos},${-FAR_PIXEL} L ${xPos},${FAR_PIXEL} `;
        }
        let gy;
        for (gy = 0; gy <= 1.0001; gy += gridStep) {
            const yPos = HANDLE_PADDING + gy * usableSize;
            dGrid += `M ${-FAR_PIXEL},${yPos} L ${FAR_PIXEL},${yPos} `;
        }
        document.getElementById('gridPath').setAttribute('d', dGrid);

        // Handles
        let h1x, h2x, h1y, h2y;
        if (graphMode === 'velocity') {
            // Ajuste para que los handles no se crucen (Estilo AE nativo)
            // Cada handle ocupa mÃ¡ximo el 48% para dejar un pequeÃ±o espacio en el centro
            h1x = mapX(mcp1x * 0.48); h1y = mapY(0);
            h2x = mapX(1 - ((1 - mcp2x) * 0.48)); h2y = mapY(0);
        }
        else { h1x = mapX(mcp1x); h1y = mapY(mcp1y); h2x = mapX(mcp2x); h2y = mapY(mcp2y); }

        // Limpiamos los ejes base redundantes para que no se vean "3 líneas"
        baseLineL.style.display = 'none';
        baseLineR.style.display = 'none';

        if (graphMode === 'velocity') {
            // En Velocity los handles son siempre horizontales
            hLineL.setAttribute('x1', mapX(0)); hLineL.setAttribute('y1', floorY); hLineL.setAttribute('x2', h1x); hLineL.setAttribute('y2', floorY);
            hLineR.setAttribute('x1', mapX(1)); hLineR.setAttribute('y1', floorY); hLineR.setAttribute('x2', h2x); hLineR.setAttribute('y2', floorY);
        } else {
            // En Value los handles siguen al punto para libertad total
            hLineL.setAttribute('x1', mapX(0)); hLineL.setAttribute('y1', mapY(0)); hLineL.setAttribute('x2', h1x); hLineL.setAttribute('y2', h1y);
            hLineR.setAttribute('x1', mapX(1)); hLineR.setAttribute('y1', mapY(1)); hLineR.setAttribute('x2', h2x); hLineR.setAttribute('y2', h2y);
        }
        pointL.setAttribute('cx', h1x); pointL.setAttribute('cy', h1y); pointR.setAttribute('cx', h2x); pointR.setAttribute('cy', h2y);
        dragAreaL.setAttribute('x', h1x - 20); dragAreaL.setAttribute('y', h1y - 20); dragAreaR.setAttribute('x', h2x - 20); dragAreaR.setAttribute('y', h2y - 20);
        if (isGuideEnabled) tickGuideFromAEPlayhead();
    }

    // --- 3. INTERACCIÓN ---
    function startDragLeft(e) {
        if (curveFamily !== 'graph') {
            isDraggingLeft = true;
            isDraggingRight = false;
            document.body.style.cursor = 'move';
            dragStartX = e.clientX;
            dragStartY = e.clientY;
            if (curveFamily === 'elastic') dragStartSpecial = { decay: specialElastic.decay, amp: specialElastic.amp };
            else if (curveFamily === 'bounce') dragStartSpecial = { peak: specialBounce.peak, damp: specialBounce.damp };
            else if (curveFamily === 'step') dragStartSpecial = { steps: specialStep.steps };
            return;
        }
        isDraggingLeft = true; isDraggingRight = false; document.body.style.cursor = 'move'; dragStartX = e.clientX; dragStartY = e.clientY; dragStartValX = parseFloat(sliderOut.value); dragStartValY = handleLeftY; dragStartScale = (graphMode === 'value') ? currentViewScale : 1;
    }
    function startDragRight(e) {
        if (curveFamily !== 'graph') {
            if (curveFamily === 'step') return;
            isDraggingRight = true;
            isDraggingLeft = false;
            document.body.style.cursor = 'move';
            dragStartX = e.clientX;
            dragStartY = e.clientY;
            if (curveFamily === 'elastic') dragStartSpecial = { decay: specialElastic.decay, amp: specialElastic.amp };
            else if (curveFamily === 'bounce') dragStartSpecial = { peak: specialBounce.peak, damp: specialBounce.damp };
            return;
        }
        isDraggingRight = true; isDraggingLeft = false; document.body.style.cursor = 'move'; dragStartX = e.clientX; dragStartY = e.clientY; dragStartValX = parseFloat(sliderIn.value); dragStartValY = handleRightY; dragStartScale = (graphMode === 'value') ? currentViewScale : 1;
    }
    function handleDrag(e) {
        if (curveFamily !== 'graph' && (isDraggingLeft || isDraggingRight)) {
            const rect = speedGraphSVG.getBoundingClientRect();
            const dy = (e.clientY - dragStartY) / Math.max(1, rect.height) * 2.2;
            const dx = (e.clientX - dragStartX) / Math.max(1, rect.width) * 2.2;
            if (curveFamily === 'elastic') {
                // Elastic:
                // - punto sobre curva (izq): SOLO horizontal => decay
                // - punto abajo (der): SOLO vertical => amp
                if (isDraggingLeft) specialElastic.decay = clamp01(dragStartSpecial.decay + dx);
                if (isDraggingRight) specialElastic.amp = clamp01(dragStartSpecial.amp - dy);
            } else if (curveFamily === 'bounce') {
                // Bounce:
                // - punto sobre curva (izq): SOLO horizontal => cantidad de rebotes (damp)
                // - punto abajo (der): SOLO vertical => amplitud (peak)
                if (isDraggingLeft) specialBounce.damp = clamp01(dragStartSpecial.damp + dx);
                if (isDraggingRight) specialBounce.peak = clamp01(dragStartSpecial.peak - dy);
            } else if (curveFamily === 'step' && isDraggingLeft) {
                const usable = rect.width - (HANDLE_PADDING * 2 * (rect.width / SVG_WIDTH));
                const nx = (e.clientX - rect.left - HANDLE_PADDING * (rect.width / SVG_WIDTH)) / usable;
                specialStep.steps = Math.max(2, Math.min(16, Math.round(2 + nx * 14)));
            }
            updateGraphVisuals();
            return;
        }
        if (!isDraggingLeft && !isDraggingRight) return;
        const rect = speedGraphSVG.getBoundingClientRect();
        const usableSize = rect.width - (HANDLE_PADDING * 2 * (rect.width / SVG_WIDTH));

        let pixelsFor100;
        if (graphMode === 'velocity') {
            pixelsFor100 = usableSize * 0.48;
        } else {
            pixelsFor100 = usableSize / dragStartScale;
        }

        const deltaX = (e.clientX - dragStartX) / pixelsFor100 * 100;
        let changeX = isDraggingRight ? -deltaX : deltaX;
        let newValX = Math.max(0.1, Math.min(100, dragStartValX + changeX));

        if (graphMode === 'value') {
            const deltaY = -(e.clientY - dragStartY) / usableSize * dragStartScale;
            if (isDraggingLeft) handleLeftY = dragStartValY + deltaY; else handleRightY = dragStartValY + deltaY;
        }

        const shouldLink = isLocked || e.shiftKey;

        if (isDraggingLeft) {
            sliderOut.value = newValX;
            sliderOut.dispatchEvent(new Event('input'));
            if (shouldLink) {
                sliderIn.value = newValX;
                sliderIn.dispatchEvent(new Event('input'));
                if (graphMode === 'value') handleRightY = handleLeftY;
            }
        } else {
            sliderIn.value = newValX;
            sliderIn.dispatchEvent(new Event('input'));
            if (shouldLink) {
                sliderOut.value = newValX;
                sliderOut.dispatchEvent(new Event('input'));
                if (graphMode === 'value') handleLeftY = handleRightY;
            }
        }
        updateGraphVisuals();
    }
    function stopDrag() {
        isDraggingLeft = false;
        isDraggingRight = false;
        isDraggingCustom = false;
        customDragRef = null;
        document.body.style.cursor = 'default';
    }

    dragGroupLeft.addEventListener('mousedown', startDragLeft);
    dragGroupRight.addEventListener('mousedown', startDragRight);
    window.addEventListener('mousemove', handleDrag);
    window.addEventListener('mouseup', stopDrag);

    // --- 4. PRESETS ---
    function loadData() {
        try {
            const sFav = localStorage.getItem('grapheditorFav_AE');
            if (sFav) favoritesSet = new Set(JSON.parse(sFav));
            const sCust = localStorage.getItem('grapheditorCustomPresets_AE');
            if (sCust) customPresets = JSON.parse(sCust);
            const sOrder = localStorage.getItem('grapheditorOrder_AE');
            let order = sOrder ? JSON.parse(sOrder) : [];

            let baseList = DEFAULT_PRESETS.map(p => ({ ...p, isDefault: true }));
            baseList = baseList.concat(customPresets.map(p => ({ ...p, isDefault: false })));

            if (order.length > 0) {
                allPresets = order.map(id => baseList.find(p => p.id === id)).filter(p => p !== undefined);
                baseList.forEach(p => { if (!order.includes(p.id)) allPresets.push(p); });
            } else { allPresets = baseList; }
            renderPresets();
        } catch (e) { }
    }

    function saveOrder() { localStorage.setItem('grapheditorOrder_AE', JSON.stringify(allPresets.map(p => p.id))); }
    function saveFavs() { localStorage.setItem('grapheditorFav_AE', JSON.stringify([...favoritesSet])); }
    function saveCustoms() { localStorage.setItem('grapheditorCustomPresets_AE', JSON.stringify(allPresets.filter(p => !p.isDefault))); }

    function updatePresetFavToolbar() {
        if (!presetFavToggleBtn) return;
        const on = selectedPresetId && favoritesSet.has(selectedPresetId);
        presetFavToggleBtn.classList.toggle('is-on', !!on);
    }

    function renderPresets() {
        presetsGrid.innerHTML = '';
        const visible = allPresets.filter(function (p) {
            const fam = p.family || 'graph';
            return fam === curveFamily;
        });
        visible.forEach(p => {
            const div = document.createElement('div');
            div.className = 'preset-card' + (p.isDefault ? ' default-preset' : ' custom-preset');
            div.id = p.id; div.draggable = true;
            if (p.id === selectedPresetId) div.classList.add('is-selected');
            if (favoritesSet.has(p.id)) div.classList.add('is-favorite');
            let path;
            if ((p.family || 'graph') === 'graph') {
                path = getStandardizedPath(p.o, p.i, p.vO || 0, p.vI || (graphMode === 'value' ? 1 : 0), graphMode);
            } else {
                const raw = sampleCurvePointsForPreset(p);
                const pp = buildPathFromNormalizedPoints(raw);
                path = pp.dCurve;
            }
            const name = p.customName || p.name;
            div.innerHTML = `<svg class="preset-icon" viewBox="0 0 300 300"><path d="${path}"/></svg>
                <div class="preset-name">${name}</div>`;

            div.addEventListener('click', () => {
                presetsGrid.querySelectorAll('.preset-card').forEach(function (c) { c.classList.remove('is-selected'); });
                div.classList.add('is-selected');
                selectedPresetId = p.id;
                const fam = p.family || 'graph';
                // Switch mode to match preset family
                if (fam !== curveFamily) {
                    curveFamily = fam;
                    document.querySelectorAll('.curve-type-btn').forEach(function (b) {
                        b.classList.toggle('active', b.getAttribute('data-curve') === fam);
                    });
                }
                if (fam === 'graph') {
                    sliderOut.value = p.o; sliderIn.value = p.i;
                    if (graphMode === 'value') { handleLeftY = p.vO || 0; handleRightY = p.vI || 1; }
                } else if (fam === 'elastic' && p.elastic) {
                    specialElastic = { amp: p.elastic.amp, decay: p.elastic.decay };
                } else if (fam === 'bounce' && p.bounce) {
                    specialBounce = { peak: p.bounce.peak, damp: p.bounce.damp };
                } else if (fam === 'step' && p.step) {
                    specialStep = { steps: p.step.steps };
                }
                updatePresetFavToolbar();
                updateGraphVisuals(); applyToAE();
            });
            div.addEventListener('dragstart', () => div.classList.add('is-dragging-item'));
            div.addEventListener('dragend', () => { div.classList.remove('is-dragging-item'); saveOrder(); });
            presetsGrid.appendChild(div);
        });
        updatePresetFavToolbar();
    }

    presetsGrid.addEventListener('dragover', (e) => {
        e.preventDefault();
        const afterElement = getDragAfterElement(presetsGrid, e.clientY);
        const dragging = document.querySelector('.is-dragging-item');
        if (afterElement == null) presetsGrid.appendChild(dragging); else presetsGrid.insertBefore(dragging, afterElement);
    });

    presetsGrid.addEventListener('drop', (e) => {
        e.preventDefault();
        const newOrder = [...presetsGrid.querySelectorAll('.preset-card')].map(c => c.id);
        allPresets = newOrder.map(id => allPresets.find(p => p.id === id));
        saveOrder();
    });

    function getDragAfterElement(container, y) {
        const draggableElements = [...container.querySelectorAll('.preset-card:not(.is-dragging-item)')];
        return draggableElements.reduce((closest, child) => {
            const box = child.getBoundingClientRect();
            const offset = y - box.top - box.height / 2;
            if (offset < 0 && offset > closest.offset) return { offset: offset, element: child };
            else return closest;
        }, { offset: Number.NEGATIVE_INFINITY }).element;
    }

    function applyPresetsCollapsedLayout(collapsed) {
        if (!mainLayout || !primaryColumn) return;
        const horiz = mainLayout.classList.contains('layout-horizontal');
        if (collapsed) {
            mainLayout.classList.add('presets-collapsed');
            mainLayout.classList.remove('has-fixed-split');
            primaryColumn.style.height = '';
            primaryColumn.style.flexBasis = '';
            primaryColumn.style.width = '';
        } else {
            mainLayout.classList.remove('presets-collapsed');
            if (horiz) {
                primaryColumn.style.height = '100%';
                if (userSplitWidthPx != null && userSplitWidthPx > 0) {
                    primaryColumn.style.width = userSplitWidthPx + 'px';
                    primaryColumn.style.flexBasis = userSplitWidthPx + 'px';
                    mainLayout.classList.add('has-fixed-split');
                } else {
                    primaryColumn.style.width = '';
                    primaryColumn.style.flexBasis = '';
                    mainLayout.classList.remove('has-fixed-split');
                }
            } else if (userSplitHeightPx != null && userSplitHeightPx > 0) {
                primaryColumn.style.height = userSplitHeightPx + 'px';
                primaryColumn.style.flexBasis = userSplitHeightPx + 'px';
                mainLayout.classList.add('has-fixed-split');
            } else {
                primaryColumn.style.height = '';
                primaryColumn.style.flexBasis = '';
                mainLayout.classList.remove('has-fixed-split');
            }
        }
    }

    function syncLayoutFromWindow() {
        if (!mainLayout || !primaryColumn || !presetsPanel) return;
        const wide = window.innerWidth >= LAYOUT_THRESHOLD;
        const nextMode = wide ? 'horizontal' : 'vertical';
        if (layoutMode !== nextMode) {
            layoutMode = nextMode;
            primaryColumn.style.height = '';
            primaryColumn.style.flexBasis = '';
            primaryColumn.style.width = '';
            mainLayout.classList.remove('has-fixed-split');
        }
        if (wide) {
            mainLayout.classList.remove('layout-vertical');
            mainLayout.classList.add('layout-horizontal');
            primaryColumn.style.minHeight = '0';
            presetsPanel.style.maxHeight = '';
            if (!presetsPanel.classList.contains('is-collapsed')) {
                if (userSplitWidthPx != null && userSplitWidthPx > 0) {
                    primaryColumn.style.height = '100%';
                    primaryColumn.style.width = userSplitWidthPx + 'px';
                    primaryColumn.style.flexBasis = userSplitWidthPx + 'px';
                    mainLayout.classList.add('has-fixed-split');
                } else {
                    primaryColumn.style.height = '100%';
                    primaryColumn.style.width = '';
                    primaryColumn.style.flexBasis = '';
                }
            } else {
                primaryColumn.style.height = '100%';
            }
        } else {
            mainLayout.classList.add('layout-vertical');
            mainLayout.classList.remove('layout-horizontal');
            if (!presetsPanel.classList.contains('is-collapsed')) {
                if (userSplitHeightPx != null && userSplitHeightPx > 0) {
                    primaryColumn.style.height = userSplitHeightPx + 'px';
                    primaryColumn.style.flexBasis = userSplitHeightPx + 'px';
                    mainLayout.classList.add('has-fixed-split');
                } else {
                    primaryColumn.style.height = '';
                    primaryColumn.style.flexBasis = '';
                }
            }
        }
        if (presetsPanel.classList.contains('is-collapsed')) {
            applyPresetsCollapsedLayout(true);
        } else {
            applyPresetsCollapsedLayout(false);
        }
        updateGraphVisuals();
    }

    // --- 5. PRESETS (Default dropdown) ---
    if (presetsToggle && presetsPanel) {
        presetsToggle.addEventListener('click', () => {
            presetsPanel.classList.toggle('is-collapsed');
            applyPresetsCollapsedLayout(presetsPanel.classList.contains('is-collapsed'));
            setTimeout(updateGraphVisuals, 50);
        });
    }

    // --- 6. KEYFRAME TYPES ---
    function setType(type) {
        csInterface.evalScript(`_GRAPHEDITOR.setKeyframeType('${type}')`, function (result) {
            applyBtn.innerText = result || "OK";
            setTimeout(() => applyBtn.innerText = "APLICAR", 1500);
        });
    }

    /** Easy Ease y presets rápidos: siempre usan influencia temporal (graph), no el hornado elástico/rebote. */
    function applyGraphInfluenceFromSliders() {
        applyBtn.innerText = "APLICANDO...";
        const vOut = (graphMode === 'value') ? handleLeftY : 0;
        const vIn = (graphMode === 'value') ? (handleRightY - 1) : 0;
        csInterface.evalScript('_GRAPHEDITOR.applyInfluence(' + sliderOut.value + ',' + sliderIn.value + ',' + vOut + ',' + vIn + ',\'' + graphMode + '\')', function (result) {
            applyBtn.innerText = result || "APLICADO";
            setTimeout(function () { applyBtn.innerText = "APLICAR"; }, 1800);
        });
    }

    // Listener global para botones de herramientas (Linear, Ease, Hold, etc)
    document.querySelectorAll('.kf-btn').forEach(btn => {
        btn.addEventListener('click', function () {
            if (this.dataset.type) {
                setType(this.dataset.type);
            } else if (this.classList.contains('preset-trigger')) {
                sliderOut.value = this.dataset.out;
                sliderIn.value = this.dataset.in;
                updateGraphVisuals();
                applyGraphInfluenceFromSliders();
            }
        });
    });

    function mapGuideXFromNormalizedU(u) {
        const usableSize = SVG_WIDTH - (HANDLE_PADDING * 2);
        const uc = Math.max(0, Math.min(1, u));
        return HANDLE_PADDING + uc * usableSize;
    }

    function applyGuideSvgX(x) {
        if (!guideLine || !guideDot) return;
        guideLine.setAttribute('x1', x);
        guideLine.setAttribute('x2', x);
        guideDot.setAttribute('cx', x);
    }

    function tickGuideFromAEPlayhead() {
        if (!isGuideEnabled) return;
        csInterface.evalScript('_GRAPHEDITOR.getPlayheadSegmentU()', function (res) {
            if (!isGuideEnabled) return;
            let x = SVG_WIDTH / 2;
            let ok = false;
            try {
                const raw = (res === undefined || res === null) ? '' : String(res);
                if (raw && raw.indexOf('EvalScript error') !== -1) {
                    applyGuideSvgX(x);
                    if (guideLine) guideLine.style.opacity = '0.35';
                    if (guideDot) guideDot.style.opacity = '0.35';
                    return;
                }
                const d = JSON.parse(raw);
                if (d && d.found && typeof d.u === 'number' && !isNaN(d.u)) {
                    x = mapGuideXFromNormalizedU(d.u);
                    ok = true;
                }
            } catch (e) { }
            applyGuideSvgX(x);
            if (guideLine) {
                guideLine.style.opacity = ok ? '1' : '0.35';
            }
            if (guideDot) {
                guideDot.style.opacity = ok ? '1' : '0.35';
            }
        });
    }

    function setGuideVisibility(on) {
        isGuideEnabled = !!on;
        if (playheadGuideTimer) {
            clearInterval(playheadGuideTimer);
            playheadGuideTimer = null;
        }
        if (!guideLine || !guideDot) return;
        guideLine.style.display = isGuideEnabled ? 'block' : 'none';
        guideDot.style.display = isGuideEnabled ? 'block' : 'none';
        if (guideBtn) guideBtn.classList.toggle('is-active', isGuideEnabled);

        if (isGuideEnabled) {
            tickGuideFromAEPlayhead();
            playheadGuideTimer = setInterval(tickGuideFromAEPlayhead, 60);
        } else {
            guideLine.style.opacity = '1';
            guideDot.style.opacity = '1';
        }
    }

    window.addEventListener('beforeunload', function () {
        if (playheadGuideTimer) {
            clearInterval(playheadGuideTimer);
            playheadGuideTimer = null;
        }
    });

    // --- 7. AE STUFF ---
    function applyToAE() {
        applyBtn.innerText = "APLICANDO...";
        if (curveFamily === 'graph') {
            const vOut = (graphMode === 'value') ? handleLeftY : 0;
            const vIn = (graphMode === 'value') ? (handleRightY - 1) : 0;
            csInterface.evalScript(`_GRAPHEDITOR.applyInfluence(${sliderOut.value}, ${sliderIn.value}, ${vOut}, ${vIn}, '${graphMode}')`, function (result) {
                applyBtn.innerText = result || "APLICADO";
                setTimeout(() => applyBtn.innerText = "APLICAR", 2000);
            });
        } else {
            const raw = sampleSpecialCurvePoints();
            let pts = buildBakePointsFromSamples(raw);
            pts = normalizeBakeEndpoints(pts);
            pts = downsampleBakePoints(pts, BAKE_MAX_INTERIOR);
            const payload = { type: curveFamily, points: pts };
            if (curveFamily === 'elastic') payload.params = { amp: specialElastic.amp, decay: specialElastic.decay };
            if (curveFamily === 'bounce') payload.params = { peak: specialBounce.peak, damp: specialBounce.damp };
            if (curveFamily === 'step') payload.params = { steps: specialStep.steps };
            // custom removed
            const inner = JSON.stringify(payload);
            const cmd = '_GRAPHEDITOR.applyExpressionSegment(' + JSON.stringify(inner) + ')';
            csInterface.evalScript(cmd, function (result) {
                const r = (result || '').toString();
                if (r.indexOf('OK:') === 0) {
                    const n = parseInt(r.slice(3), 10);
                    applyBtn.innerText = (isNaN(n) || n < 1) ? "NO APLICÓ" : "APLICADO";
                } else {
                    applyBtn.innerText = r || "ERROR";
                    // hint rápido para cuando el host JSX no se recargó
                    if (r.indexOf('EvalScript') !== -1 || r.indexOf('ERR:') === 0) {
                        setTimeout(() => { applyBtn.innerText = "RECARGA PANEL"; }, 1200);
                    }
                }
                setTimeout(() => { applyBtn.innerText = "APLICAR"; }, 2200);
            });
        }
    }

    copyBtn.addEventListener('click', () => {
        // Prefer: detect GraphEditor expression (elastic/bounce/step/custom).
        // Fallback: Graph influences (velocity/value) if no expr was found.

        function setFamilyUI(fam) {
            curveFamily = fam;
            document.querySelectorAll('.curve-type-btn').forEach(function (b) {
                b.classList.toggle('active', b.getAttribute('data-curve') === fam);
            });
        }

        function copyGraphInfluences() {
            setFamilyUI('graph');
            csInterface.evalScript('_GRAPHEDITOR.getSelectedInfluences()', (result) => {
                try {
                    const data = JSON.parse(result);
                    if (data.found) {
                        sliderOut.value = data.outVal; sliderIn.value = data.inVal;
                        if (graphMode === 'value') { handleLeftY = data.slopeOut * (data.outVal / 100); handleRightY = (data.slopeIn * (data.inVal / 100)) + 1; }
                        updateGraphVisuals();
                        renderPresets();
                    } else {
                        applyBtn.innerText = 'NO KEYS';
                        setTimeout(() => { applyBtn.innerText = "APLICAR"; }, 1200);
                    }
                } catch (e) {
                    applyBtn.innerText = 'RECARGA';
                    setTimeout(() => { applyBtn.innerText = "APLICAR"; }, 1200);
                }
            });
        }

        csInterface.evalScript('_GRAPHEDITOR.getSelectedCurveFromExpression()', (result) => {
            let data = null;
            try { data = JSON.parse(result); } catch (e0) { data = null; }

            if (!data || !data.found) {
                // If it's not one of our special curves, treat it as Graph.
                copyGraphInfluences();
                return;
            }

            if (data && data.expressionEnabled === false) {
                applyBtn.innerText = 'EXPR OFF';
                setTimeout(() => { applyBtn.innerText = "APLICAR"; }, 1200);
            }

            const famRaw = (data.type || '').toString().toLowerCase();
            const fam = (famRaw === 'elastic' || famRaw === 'bounce' || famRaw === 'step') ? famRaw : 'graph';

            if (fam === 'graph') {
                copyGraphInfluences();
                return;
            }

            // Auto-switch tab to detected family
            setFamilyUI(fam);

            if (fam === 'elastic' && data.params) {
                specialElastic = { amp: data.params.amp, decay: data.params.decay };
            } else if (fam === 'bounce' && data.params) {
                specialBounce = { peak: data.params.peak, damp: data.params.damp };
            } else if (fam === 'step' && data.params) {
                specialStep = { steps: data.params.steps };
                }

            updateGraphVisuals();
            renderPresets();
        });
    });

    applyBtn.addEventListener('click', applyToAE);
    btnModeVel.addEventListener('click', () => {
        graphMode = 'velocity';
        btnModeVel.classList.add('active');
        btnModeVal.classList.remove('active');
        updateGraphVisuals();
        renderPresets();
    });
    btnModeVal.addEventListener('click', () => {
        graphMode = 'value';
        btnModeVal.classList.add('active');
        btnModeVel.classList.remove('active');
        handleRightY = 1;
        updateGraphVisuals();
        renderPresets();
    });

    // New buttons
    if (reverseBtn) {
        reverseBtn.addEventListener('click', () => {
            const o = parseFloat(sliderOut.value);
            const i = parseFloat(sliderIn.value);
            sliderOut.value = i;
            sliderIn.value = o;

            if (graphMode === 'value') {
                const tmpY = handleLeftY;
                handleLeftY = handleRightY - 1;
                handleRightY = tmpY + 1;
            }

            updateGraphVisuals();
            applyToAE();
        });
    }

    if (guideBtn) {
        guideBtn.addEventListener('click', () => {
            setGuideVisibility(!isGuideEnabled);
        });
    }

    function setFavoritesFilterOnly(on) {
        presetsGrid.classList.toggle('showing-favorites-only', on);
        if (presetFilterAll) presetFilterAll.classList.toggle('active', !on);
        if (presetFilterFav) presetFilterFav.classList.toggle('active', on);
    }

    if (presetFilterAll) {
        presetFilterAll.addEventListener('click', function () { setFavoritesFilterOnly(false); });
    }
    if (presetFilterFav) {
        presetFilterFav.addEventListener('click', function () { setFavoritesFilterOnly(true); });
    }

    function showPresetNameModal(defaultValue) {
        return new Promise(function (resolve) {
            var overlay = document.getElementById('presetNameModal');
            var input = document.getElementById('presetNameInput');
            var okBtn = document.getElementById('presetNameOk');
            var cancelBtn = document.getElementById('presetNameCancel');
            if (!overlay || !input || !okBtn || !cancelBtn) {
                resolve(null);
                return;
            }
            function close(val) {
                overlay.classList.remove('is-open');
                overlay.setAttribute('aria-hidden', 'true');
                document.removeEventListener('keydown', onKey);
                okBtn.removeEventListener('click', onOk);
                cancelBtn.removeEventListener('click', onCancel);
                overlay.removeEventListener('click', onOverlayClick);
                resolve(val);
            }
            function onOk() {
                var v = (input.value || '').trim();
                close(v || null);
            }
            function onCancel() {
                close(null);
            }
            function onOverlayClick(e) {
                if (e.target === overlay) onCancel();
            }
            function onKey(e) {
                if (e.key === 'Escape') {
                    e.preventDefault();
                    onCancel();
                }
                if (e.key === 'Enter' && document.activeElement === input) {
                    e.preventDefault();
                    onOk();
                }
            }
            input.value = defaultValue != null ? defaultValue : 'Preset';
            overlay.classList.add('is-open');
            overlay.setAttribute('aria-hidden', 'false');
            okBtn.addEventListener('click', onOk);
            cancelBtn.addEventListener('click', onCancel);
            overlay.addEventListener('click', onOverlayClick);
            document.addEventListener('keydown', onKey);
            setTimeout(function () {
                input.focus();
                input.select();
            }, 10);
        });
    }

    if (addPresetBtn) {
        addPresetBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            showPresetNameModal('Preset').then(function (name) {
                if (!name) return;
                const id = 'cust_' + Date.now();
                let p;
                if (curveFamily === 'graph') {
                    p = {
                        id: id,
                        family: 'graph',
                        name: name,
                        o: sliderOut.value,
                        i: sliderIn.value,
                        vO: handleLeftY,
                        vI: handleRightY,
                        isDefault: false
                    };
                } else if (curveFamily === 'elastic') {
                    p = {
                        id: id,
                        family: 'elastic',
                        name: name,
                        elastic: { amp: specialElastic.amp, decay: specialElastic.decay },
                        isDefault: false
                    };
                } else if (curveFamily === 'bounce') {
                    p = {
                        id: id,
                        family: 'bounce',
                        name: name,
                        bounce: { peak: specialBounce.peak, damp: specialBounce.damp },
                        isDefault: false
                    };
                } else if (curveFamily === 'step') {
                    p = {
                        id: id,
                        family: 'step',
                        name: name,
                        step: { steps: specialStep.steps },
                        isDefault: false
                    };
                } else {
                    p = {
                        id: id,
                        family: curveFamily,
                        name: name,
                        isDefault: false
                    };
                }
                allPresets.push(p);
                selectedPresetId = p.id;
                saveCustoms();
                renderPresets();
            });
        });
    }

    if (removePresetBtn) {
        removePresetBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            if (!selectedPresetId) {
                applyBtn.innerText = "SELECCIONA";
                setTimeout(function () { applyBtn.innerText = "APLICAR"; }, 1600);
                return;
            }
            const p = allPresets.find(function (x) { return x.id === selectedPresetId; });
            if (!p || p.isDefault) {
                applyBtn.innerText = "DEFAULT";
                setTimeout(function () { applyBtn.innerText = "APLICAR"; }, 1600);
                return;
            }
            allPresets = allPresets.filter(function (pr) { return pr.id !== selectedPresetId; });
            if (favoritesSet.has(selectedPresetId)) {
                favoritesSet.delete(selectedPresetId);
                saveFavs();
            }
            selectedPresetId = null;
            saveCustoms();
            saveOrder();
            renderPresets();
        });
    }

    if (presetFavToggleBtn) {
        presetFavToggleBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            if (!selectedPresetId) {
                applyBtn.innerText = "SELECCIONA";
                setTimeout(function () { applyBtn.innerText = "APLICAR"; }, 1600);
                return;
            }
            if (favoritesSet.has(selectedPresetId)) favoritesSet.delete(selectedPresetId);
            else favoritesSet.add(selectedPresetId);
            saveFavs();
            renderPresets();
            applyBtn.innerText = favoritesSet.has(selectedPresetId) ? "FAVORITO ✓" : "FAVORITO ✕";
            setTimeout(function () { applyBtn.innerText = "APLICAR"; }, 1400);
        });
    }

    document.querySelectorAll('.curve-type-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
            const c = btn.getAttribute('data-curve');
            if (!c) return;
            curveFamily = c;
            document.querySelectorAll('.curve-type-btn').forEach(function (b) {
                b.classList.toggle('active', b.getAttribute('data-curve') === c);
            });
            if (modeSelectorRow) {
                modeSelectorRow.classList.remove('mode-locked-value');
            }
            if (graphContainer) {
                graphContainer.title = '';
            }
            updateGraphVisuals();
            renderPresets();
        });
    });

    // --- 8. RESIZE (Graph vs Presets) ---
    if (resizeGutter && primaryColumn && mainLayout) {
        resizeGutter.addEventListener('mousedown', () => {
            isDraggingGutter = true;
            resizeGutter.classList.add('is-dragging');
        });
        window.addEventListener('mousemove', (e) => {
            if (!isDraggingGutter) return;
            if (presetsPanel && presetsPanel.classList.contains('is-collapsed')) return;
            const horiz = mainLayout.classList.contains('layout-horizontal');
            if (horiz) {
                const rect = mainLayout.getBoundingClientRect();
                let newW = e.clientX - rect.left - 6;
                const minW = 200;
                const maxW = Math.max(minW + 40, rect.width - 140);
                newW = Math.max(minW, Math.min(maxW, newW));
                userSplitWidthPx = newW;
                primaryColumn.style.height = '100%';
                primaryColumn.style.width = newW + 'px';
                primaryColumn.style.flexBasis = newW + 'px';
                mainLayout.classList.add('has-fixed-split');
            } else {
                const rect = mainLayout.getBoundingClientRect();
                let newH = e.clientY - rect.top - 6;
                const minH = 160;
                const maxH = Math.max(minH + 80, rect.height - 72);
                newH = Math.max(minH, Math.min(maxH, newH));
                userSplitHeightPx = newH;
                primaryColumn.style.height = newH + 'px';
                primaryColumn.style.flexBasis = newH + 'px';
                mainLayout.classList.add('has-fixed-split');
            }
            updateGraphVisuals();
        });
        window.addEventListener('mouseup', () => {
            if (!isDraggingGutter) return;
            isDraggingGutter = false;
            resizeGutter.classList.remove('is-dragging');
        });
    }

    let resizeTimer = null;
    window.addEventListener('resize', function () {
        if (resizeTimer) clearTimeout(resizeTimer);
        resizeTimer = setTimeout(syncLayoutFromWindow, 80);
    });

    // Fallback: keep sliders in state even if hidden/removed (no linking)
    if (sliderOut) sliderOut.addEventListener('input', () => { updateGraphVisuals(); });
    if (sliderIn) sliderIn.addEventListener('input', () => { updateGraphVisuals(); });

    loadData();
    setFavoritesFilterOnly(false);
    syncLayoutFromWindow();

})();