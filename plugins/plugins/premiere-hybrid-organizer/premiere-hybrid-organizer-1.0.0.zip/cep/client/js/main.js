// PR Hybrid Organizer — cliente principal
// Flujo: Organizar panel (PR Organizer) -> Consolidar medios a la carpeta del
// proyecto (File Manager). Regla: lo que está en Descargas se MUEVE; lo demás
// se COPIA (para preservar plantillas).

const csInterface = new CSInterface();

// Node modules (mixed-context + enable-nodejs)
const fm_os = require('os');
const fm_path = require('path');
const fm_fs = require('fs');

// fileOperations.js (cargado antes que este script)
const FOP = (typeof module !== 'undefined' && module.exports) ? module.exports : window;

let exportFiles = [];   // archivos externos detectados Y DISPONIBLES (op: move|copy)
let offlineFiles = [];  // externos cuyo archivo de origen ya no existe (sin conexión)
let rawExternalCount = 0; // total de externos antes de filtrar offline
let lastTotalFiles = 0;

// ───────────────────────────────────────────────────────── Settings ────────
const DEFAULT_SETTINGS = {
  levels: 0,
  rootFolder: '',
  masterKeyword: 'master',
  moveFolders: '',        // texto crudo del textarea (rutas/nombres por línea)
  excludedFolders: '',    // bins excluidos, uno por línea
  autoRelink: true,
  organizeOnAnalyze: true
};
let settings = Object.assign({}, DEFAULT_SETTINGS);

function settingsDir() {
  const platform = fm_os.platform();
  if (platform === 'darwin') {
    return fm_path.join(fm_os.homedir(), 'Library', 'Application Support', 'PremiereHybridOrganizer');
  }
  return fm_path.join(process.env.APPDATA || fm_os.homedir(), 'PremiereHybridOrganizer');
}
function settingsFile() { return fm_path.join(settingsDir(), 'settings.json'); }

function loadSettings() {
  try {
    const f = settingsFile();
    if (fm_fs.existsSync(f)) {
      const data = JSON.parse(fm_fs.readFileSync(f, 'utf8'));
      settings = Object.assign({}, DEFAULT_SETTINGS, data);
    }
  } catch (e) { log('No se pudo leer config: ' + e.message); }
  applySettingsToUI();
}

function saveSettings() {
  readSettingsFromUI();
  try {
    const dir = settingsDir();
    if (!fm_fs.existsSync(dir)) fm_fs.mkdirSync(dir, { recursive: true });
    fm_fs.writeFileSync(settingsFile(), JSON.stringify(settings, null, 2), 'utf8');
    showStatus('Configuración guardada', 'success');
  } catch (e) {
    showStatus('Error guardando config: ' + e.message, 'error');
  }
  closeSettings();
}

function applySettingsToUI() {
  document.getElementById('setLevels').value = settings.levels;
  document.getElementById('setRoot').value = settings.rootFolder;
  document.getElementById('setMasterKeyword').value = settings.masterKeyword;
  document.getElementById('setMoveFolders').value = settings.moveFolders;
  document.getElementById('setExcluded').value = settings.excludedFolders;
  document.getElementById('setAutoRelink').checked = !!settings.autoRelink;
  document.getElementById('setOrganizeOnAnalyze').checked = !!settings.organizeOnAnalyze;
}

function readSettingsFromUI() {
  settings.levels = parseInt(document.getElementById('setLevels').value, 10) || 0;
  settings.rootFolder = document.getElementById('setRoot').value.trim();
  settings.masterKeyword = document.getElementById('setMasterKeyword').value.trim() || 'master';
  settings.moveFolders = document.getElementById('setMoveFolders').value;
  settings.excludedFolders = document.getElementById('setExcluded').value;
  settings.autoRelink = document.getElementById('setAutoRelink').checked;
  settings.organizeOnAnalyze = document.getElementById('setOrganizeOnAnalyze').checked;
}

// Convierte el textarea de "carpetas a mover" en { folderPaths, folderNames }.
function buildMoveConfig() {
  const lines = (settings.moveFolders || '').split(/\r?\n/).map(s => s.trim()).filter(Boolean);
  const folderPaths = [];
  const folderNames = [];
  lines.forEach(line => {
    if (line.indexOf('/') >= 0 || line.indexOf('\\') >= 0 || /^[a-zA-Z]:/.test(line)) {
      folderPaths.push(line);
    } else {
      folderNames.push(line);
    }
  });
  return { folderPaths, folderNames };
}

function excludedFoldersArray() {
  return (settings.excludedFolders || '').split(/\r?\n/).map(s => s.trim()).filter(Boolean);
}

// ───────────────────────────────────────────────────────── Helpers UI ──────
function showStatus(msg, type) {
  const el = document.getElementById('status');
  el.textContent = msg;
  el.className = 'status ' + (type || '');
}
function log(msg) {
  const el = document.getElementById('log');
  const ts = new Date().toISOString().substr(11, 8);
  el.textContent += `[${ts}] ${msg}\n`;
  el.scrollTop = el.scrollHeight;
}
function showProgress(label) {
  document.getElementById('progressBox').style.display = 'block';
  document.getElementById('progressLabel').textContent = label || 'Procesando…';
  setProgress(0, '');
}
function setProgress(pct, sub) {
  document.getElementById('progressFill').style.width = pct + '%';
  document.getElementById('progressSub').textContent = sub || '';
}
function hideProgress() {
  setTimeout(() => { document.getElementById('progressBox').style.display = 'none'; }, 800);
}

// Escapa backslashes para inyectar rutas en evalScript con seguridad.
function esc(s) { return (s || '').replace(/\\/g, '\\\\'); }

// ───────────────────────────────────────────────────────── Proyecto ────────
function getProjectInfo() {
  csInterface.evalScript(`FileManager_getProjectInfo(${settings.levels})`, (result) => {
    let info;
    try { info = JSON.parse(result); } catch (e) { info = { error: 'parse' }; }
    const dot = document.getElementById('projDot');
    const txt = document.getElementById('projText');
    if (info && info.name) {
      dot.className = 'dot online';
      txt.textContent = info.name + (info.rootPath ? '  ·  raíz: ' + shortPath(info.rootPath) : '');
    } else {
      dot.className = 'dot offline';
      txt.textContent = 'Abre un proyecto para empezar…';
    }
  });
}
function shortPath(p) {
  if (!p) return '';
  const parts = p.replace(/\\/g, '/').split('/');
  return parts.length > 2 ? '…/' + parts.slice(-2).join('/') : p;
}

// ───────────────────────────────────────────────── Solo organizar ──────────
function organizeOnly() {
  const btn = document.getElementById('organizeOnlyBtn');
  btn.disabled = true;
  showStatus('Organizando panel…', '');
  runOrganize((res) => {
    btn.disabled = false;
    if (res.status === 'OK') {
      showStatus(`Panel organizado · ${res.moved} ítems, ${res.deleted} bins vacíos borrados`, 'success');
    } else {
      showStatus('Error organizando: ' + (res.message || ''), 'error');
    }
    getProjectInfo();
  });
}

function runOrganize(cb) {
  const kw = settings.masterKeyword || 'master';
  csInterface.evalScript(`HybridOrganizer_organizeProject("${esc(kw)}")`, (raw) => {
    let res; try { res = JSON.parse(raw); } catch (e) { res = { status: 'ERROR', message: raw }; }
    if (res.log) log('--- ORGANIZAR ---\n' + res.log);
    cb(res);
  });
}

// ───────────────────────────────────────────────── Analizar ────────────────
function analyze() {
  const btn = document.getElementById('analyzeBtn');
  btn.disabled = true;
  resetResults();

  const doScan = () => {
    showStatus('Buscando archivos externos…', '');
    const rootArg = settings.rootFolder ? `"${esc(settings.rootFolder)}"` : `''`;
    const excluded = JSON.stringify(excludedFoldersArray());
    const script = `FileManager_getFilesToSync(${rootArg}, '${excluded}', ${settings.levels})`;

    csInterface.evalScript(script, (result) => {
      let data; try { data = JSON.parse(result); } catch (e) { data = { error: 'parse: ' + result }; }
      if (data.error) {
        btn.disabled = false;
        showStatus('Error: ' + data.error, 'error');
        return;
      }

      const moveConfig = buildMoveConfig();
      const all = data.filesToSync || [];
      rawExternalCount = all.length;
      exportFiles = [];
      offlineFiles = [];
      all.forEach(f => {
        const isMove = FOP.fm_isMoveSource(f.currentPath, moveConfig);
        const item = Object.assign({}, f, { op: isMove ? 'move' : 'copy' });
        // Si el archivo de origen ya no existe, es un clip SIN CONEXIÓN:
        // no se puede mover ni copiar, así que no va a la lista accionable.
        if (FOP.fileExists(f.currentPath)) {
          exportFiles.push(item);
        } else {
          offlineFiles.push(item);
        }
      });
      if (offlineFiles.length > 0) {
        log(`${offlineFiles.length} archivo(s) sin conexión (origen inexistente) — omitidos:`);
        offlineFiles.forEach(o => log('   ⚠ ' + o.name + '  ·  ' + o.currentPath));
      }

      // Total de archivos del proyecto, para mostrar "ya en proyecto".
      csInterface.evalScript('analyzeProject()', (ar) => {
        let a; try { a = JSON.parse(ar); } catch (e) { a = {}; }
        lastTotalFiles = a.totalFiles || 0;
        renderResults();
        btn.disabled = false;
      });
    });
  };

  if (settings.organizeOnAnalyze) {
    showStatus('Organizando panel…', '');
    runOrganize((res) => {
      if (res.status !== 'OK') log('Aviso: organizar devolvió ' + (res.message || 'error'));
      getProjectInfo();
      doScan();
    });
  } else {
    doScan();
  }
}

function resetResults() {
  document.getElementById('summary').style.display = 'none';
  document.getElementById('listCard').style.display = 'none';
  document.getElementById('fileList').innerHTML = '';
}

function renderResults() {
  const moveN = exportFiles.filter(f => f.op === 'move').length;
  const copyN = exportFiles.filter(f => f.op === 'copy').length;
  const offlineN = offlineFiles.length;
  // "Ya en proyecto" = total del proyecto menos TODOS los externos (incl. offline).
  const insideN = Math.max(0, lastTotalFiles - rawExternalCount);

  document.getElementById('moveCount').textContent = moveN;
  document.getElementById('copyCount').textContent = copyN;
  document.getElementById('insideCount').textContent = insideN;
  document.getElementById('offlineCount').textContent = offlineN;
  document.getElementById('offlineStat').style.display = offlineN > 0 ? 'inline' : 'none';
  document.getElementById('summary').style.display = 'flex';

  const list = document.getElementById('fileList');
  list.innerHTML = '';

  // Sección informativa de archivos sin conexión (no accionables).
  if (offlineN > 0) {
    const note = document.createElement('div');
    note.className = 'offline-note';
    note.innerHTML = `<b>⚠ ${offlineN} sin conexión</b> — el archivo de origen ya no existe, ` +
      `no se pueden consolidar. Re-enlázalos o quítalos del proyecto en Premiere.`;
    list.appendChild(note);
    offlineFiles.forEach(f => {
      const row = document.createElement('div');
      row.className = 'file-item offline';
      row.innerHTML = `
        <div class="file-meta">
          <div class="file-name"><span class="badge offline">OFFLINE</span> ${escapeHtml(f.name)}</div>
          <div class="file-path">${escapeHtml(shortPath(f.currentPath))}</div>
        </div>`;
      list.appendChild(row);
    });
  }

  if (exportFiles.length === 0) {
    document.getElementById('listCard').style.display = 'block';
    document.getElementById('consolidateBtn').style.display = 'none';
    if (offlineN === 0) {
      list.innerHTML = '<div class="empty-state">No hay archivos externos. Todo está dentro de la carpeta del proyecto. ✓</div>';
      showStatus('Nada que consolidar', 'success');
    } else {
      showStatus(`Nada consolidable · ${offlineN} sin conexión (omitidos)`, 'warning');
    }
    return;
  }

  exportFiles.forEach((f, i) => {
    const row = document.createElement('div');
    row.className = 'file-item';
    const badge = f.op === 'move'
      ? '<span class="badge move">MOVER</span>'
      : '<span class="badge copy">COPIAR</span>';
    row.innerHTML = `
      <input type="checkbox" id="cf-${i}" checked>
      <div class="file-meta">
        <div class="file-name">${badge} ${escapeHtml(f.name)}</div>
        <div class="file-path">${escapeHtml(shortPath(f.currentPath))} <span class="arrow">→</span> ${escapeHtml(f.binPath || 'Raíz')}/</div>
      </div>`;
    list.appendChild(row);
  });

  document.getElementById('consolidateBtn').style.display = 'block';
  document.getElementById('listCard').style.display = 'block';
  let msg = `${moveN} a mover · ${copyN} a copiar`;
  if (offlineN > 0) msg += ` · ${offlineN} sin conexión`;
  showStatus(msg, 'success');
}

function escapeHtml(t) {
  const d = document.createElement('div');
  d.textContent = t == null ? '' : t;
  return d.innerHTML;
}

// ───────────────────────────────────────────────── Consolidar ──────────────
async function consolidate() {
  const selected = exportFiles.filter((_, i) => {
    const cb = document.getElementById('cf-' + i);
    return cb && cb.checked;
  });
  if (selected.length === 0) { showStatus('No hay archivos seleccionados', 'warning'); return; }

  const btn = document.getElementById('consolidateBtn');
  btn.disabled = true;

  const moveSel = selected.filter(f => f.op === 'move');
  // Si auto-relink está apagado, mover dejaría el medio offline -> se trata como copia.
  const willMove = settings.autoRelink && moveSel.length > 0;
  if (!settings.autoRelink && moveSel.length > 0) {
    log('Auto-relink desactivado: los archivos de Descargas se COPIARÁN (no se borran) para no dejar medios offline.');
  }

  showProgress('Copiando archivos…');

  const filesToCopy = selected.map(f => ({
    name: f.name, source: f.currentPath, destination: f.targetPath, op: f.op
  }));

  try {
    const startTime = Date.now();
    const results = await FOP.copyFiles(filesToCopy, (p) => {
      setProgress(p.percent, `${p.current}/${p.total} · ${filesToCopy[p.current - 1] ? filesToCopy[p.current - 1].name : ''}`);
    });
    log(`Copia: ${(Date.now() - startTime) / 1000}s`);

    // Re-enlazar en Premiere lo que se copió/ya existía.
    let relinkOkByDest = {};
    if (settings.autoRelink) {
      setProgress(100, 'Re-enlazando medios…');
      document.getElementById('progressLabel').textContent = 'Re-enlazando medios…';

      const relinkList = [];
      results.forEach((r, i) => {
        const f = filesToCopy[i];
        const usable = (r.success || r.skipped);
        if (usable && FOP.fileExists(f.destination)) {
          relinkList.push({ name: r.name, oldPath: esc(f.source), newPath: esc(f.destination), _dest: f.destination });
        }
      });

      if (relinkList.length > 0) {
        const payload = relinkList.map(r => ({ name: r.name, oldPath: r.oldPath, newPath: r.newPath }));
        await new Promise((resolve) => {
          csInterface.evalScript(`FileManager_batchRelinkMedia('${JSON.stringify(payload)}')`, (res) => {
            try {
              const parsed = JSON.parse(res);
              (parsed.results || []).forEach((rr, idx) => {
                // rr.success puede venir como string JSON desde el host; normalizamos.
                let ok = rr.success;
                if (typeof ok === 'string') { try { ok = JSON.parse(ok).success; } catch (e) {} }
                if (ok) relinkOkByDest[relinkList[idx]._dest] = true;
              });
            } catch (e) { log('Relink parse: ' + e.message); }
            resolve();
          });
        });
      }
    }

    // Borrar orígenes SOLO de los MOVER que: se copiaron bien, se re-enlazaron y
    // el destino coincide en tamaño con el origen.
    let deletedCount = 0;
    if (willMove) {
      const toDelete = [];
      results.forEach((r, i) => {
        const f = filesToCopy[i];
        if (f.op !== 'move') return;
        const copiedOk = r.success || r.skipped;
        const relinked = relinkOkByDest[f.destination] === true;
        if (copiedOk && relinked && FOP.fm_safeToDeleteSource(f.source, f.destination)) {
          toDelete.push(f.source);
        } else if (copiedOk && !relinked) {
          log(`No se borra origen (relink falló): ${f.name}`);
        }
      });
      if (toDelete.length > 0) {
        const delRes = FOP.fm_deleteSources(toDelete);
        deletedCount = delRes.filter(d => d.deleted).length;
      }
    }

    setProgress(100, 'Listo');
    hideProgress();

    const ok = results.filter(r => r.success).length;
    const skipped = results.filter(r => r.skipped).length;
    const failed = results.filter(r => !r.success).length;

    let msg = `Consolidado: ${ok} copiados`;
    if (deletedCount > 0) msg += ` · ${deletedCount} movidos (origen borrado)`;
    if (skipped > 0) msg += ` · ${skipped} ya existían`;
    if (failed > 0) msg += ` · ${failed} con error`;
    showStatus(msg, failed > 0 ? 'warning' : 'success');
    log(msg);

    btn.disabled = false;
    setTimeout(analyze, 600); // refrescar
  } catch (e) {
    showStatus('Error al consolidar: ' + e.message, 'error');
    log('ERROR: ' + e.message);
    hideProgress();
    btn.disabled = false;
  }
}

// ───────────────────────────────────────────────── Settings UI ─────────────
function openSettings() { document.getElementById('settingsOverlay').style.display = 'flex'; }
function closeSettings() { document.getElementById('settingsOverlay').style.display = 'none'; }
function browseRoot() {
  csInterface.evalScript('FileManager_selectFolder()', (res) => {
    if (res && res !== 'null') document.getElementById('setRoot').value = res;
  });
}

// ───────────────────────────────────────────────── Init ────────────────────
document.addEventListener('DOMContentLoaded', () => {
  // Conectar el log de fileOperations al panel.
  if (FOP.fm_setLogCallback) FOP.fm_setLogCallback((m) => log(m));

  // Cargar host JSX explícitamente (además del ScriptPath del manifest).
  try {
    const ext = csInterface.getSystemPath(SystemPath.EXTENSION);
    csInterface.evalScript(`$.evalFile("${ext}/host/index.jsx")`, () => {});
  } catch (e) {}

  loadSettings();
  getProjectInfo();

  document.getElementById('organizeOnlyBtn').addEventListener('click', organizeOnly);
  document.getElementById('analyzeBtn').addEventListener('click', analyze);
  document.getElementById('consolidateBtn').addEventListener('click', consolidate);

  document.getElementById('settingsBtn').addEventListener('click', openSettings);
  document.getElementById('closeSettings').addEventListener('click', closeSettings);
  document.getElementById('saveSettings').addEventListener('click', saveSettings);
  document.getElementById('browseRoot').addEventListener('click', browseRoot);

  document.getElementById('selAll').addEventListener('click', () => {
    document.querySelectorAll('#fileList input[type="checkbox"]').forEach(cb => cb.checked = true);
  });
  document.getElementById('selNone').addEventListener('click', () => {
    document.querySelectorAll('#fileList input[type="checkbox"]').forEach(cb => cb.checked = false);
  });

  const lt = document.getElementById('logToggle');
  lt.addEventListener('click', () => {
    const el = document.getElementById('log');
    const open = el.style.display !== 'none';
    el.style.display = open ? 'none' : 'block';
    lt.textContent = (open ? '▸' : '▾') + ' Ver log detallado';
  });

  // Refrescar info del proyecto al cambiar de proyecto/secuencia.
  try {
    csInterface.addEventListener('com.adobe.csxs.events.ApplicationActivate', getProjectInfo);
  } catch (e) {}
});
