// hostscript.jsx - ExtendScript Premiere Pro - v6.3.0
// =====================================================================
// v6.3.0 CAMBIOS:
// - Smart Zoom: detecta clip vs secuencia y aplica Scale automatico
// - ppManualRotation(degrees): rotacion manual con zoom inteligente
// - ppApplyFix ahora tambien aplica zoom inteligente a cada segmento
// =====================================================================

function ppGetClipInfo() {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return '{"err":"Sin secuencia activa"}';
        var vc = null, vti = -1;

        outer1: for (var t = 0; t < seq.videoTracks.numTracks; t++) {
            var tr = seq.videoTracks[t];
            for (var c = 0; c < tr.clips.numItems; c++) {
                try {
                    if (tr.clips[c].isSelected()) { vc = tr.clips[c]; vti = t; break outer1; }
                } catch(e2) {}
            }
        }

        if (!vc) {
            try {
                var sel = seq.getSelection();
                for (var i = 0; i < sel.length; i++) {
                    if (sel[i].mediaType === "Video") { vc = sel[i]; break; }
                }
            } catch(e1) {}
            if (vc) {
                var vs = vc.start.seconds, ve = vc.end.seconds;
                outer2: for (var t2 = 0; t2 < seq.videoTracks.numTracks; t2++) {
                    var tr2 = seq.videoTracks[t2];
                    for (var c2 = 0; c2 < tr2.clips.numItems; c2++) {
                        var cl = tr2.clips[c2];
                        if (Math.abs(cl.start.seconds-vs)<0.05 && Math.abs(cl.end.seconds-ve)<0.05) {
                            vti = t2; vc = cl; break outer2;
                        }
                    }
                }
            }
        }

        if (!vc) return '{"err":"Selecciona un clip de VIDEO en el timeline"}';
        if (vti===-1) return '{"err":"Pista no identificada. Haz click directo sobre el clip."}';

        var mp = "";
        try { mp = vc.projectItem.getMediaPath(); } catch(ep) {}

        var fps = 24;
        try { fps = 1.0 / seq.getSettings().videoFrameRate.seconds; } catch(ef) {}

        return '{"mediaPath":"'+mp.replace(/\\/g,'\\\\').replace(/"/g,'\\"')+'"'
            +',"clipStart":'+vc.start.seconds+',"clipEnd":'+vc.end.seconds
            +',"clipIn":'+vc.inPoint.seconds+',"clipOut":'+vc.outPoint.seconds
            +',"trackIdx":'+vti+',"seqW":'+seq.frameSizeHorizontal+',"seqH":'+seq.frameSizeVertical
            +',"fps":'+fps+'}';
    } catch(e) { return '{"err":"'+e.toString().replace(/"/g,'\\"')+'"}'; }
}

// =====================================================================
// ppGetAllSelectedClips - Obtiene info de TODOS los clips seleccionados
// =====================================================================

function ppGetAllSelectedClips() {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return '{"err":"Sin secuencia activa"}';
        
        var fps = 24;
        try { fps = 1.0 / seq.getSettings().videoFrameRate.seconds; } catch(ef) {}
        
        var seqW = seq.frameSizeHorizontal;
        var seqH = seq.frameSizeVertical;
        
        var clips = [];
        
        for (var t = 0; t < seq.videoTracks.numTracks; t++) {
            var tr = seq.videoTracks[t];
            for (var c = 0; c < tr.clips.numItems; c++) {
                try {
                    var cl = tr.clips[c];
                    if (cl.isSelected()) {
                        var mp = "";
                        try { mp = cl.projectItem.getMediaPath(); } catch(ep) {}
                        
                        clips.push('{"mediaPath":"'+mp.replace(/\\/g,'\\\\').replace(/"/g,'\\"')+'"'
                            +',"clipStart":'+cl.start.seconds+',"clipEnd":'+cl.end.seconds
                            +',"clipIn":'+cl.inPoint.seconds+',"clipOut":'+cl.outPoint.seconds
                            +',"trackIdx":'+t+',"clipIdx":'+c+'}');
                    }
                } catch(e2) {}
            }
        }
        
        if (clips.length === 0) return '{"err":"Selecciona al menos un clip de VIDEO en el timeline"}';
        
        return '{"clips":['+clips.join(',')+'],"seqW":'+seqW+',"seqH":'+seqH+',"fps":'+fps+'}';
    } catch(e) { return '{"err":"'+e.toString().replace(/"/g,'\\"')+'"}'; }
}

// =====================================================================
// ppApplyToClip - Aplica rotacion y zoom a un clip especifico
// Sin cortes, solo rotacion y escala directa
// =====================================================================

function ppApplyToClip(trackIdx, clipStartSec, rotation, scale) {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return '{"err":"Sin secuencia"}';
        
        var vt = seq.videoTracks[trackIdx];
        var clip = null;
        
        // Encontrar el clip por su posicion en el timeline
        for (var c = 0; c < vt.clips.numItems; c++) {
            if (Math.abs(vt.clips[c].start.seconds - clipStartSec) < 0.05) {
                clip = vt.clips[c];
                break;
            }
        }
        
        if (!clip) return '{"err":"Clip no encontrado en tl='+clipStartSec+'"}';
        
        var rotResult = 'skip';
        var scaleResult = 'skip';
        
        if (rotation !== 0) {
            rotResult = _ppSetMotion(clip, rotation);
        }
        
        if (scale !== 100 && scale > 0) {
            scaleResult = _ppSetScale(clip, scale);
        }
        
        return '{"ok":true,"rotResult":"'+rotResult+'","scaleResult":"'+scaleResult+'"}';
    } catch(e) {
        return '{"err":"'+e.toString().replace(/"/g,'\\"')+'"}';
    }
}

// =====================================================================
// ppApplyToClipSmart - Detecta dimensiones y aplica rotacion + zoom
// =====================================================================

function ppApplyToClipSmart(trackIdx, clipStartSec, rotation) {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return '{"err":"Sin secuencia"}';
        
        var seqW = seq.frameSizeHorizontal;
        var seqH = seq.frameSizeVertical;
        
        var vt = seq.videoTracks[trackIdx];
        var clip = null;
        
        for (var c = 0; c < vt.clips.numItems; c++) {
            if (Math.abs(vt.clips[c].start.seconds - clipStartSec) < 0.05) {
                clip = vt.clips[c];
                break;
            }
        }
        
        if (!clip) return '{"err":"Clip no encontrado en tl='+clipStartSec+'"}';
        
        // Obtener dimensiones
        var dims = _getClipDimensions(clip);
        var clipW = dims.w;
        var clipH = dims.h;
        
        // Aplicar rotacion
        var rotResult = 'skip';
        if (rotation !== 0) {
            rotResult = _ppSetMotion(clip, rotation);
        }
        
        // Calcular y aplicar zoom
        var scale = _computeSmartScale(clipW, clipH, seqW, seqH, rotation);
        var scaleResult = 'no_dims';
        if (clipW > 0 && clipH > 0 && scale !== 100) {
            scaleResult = _ppSetScale(clip, scale);
        }
        
        return '{"ok":true,"clipW":'+clipW+',"clipH":'+clipH
            +',"seqW":'+seqW+',"seqH":'+seqH
            +',"scale":'+scale
            +',"rotResult":"'+rotResult+'"'
            +',"scaleResult":"'+scaleResult+'"}';
    } catch(e) {
        return '{"err":"'+e.toString().replace(/"/g,'\\"')+'"}';
    }
}

function ppTimeDiag() {
    try {
        var seq = app.project.activeSequence;
        var fps = 1.0 / seq.getSettings().videoFrameRate.seconds;
        return 'FPS: ' + fps.toFixed(4) + ' | 22 frames = ' + (22/fps).toFixed(4) + 's';
    } catch(e) { return 'diag err: '+e; }
}

// =====================================================================
// SMART ZOOM - Detecta dimensiones del clip y aplica Scale
// =====================================================================


function _normMotionName(s) {
    s = (s || '').toString().toLowerCase();
    s = s.replace(/[áàäâ]/g, 'a').replace(/[éèëê]/g, 'e').replace(/[íìïî]/g, 'i').replace(/[óòöô]/g, 'o').replace(/[úùüû]/g, 'u').replace(/ñ/g, 'n');
    return s;
}

function _findMotionComponent(clip) {
    try {
        var best = null;
        for (var i = 0; i < clip.components.numItems; i++) {
            var comp = clip.components[i];
            var cname = _normMotionName(comp.displayName || comp.name || '');
            if (cname.indexOf('motion') >= 0 || cname.indexOf('movimiento') >= 0) {
                return comp;
            }
            if (!best) {
                var hasScale = false, hasRot = false;
                try {
                    for (var p = 0; p < comp.properties.numItems; p++) {
                        var dn = _normMotionName(comp.properties[p].displayName || '');
                        if (dn.indexOf('scale') >= 0 || dn.indexOf('escala') >= 0) hasScale = true;
                        if (dn.indexOf('rotat') >= 0 || dn.indexOf('rotac') >= 0 || dn.indexOf('giro') >= 0) hasRot = true;
                    }
                } catch(eProps) {}
                if (hasScale && hasRot) best = comp;
            }
        }
        if (best) return best;
        // Fallback historico: Premiere normalmente pone Movimiento en components[1]
        return clip.components[1] || clip.components[0] || null;
    } catch(e) {
        try { return clip.components[1]; } catch(e2) { return null; }
    }
}

function _findMotionParam(motionComp, kind) {
    if (!motionComp) return null;
    var names = [];
    if (kind === 'rotation') names = ['Rotation', 'Rotación', 'Rotacion'];
    if (kind === 'scale')    names = ['Scale', 'Escala'];
    if (kind === 'position') names = ['Position', 'Posición', 'Posicion'];
    if (kind === 'anchor')   names = ['Anchor Point', 'Punto de anclaje', 'Punto de ancla'];
    if (kind === 'opacity')  names = ['Opacity', 'Opacidad'];

    for (var i = 0; i < names.length; i++) {
        try {
            var direct = motionComp.properties.getParamForDisplayName(names[i]);
            if (direct) return direct;
        } catch(e) {}
    }
    try {
        for (var p = 0; p < motionComp.properties.numItems; p++) {
            var prop = motionComp.properties[p];
            var dn = _normMotionName(prop.displayName || '');
            if (kind === 'rotation' && (dn.indexOf('rotat') >= 0 || dn.indexOf('rotac') >= 0 || dn.indexOf('giro') >= 0)) return prop;
            if (kind === 'scale' && (dn.indexOf('scale') >= 0 || dn.indexOf('escala') >= 0)) return prop;
            if (kind === 'position' && (dn.indexOf('position') >= 0 || dn.indexOf('posicion') >= 0)) return prop;
            if (kind === 'anchor' && (dn.indexOf('anchor') >= 0 || dn.indexOf('anclaje') >= 0 || dn.indexOf('ancla') >= 0)) return prop;
            if (kind === 'opacity' && (dn.indexOf('opacity') >= 0 || dn.indexOf('opacidad') >= 0)) return prop;
        }
    } catch(e2) {}
    return null;
}

function _setParamValueSafe(param, value, clip) {
    if (!param) return 'no_param';
    try {
        if (param.isTimeVarying && param.isTimeVarying()) {
            var startTime = clip ? clip.start : null;
            if (startTime) {
                try { param.addKey(startTime); } catch(eAdd) {}
                try { param.setValueAtKey(startTime, value, true); return 'ok_key_' + value; } catch(eKey1) {}
                try { param.setValueAtKey(startTime, value); return 'ok_key_' + value; } catch(eKey2) {}
            }
        }
        try { param.setValue(value, true); return 'ok_' + value; } catch(e1) {}
        param.setValue(value);
        return 'ok_' + value;
    } catch(e) {
        return 'set_err:' + e.toString();
    }
}

function _getClipDimensions(clip) {
    var w = 0, h = 0;
    try {
        var pi = clip.projectItem;
        
        // Metodo 1: footageInterpretation
        try {
            var vidInfo = pi.getFootageInterpretation();
            if (vidInfo) {
                w = vidInfo.frameWidth || 0;
                h = vidInfo.frameHeight || 0;
            }
        } catch(e1) {}
        
        // Metodo 2: XMP metadata stDim
        if (w === 0 || h === 0) {
            try {
                var xmp = pi.getXMPMetadata();
                var xw = xmp.match(/stDim:w="(\d+)"/);
                var xh = xmp.match(/stDim:h="(\d+)"/);
                if (xw && xh) { w = parseInt(xw[1]); h = parseInt(xh[1]); }
            } catch(e2) {}
        }
        
        // Metodo 3: project columns metadata
        if (w === 0 || h === 0) {
            try {
                var cols = ['Column.Intrinsic.VideoInfo'];
                var mdStr = pi.getProjectColumnsMetadata(cols);
                if (mdStr) {
                    var dims = mdStr.match(/(\d{3,5})\s*[xX\u00d7]\s*(\d{3,5})/);
                    if (dims) { w = parseInt(dims[1]); h = parseInt(dims[2]); }
                }
            } catch(e3) {}
        }

        // Metodo 4: project metadata string
        if (w === 0 || h === 0) {
            try {
                var md = pi.getProjectMetadata();
                var dims2 = md.match(/(\d{3,5})\s*[xX\u00d7]\s*(\d{3,5})/);
                if (dims2) { w = parseInt(dims2[1]); h = parseInt(dims2[2]); }
            } catch(e4) {}
        }
    } catch(e) {}
    return { w: w, h: h };
}

function _computeSmartScale(clipW, clipH, seqW, seqH, rotation) {
    if (clipW <= 0 || clipH <= 0) return 100;
    
    // Si rotacion es 90 o 270, las dimensiones efectivas se intercambian
    var effectiveW = clipW;
    var effectiveH = clipH;
    var absRot = Math.abs(rotation) % 360;
    if (absRot === 90 || absRot === 270) {
        effectiveW = clipH;
        effectiveH = clipW;
    }
    
    // Calcular scale para llenar la secuencia (fill)
    var scaleX = (seqW / effectiveW) * 100;
    var scaleY = (seqH / effectiveH) * 100;
    var scale = Math.max(scaleX, scaleY);
    
    return Math.round(scale * 10) / 10;
}

function _ppSetScale(clip, scaleVal) {
    try {
        var motionComp = _findMotionComponent(clip);
        if (!motionComp) return 'no_motion';
        var scaleParam = _findMotionParam(motionComp, 'scale');
        if (!scaleParam) return 'no_scale_param';
        var rr = _setParamValueSafe(scaleParam, scaleVal, clip);
        if (rr.indexOf('ok') === 0) return 'ok_scale_' + scaleVal;
        return 'scale_' + rr;
    } catch(e) {
        return 'scale_err:' + e.toString();
    }
}

function _findComponentByKeyword(clip, keywords) {
    try {
        for (var i = 0; i < clip.components.numItems; i++) {
            var comp = clip.components[i];
            var cname = _normMotionName(comp.displayName || comp.name || '');
            for (var k = 0; k < keywords.length; k++) {
                if (cname.indexOf(keywords[k]) >= 0) return comp;
            }
            try {
                for (var p = 0; p < comp.properties.numItems; p++) {
                    var dn = _normMotionName(comp.properties[p].displayName || '');
                    for (var k2 = 0; k2 < keywords.length; k2++) {
                        if (dn.indexOf(keywords[k2]) >= 0) return comp;
                    }
                }
            } catch(eProps) {}
        }
    } catch(e) {}
    return null;
}

function _setArrayParamSafe(param, valueArray, clip) {
    if (!param) return 'no_param';
    try {
        if (param.isTimeVarying && param.isTimeVarying()) {
            var startTime = clip ? clip.start : null;
            if (startTime) {
                try { param.addKey(startTime); } catch(eAdd) {}
                try { param.setValueAtKey(startTime, valueArray, true); return 'ok_array'; } catch(eKey1) {}
                try { param.setValueAtKey(startTime, valueArray); return 'ok_array'; } catch(eKey2) {}
            }
        }
        try { param.setValue(valueArray, true); return 'ok_array'; } catch(e1) {}
        param.setValue(valueArray);
        return 'ok_array';
    } catch(e) {
        return 'set_array_err:' + e.toString();
    }
}

function _resetClipBasicAttributes(clip, seqW, seqH) {
    var ops = [];
    var motionComp = _findMotionComponent(clip);
    if (motionComp) {
        var rotParam = _findMotionParam(motionComp, 'rotation');
        var scaleParam = _findMotionParam(motionComp, 'scale');
        var posParam = _findMotionParam(motionComp, 'position');
        var anchorParam = _findMotionParam(motionComp, 'anchor');

        if (rotParam) ops.push('rot=' + _setParamValueSafe(rotParam, 0, clip));
        if (scaleParam) ops.push('scale=' + _setParamValueSafe(scaleParam, 100, clip));

        // Position default: centro de la secuencia.
        if (posParam) ops.push('pos=' + _setArrayParamSafe(posParam, [seqW / 2, seqH / 2], clip));

        // Anchor default: centro del medio, si podemos leer dimensiones.
        var dims = _getClipDimensions(clip);
        if (anchorParam && dims.w > 0 && dims.h > 0) {
            ops.push('anchor=' + _setArrayParamSafe(anchorParam, [dims.w / 2, dims.h / 2], clip));
        }
    } else {
        ops.push('motion=no_motion');
    }

    // Opacity/Opacidad suele estar en otro componente, no en Motion.
    var opacityComp = _findComponentByKeyword(clip, ['opacity', 'opacidad']);
    if (opacityComp) {
        var opacityParam = _findMotionParam(opacityComp, 'opacity');
        if (opacityParam) ops.push('opacity=' + _setParamValueSafe(opacityParam, 100, clip));
    }

    return ops.join(',');
}

function ppResetSelectedAttributes() {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return '{"err":"Sin secuencia activa"}';

        var seqW = seq.frameSizeHorizontal;
        var seqH = seq.frameSizeVertical;
        var total = 0;
        var reset = 0;
        var details = [];

        for (var t = 0; t < seq.videoTracks.numTracks; t++) {
            var tr = seq.videoTracks[t];
            for (var c = 0; c < tr.clips.numItems; c++) {
                try {
                    var cl = tr.clips[c];
                    if (cl.isSelected()) {
                        total++;
                        var r = _resetClipBasicAttributes(cl, seqW, seqH);
                        reset++;
                        details.push('V' + (t + 1) + '#' + (c + 1) + ':' + r);
                    }
                } catch(eClip) {
                    details.push('err:' + eClip.toString());
                }
            }
        }

        if (total === 0) return '{"err":"Selecciona al menos un clip de VIDEO en el timeline"}';

        var d = details.join(' | ').replace(/\\/g, '\\\\').replace(/"/g, "'");
        return '{"ok":true,"total":' + total + ',"reset":' + reset
            + ',"details":"' + d + '","warn":"Restablece Motion/Scale/Rotation/Position/Anchor y Opacity cuando Premiere expone esos parametros."}';
    } catch(e) {
        return '{"err":"' + e.toString().replace(/"/g, '\\"') + '"}';
    }
}


// =====================================================================
// ROTACION MANUAL con Smart Zoom
// =====================================================================

function ppManualRotation(degrees) {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return '{"err":"Sin secuencia activa"}';
        
        var vc = null, vti = -1;
        
        outer1: for (var t = 0; t < seq.videoTracks.numTracks; t++) {
            var tr = seq.videoTracks[t];
            for (var c = 0; c < tr.clips.numItems; c++) {
                try {
                    if (tr.clips[c].isSelected()) { vc = tr.clips[c]; vti = t; break outer1; }
                } catch(e2) {}
            }
        }
        
        if (!vc) {
            try {
                var sel = seq.getSelection();
                for (var i = 0; i < sel.length; i++) {
                    if (sel[i].mediaType === "Video") { vc = sel[i]; break; }
                }
            } catch(e1) {}
            if (vc) {
                var vs = vc.start.seconds, ve = vc.end.seconds;
                outer2: for (var t2 = 0; t2 < seq.videoTracks.numTracks; t2++) {
                    var tr2 = seq.videoTracks[t2];
                    for (var c2 = 0; c2 < tr2.clips.numItems; c2++) {
                        var cl = tr2.clips[c2];
                        if (Math.abs(cl.start.seconds-vs)<0.05 && Math.abs(cl.end.seconds-ve)<0.05) {
                            vti = t2; vc = cl; break outer2;
                        }
                    }
                }
            }
        }
        
        if (!vc) return '{"err":"Selecciona un clip de VIDEO en el timeline"}';
        
        var seqW = seq.frameSizeHorizontal;
        var seqH = seq.frameSizeVertical;
        
        // Obtener dimensiones del clip
        var dims = _getClipDimensions(vc);
        var clipW = dims.w;
        var clipH = dims.h;
        
        // Aplicar rotacion
        var rotResult = _ppSetMotion(vc, degrees);
        
        // Calcular y aplicar smart zoom
        var scale = _computeSmartScale(clipW, clipH, seqW, seqH, degrees);
        var scaleResult = 'no_dims';
        if (clipW > 0 && clipH > 0) {
            scaleResult = _ppSetScale(vc, scale);
        }
        
        return '{"ok":true,"rotation":' + degrees 
            + ',"clipW":' + clipW + ',"clipH":' + clipH 
            + ',"seqW":' + seqW + ',"seqH":' + seqH
            + ',"scale":' + scale 
            + ',"rotResult":"' + rotResult + '"'
            + ',"scaleResult":"' + scaleResult + '"}';
        
    } catch(e) {
        return '{"err":"' + e.toString().replace(/"/g, '\\"') + '"}';
    }
}

// =====================================================================
// SMART FIT - Solo ajusta Scale sin rotar (para clips 1080 en seq 4K, etc)
// =====================================================================

function ppSmartFit() {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return '{"err":"Sin secuencia activa"}';
        
        var vc = null;
        
        outer1: for (var t = 0; t < seq.videoTracks.numTracks; t++) {
            var tr = seq.videoTracks[t];
            for (var c = 0; c < tr.clips.numItems; c++) {
                try {
                    if (tr.clips[c].isSelected()) { vc = tr.clips[c]; break outer1; }
                } catch(e2) {}
            }
        }
        
        if (!vc) {
            try {
                var sel = seq.getSelection();
                for (var i = 0; i < sel.length; i++) {
                    if (sel[i].mediaType === "Video") { vc = sel[i]; break; }
                }
            } catch(e1) {}
        }
        
        if (!vc) return '{"err":"Selecciona un clip de VIDEO en el timeline"}';
        
        var seqW = seq.frameSizeHorizontal;
        var seqH = seq.frameSizeVertical;
        
        var dims = _getClipDimensions(vc);
        var clipW = dims.w;
        var clipH = dims.h;
        
        if (clipW <= 0 || clipH <= 0) {
            return '{"err":"No se pudieron detectar las dimensiones del clip"}';
        }
        
        // Leer la rotacion actual del clip para considerar en el calculo
        var currentRot = 0;
        try {
            var motionComp = _findMotionComponent(vc);
            var rotParam = _findMotionParam(motionComp, 'rotation');
            if (rotParam) { currentRot = rotParam.getValue(); }
        } catch(er) {}
        
        var scale = _computeSmartScale(clipW, clipH, seqW, seqH, currentRot);
        var scaleResult = _ppSetScale(vc, scale);
        
        return '{"ok":true,"clipW":' + clipW + ',"clipH":' + clipH 
            + ',"seqW":' + seqW + ',"seqH":' + seqH
            + ',"currentRot":' + currentRot
            + ',"scale":' + scale 
            + ',"scaleResult":"' + scaleResult + '"}';
        
    } catch(e) {
        return '{"err":"' + e.toString().replace(/"/g, '\\"') + '"}';
    }
}

// =====================================================================
// Utilidades para timecode
// =====================================================================

function _secsToTimecode(secs, seq) {
    try {
        var t = new Time();
        t.seconds = secs;
        var settings = seq.getSettings();
        return t.getFormatted(settings.videoFrameRate, seq.videoDisplayFormat);
    } catch(e) {
        var fps = 24;
        try { fps = Math.round(1.0 / seq.getSettings().videoFrameRate.seconds); } catch(ef) {}
        
        var totalFrames = Math.round(secs * fps);
        var f = totalFrames % fps;
        var s = Math.floor(totalFrames / fps) % 60;
        var m = Math.floor(totalFrames / fps / 60) % 60;
        var h = Math.floor(totalFrames / fps / 3600);
        
        function pad(n, d) { var s = n.toString(); while(s.length < d) s = '0' + s; return s; }
        return pad(h,2) + ':' + pad(m,2) + ':' + pad(s,2) + ':' + pad(f,2);
    }
}

function _findLinkedAudioClip(seq, videoClip) {
    var vStart = videoClip.start.seconds;
    var vEnd = videoClip.end.seconds;
    for (var a = 0; a < seq.audioTracks.numTracks; a++) {
        var at = seq.audioTracks[a];
        for (var c = 0; c < at.clips.numItems; c++) {
            var ac = at.clips[c];
            if (Math.abs(ac.start.seconds - vStart) < 0.05 && 
                Math.abs(ac.end.seconds - vEnd) < 0.05) {
                return { clip: ac, trackIdx: a };
            }
        }
    }
    return null;
}

// =====================================================================
// ppApplyFix v5.0 - QE DOM + SMART ZOOM
// =====================================================================

function ppApplyFix(segs, trackIdx, frameOffset, targetClipStartSec) {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return '{"err":"Sin secuencia activa"}';
        
        app.enableQE();
        
        var qeSeq = qe.project.getActiveSequence();
        if (!qeSeq) return '{"err":"QE: No se pudo obtener secuencia activa"}';
        
        var fps = 24;
        try { fps = 1.0 / seq.getSettings().videoFrameRate.seconds; } catch(ef) {}
        
        var offsetSecs = (frameOffset || 0) / fps;
        
        var seqW = seq.frameSizeHorizontal;
        var seqH = seq.frameSizeVertical;
        
        var vt = seq.videoTracks[trackIdx];
        var log = [];
        
        log.push('v5.0_SmartZoom');
        log.push('fps:' + fps.toFixed(2) + ' offset:' + offsetSecs.toFixed(3) + 's');
        log.push('seq:' + seqW + 'x' + seqH);
        
        // ══════════════════════════════════════════════════════════════
        // PASO 1: Encontrar clip seleccionado
        // ══════════════════════════════════════════════════════════════
        var origClip = null;
        var hasTargetClipStart = (targetClipStartSec !== undefined && targetClipStartSec !== null && !isNaN(parseFloat(targetClipStartSec)));

        // Cuando hay varios clips seleccionados, NO debemos agarrar el primer clip seleccionado.
        // Primero intentamos localizar exactamente el clip que el panel mando por clipStart.
        if (hasTargetClipStart) {
            var targetClipStart = parseFloat(targetClipStartSec);
            for (var tc = 0; tc < vt.clips.numItems; tc++) {
                try {
                    if (Math.abs(vt.clips[tc].start.seconds - targetClipStart) < 0.08) {
                        origClip = vt.clips[tc];
                        break;
                    }
                } catch(et) {}
            }
            log.push('target_clip_start:' + targetClipStart.toFixed(3) + ' found:' + (origClip ? 'yes' : 'no'));
        }

        if (!origClip) {
            for (var c = 0; c < vt.clips.numItems; c++) {
                try {
                    if (vt.clips[c].isSelected()) { origClip = vt.clips[c]; break; }
                } catch(e) {}
            }
        }
        
        if (!origClip && segs.length > 0) {
            var targetStart = segs[0].timelineStart;
            for (var c2 = 0; c2 < vt.clips.numItems; c2++) {
                var cl = vt.clips[c2];
                if (Math.abs(cl.start.seconds - targetStart) < 0.5) {
                    origClip = cl; break;
                }
            }
        }
        
        if (!origClip) {
            return '{"err":"No se encontro el clip de video."}';
        }
        
        // Obtener dimensiones del clip ANTES de cortar
        var dims = _getClipDimensions(origClip);
        var clipW = dims.w;
        var clipH = dims.h;
        log.push('clip:' + clipW + 'x' + clipH);
        
        var origTlStart = origClip.start.seconds;
        var origTlEnd = origClip.end.seconds;
        
        log.push('orig_tl:' + origTlStart.toFixed(2) + '-' + origTlEnd.toFixed(2));
        
        // ══════════════════════════════════════════════════════════════
        // PASO 2: Calcular puntos de corte
        // ══════════════════════════════════════════════════════════════
        var cutPoints = [];
        
        for (var si = 1; si < segs.length; si++) {
            var cutTime = segs[si].timelineStart;
            cutTime += offsetSecs;
            if (cutTime > origTlStart + 0.05 && cutTime < origTlEnd - 0.05) {
                cutPoints.push(cutTime);
            }
        }
        
        log.push('cut_points:' + cutPoints.length);
        
        // ══════════════════════════════════════════════════════════════
        // PASO 3: CORTES con QE DOM razor()
        // ══════════════════════════════════════════════════════════════
        
        cutPoints.sort(function(a, b) { return b - a; });
        
        var cutsApplied = 0;
        var qeVideoTrack = qeSeq.getVideoTrackAt(trackIdx);
        var qeAudioTrack = null;
        
        try {
            qeAudioTrack = qeSeq.getAudioTrackAt(trackIdx);
        } catch(e) {
            try { qeAudioTrack = qeSeq.getAudioTrackAt(0); } catch(e2) {}
        }
        
        for (var ci = 0; ci < cutPoints.length; ci++) {
            var cutSecs = cutPoints[ci];
            var timecode = _secsToTimecode(cutSecs, seq);
            
            log.push('cut@' + cutSecs.toFixed(2) + 's=' + timecode);
            
            try {
                qeVideoTrack.razor(timecode);
                cutsApplied++;
                if (qeAudioTrack) {
                    try { qeAudioTrack.razor(timecode); } catch(ea) {}
                }
            } catch(er) {
                log.push('razor_err:' + er.toString());
            }
            
            $.sleep(50);
        }
        
        log.push('cuts_done:' + cutsApplied);
        
        // ══════════════════════════════════════════════════════════════
        // PASO 4: APLICAR ROTACIONES + SMART ZOOM
        // ══════════════════════════════════════════════════════════════
        
        $.sleep(200);
        
        var vtFinal = app.project.activeSequence.videoTracks[trackIdx];
        var rotated = 0;
        var zoomed = 0;
        
        var adjustedSegs = [];
        for (var asi = 0; asi < segs.length; asi++) {
            var aseg = {
                timelineStart: segs[asi].timelineStart,
                timelineEnd: segs[asi].timelineEnd,
                rotation: segs[asi].rotation
            };
            
            if (asi === 0) {
                aseg.timelineStart = origTlStart;
            } else {
                aseg.timelineStart = segs[asi].timelineStart + offsetSecs;
            }
            
            if (asi < segs.length - 1) {
                aseg.timelineEnd = segs[asi + 1].timelineStart + offsetSecs;
            } else {
                aseg.timelineEnd = origTlEnd;
            }
            
            adjustedSegs.push(aseg);
        }
        
        for (var rs = 0; rs < adjustedSegs.length; rs++) {
            var rseg = adjustedSegs[rs];
            
            var mid = rseg.timelineStart + (rseg.timelineEnd - rseg.timelineStart) * 0.5;
            
            for (var rc = 0; rc < vtFinal.clips.numItems; rc++) {
                var rclip = vtFinal.clips[rc];
                if (rclip.start.seconds <= mid + 0.1 && rclip.end.seconds >= mid - 0.1) {
                    
                    // Aplicar rotacion
                    if (rseg.rotation !== 0) {
                        var rr = _ppSetMotion(rclip, rseg.rotation);
                        if (rr.indexOf('ok') === 0) rotated++;
                        log.push('rot_seg' + rs + ':' + rseg.rotation + 'deg=' + rr);
                    }
                    
                    // SMART ZOOM
                    var scale = _computeSmartScale(clipW, clipH, seqW, seqH, rseg.rotation);
                    if (clipW > 0 && clipH > 0 && scale !== 100) {
                        var sr = _ppSetScale(rclip, scale);
                        if (sr.indexOf('ok') === 0) zoomed++;
                        log.push('zoom_seg' + rs + ':' + scale + '%');
                    }
                    
                    break;
                }
            }
        }
        
        var logStr = log.join(' | ').replace(/"/g, "'");
        
        return '{"ok":true,"applied":' + rotated + ',"cuts":' + cutsApplied
            + ',"zoomed":' + zoomed + ',"cleaned":0,"cutLog":"' + logStr + '"}';
            
    } catch(e) { 
        return '{"err":"' + e.toString().replace(/"/g, '\\"') + '"}'; 
    }
}

// =====================================================================
// Funcion para aplicar rotacion via Motion component
// =====================================================================

function _ppSetMotion(clip, deg) {
    try {
        var motionComp = _findMotionComponent(clip);
        if (!motionComp) return 'no_motion';
        var rotParam = _findMotionParam(motionComp, 'rotation');
        if (!rotParam) return 'no_rotation_param';
        var rr = _setParamValueSafe(rotParam, deg, clip);
        if (rr.indexOf('ok') === 0) return 'ok_' + deg;
        return 'rot_' + rr;
    } catch(e) {
        return 'err:' + e.toString();
    }
}

// =====================================================================
// Diagnostico QE DOM
// =====================================================================

function ppQETest() {
    try {
        app.enableQE();
        var qeSeq = qe.project.getActiveSequence();
        if (!qeSeq) return 'QE: Sin secuencia';
        
        var qeTrack = qeSeq.getVideoTrackAt(0);
        var numItems = qeTrack.numItems;
        
        var info = 'QE OK | Track0 items: ' + numItems;
        
        for (var i = 0; i < Math.min(numItems, 5); i++) {
            var item = qeTrack.getItemAt(i);
            info += ' | [' + i + '] type=' + item.type;
            if (item.type !== 'Empty') {
                info += ' name=' + (item.name || '?');
            }
        }
        
        return info;
    } catch(e) {
        return 'QE Error: ' + e.toString();
    }
}
