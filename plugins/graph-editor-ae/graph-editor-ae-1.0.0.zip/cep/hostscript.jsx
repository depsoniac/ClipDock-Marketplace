/*
    GraphEditor Host Script - V10 (Motor de Física Real)
    Soporta: Velocidad, Valor, Rebotes y Curvas Espaciales
*/

var _GRAPHEDITOR = {};

(function () {
    'use strict';

    // 1. APLICAR INFLUENCIA (Fidelidad Velocity + Segment Detection)
    _GRAPHEDITOR.applyInfluence = function (outVal, inVal, vOut, vIn, mode) {
        app.beginUndoGroup("GraphEditor Apply");

        var comp = app.project.activeItem;
        if (!comp || !(comp instanceof CompItem)) { app.endUndoGroup(); return; }

        var props = comp.selectedProperties;
        var oInfl = parseFloat(outVal);
        var iInfl = parseFloat(inVal);
        var yo = parseFloat(vOut || 0);
        var yi = parseFloat(vIn || 0);

        if (isNaN(oInfl) || oInfl <= 0) oInfl = 0.1; if (oInfl > 100) oInfl = 100;
        if (isNaN(iInfl) || iInfl <= 0) iInfl = 0.1; if (iInfl > 100) iInfl = 100;

        for (var n = 0; n < props.length; n++) {
            var prop = props[n];
            if (prop.propertyType !== PropertyType.PROPERTY || prop.numKeys === 0) continue;

            var keyIndices = prop.selectedKeys;
            if (!keyIndices || keyIndices.length === 0) continue;

            for (var k = 0; k < keyIndices.length; k++) {
                var idx = keyIndices[k];

                var speedOut = 0;
                var speedIn = 0;

                // SOLO calculamos velocidad si estamos en modo VALUE y hay tiradores verticales
                if (mode === 'value') {
                    if (idx < prop.numKeys) {
                        var dt = prop.keyTime(idx + 1) - prop.keyTime(idx);
                        var v1 = prop.keyValue(idx);
                        var v2 = prop.keyValue(idx + 1);
                        var dv = 0;
                        if (v1 instanceof Array) {
                            var s = 0; for (var d = 0; d < v1.length; d++) s += Math.pow(v2[d] - v1[d], 2);
                            dv = Math.sqrt(s);
                        } else {
                            dv = v2 - v1;
                        }
                        if (dt > 0) speedOut = (yo / (oInfl / 100)) * (dv / dt);
                    }
                    if (idx > 1) {
                        var dtPrev = prop.keyTime(idx) - prop.keyTime(idx - 1);
                        var vPrev = prop.keyValue(idx - 1);
                        var vCurr = prop.keyValue(idx);
                        var dvPrev = 0;
                        if (vPrev instanceof Array) {
                            var s2 = 0; for (var d2 = 0; d2 < vPrev.length; d2++) s2 += Math.pow(vCurr[d2] - vPrev[d2], 2);
                            dvPrev = Math.sqrt(s2);
                        } else {
                            dvPrev = vCurr - vPrev;
                        }
                        if (dtPrev > 0) speedIn = (yi / (iInfl / 100)) * (dvPrev / dtPrev);
                    }
                }

                // Crear objetos de ease con las velocidades calculadas
                var easeOutObj = new KeyframeEase(speedOut, oInfl);
                var easeInObj = new KeyframeEase(speedIn, iInfl);

                var dims = 1;
                if (!(prop.isSpatial && !prop.dimensionsSeparated)) {
                    switch (prop.propertyValueType) {
                        case PropertyValueType.TwoD: dims = 2; break;
                        case PropertyValueType.ThreeD: dims = 3; break;
                        case PropertyValueType.COLOR: dims = 4; break;
                        default: dims = 1; break;
                    }
                }

                var easeInArr = [], easeOutArr = [];
                for (var d = 0; d < dims; d++) {
                    easeInArr.push(easeInObj);
                    easeOutArr.push(easeOutObj);
                }

                try {
                    prop.setInterpolationTypeAtKey(idx, KeyframeInterpolationType.BEZIER, KeyframeInterpolationType.BEZIER);
                    if (prop.setTemporalAutoBezierAtKey) prop.setTemporalAutoBezierAtKey(idx, false);
                    if (prop.isSpatial && prop.isTimeVarying) {
                        try { prop.setSpatialContinuousAtKey(idx, true); } catch (e) { }
                    }
                    prop.setTemporalEaseAtKey(idx, easeInArr, easeOutArr);
                } catch (err) { }
            }
        }
        app.endUndoGroup();
    };

    // 2. LEER INFLUENCIA (Smart Segment Detection)
    _GRAPHEDITOR.getSelectedInfluences = function () {
        var comp = app.project.activeItem;
        if (!comp || !(comp instanceof CompItem)) return JSON.stringify({ found: false });
        var props = comp.selectedProperties;
        if (!props || props.length === 0) return JSON.stringify({ found: false });

        for (var i = 0; i < props.length; i++) {
            var prop = props[i];
            if (prop.propertyType !== PropertyType.PROPERTY || prop.numKeys < 2) continue;
            var keyIndices = prop.selectedKeys;
            if (!keyIndices || keyIndices.length === 0) continue;

            // Lógica de Segmento Inteligente:
            // Si hay 1 seleccionado: intentamos ver el segmento que ENTRA a él (K-1 -> K)
            // Si hay 2+ seleccionados: vemos el segmento entre los dos primeros (K1 -> K2)
            var kStart, kEnd;
            if (keyIndices.length === 1) {
                kEnd = keyIndices[0];
                kStart = (kEnd > 1) ? kEnd - 1 : 1;
                if (kStart === kEnd) {
                    if (kEnd < prop.numKeys) kEnd = kStart + 1;
                    else return JSON.stringify({ found: false });
                }
            } else {
                var ka = keyIndices[0];
                var kb = keyIndices[1];
                kStart = (ka < kb) ? ka : kb;
                kEnd = (ka < kb) ? kb : ka;
            }

            try {
                var easeOut = prop.keyOutTemporalEase(kStart)[0];
                var easeIn = prop.keyInTemporalEase(kEnd)[0];

                var res = {
                    found: true,
                    outVal: easeOut.influence,
                    inVal: easeIn.influence,
                    speedOut: easeOut.speed,
                    speedIn: easeIn.speed,
                    slopeOut: 0,
                    slopeIn: 0,
                    kStart: kStart,
                    kEnd: kEnd
                };

                // Cálculo de pendiente para el segmento kStart -> kEnd
                var dt = prop.keyTime(kEnd) - prop.keyTime(kStart);
                var v1 = prop.keyValue(kStart);
                var v2 = prop.keyValue(kEnd);
                var dv = (v1 instanceof Array) ? 0 : (v2 - v1);

                if (v1 instanceof Array) {
                    var s = 0; for (var d = 0; d < v1.length; d++) s += Math.pow(v2[d] - v1[d], 2);
                    dv = Math.sqrt(s);
                }

                if (dt > 0 && dv !== 0) {
                    res.slopeOut = easeOut.speed / (dv / dt);
                    res.slopeIn = easeIn.speed / (dv / dt);
                }

                return JSON.stringify(res);
            } catch (e) { }
        }
        return JSON.stringify({ found: false });
    };

    /**
     * CTI: comp.time normalizado para la línea vertical del panel.
     * 1) Si hay keys seleccionados: segmento entre ellos (como getSelectedInfluences).
     * 2) Si no, pero la propiedad tiene ≥2 keys: segmento de keys que rodea comp.time.
     * 3) Si no hay propiedad válida: área de trabajo del comp, si no comp.duration.
     */
    _GRAPHEDITOR.getPlayheadSegmentU = function () {
        var comp = app.project.activeItem;
        if (!comp || !(comp instanceof CompItem)) {
            return JSON.stringify({ found: false });
        }

        var tNow = comp.time;

        function uFromSpan(t0, t1, t) {
            if (!(t1 > t0)) return 0.5;
            var u = (t - t0) / (t1 - t0);
            if (u < 0) u = 0;
            if (u > 1) u = 1;
            return u;
        }

        function segmentFromSelectedKeys(prop) {
            var keyIndices = prop.selectedKeys;
            if (!keyIndices || keyIndices.length === 0) return null;

            var kStart, kEnd;
            if (keyIndices.length === 1) {
                kEnd = keyIndices[0];
                kStart = (kEnd > 1) ? kEnd - 1 : 1;
                if (kStart === kEnd) {
                    if (kEnd < prop.numKeys) kEnd = kStart + 1;
                    else return null;
                }
            } else {
                var ka = keyIndices[0];
                var kb = keyIndices[1];
                kStart = (ka < kb) ? ka : kb;
                kEnd = (ka < kb) ? kb : ka;
            }
            if (kStart >= kEnd) return null;

            var t0 = prop.keyTime(kStart);
            var t1 = prop.keyTime(kEnd);
            if (!(t1 > t0)) return null;
            return { t0: t0, t1: t1 };
        }

        function segmentAroundTime(prop, t) {
            var nk = prop.numKeys;
            if (nk < 2) return null;

            var tFirst = prop.keyTime(1);
            var tLast = prop.keyTime(nk);

            if (t <= tFirst) {
                return { t0: prop.keyTime(1), t1: prop.keyTime(2) };
            }
            if (t >= tLast) {
                return { t0: prop.keyTime(nk - 1), t1: prop.keyTime(nk) };
            }

            var ki;
            for (ki = 1; ki < nk; ki++) {
                var ta = prop.keyTime(ki);
                var tb = prop.keyTime(ki + 1);
                if (t >= ta && t <= tb) {
                    return { t0: ta, t1: tb };
                }
            }

            var best = 1;
            for (var k2 = 1; k2 < nk; k2++) {
                if (prop.keyTime(k2) <= t) best = k2;
            }
            var t0f = prop.keyTime(best);
            var t1f = prop.keyTime(Math.min(best + 1, nk));
            if (t1f > t0f) return { t0: t0f, t1: t1f };
            return null;
        }

        var props = comp.selectedProperties;
        if (props && props.length > 0) {
            var pi;
            for (pi = 0; pi < props.length; pi++) {
                var prop = props[pi];
                if (prop.propertyType !== PropertyType.PROPERTY || prop.numKeys < 2) continue;

                var seg = segmentFromSelectedKeys(prop);
                if (!seg) {
                    seg = segmentAroundTime(prop, tNow);
                }
                if (seg) {
                    var u = uFromSpan(seg.t0, seg.t1, tNow);
                    return JSON.stringify({ found: true, u: u });
                }
            }
        }

        var waDur = comp.workAreaDuration;
        var waStart = comp.workAreaStart;
        if (waDur > 0.0001) {
            var uwa = uFromSpan(waStart, waStart + waDur, tNow);
            return JSON.stringify({ found: true, u: uwa });
        }

        var dur = comp.duration;
        if (dur > 0.0001) {
            var uc = tNow / dur;
            if (uc < 0) uc = 0;
            if (uc > 1) uc = 1;
            return JSON.stringify({ found: true, u: uc });
        }

        return JSON.stringify({ found: false });
    };

    // 3. CAMBIAR TIPO (Linear, Bezier, Hold - Restaurado)
    _GRAPHEDITOR.setKeyframeType = function (type) {
        app.beginUndoGroup("GraphEditor Type");
        var comp = app.project.activeItem;
        if (!comp) { app.endUndoGroup(); return; }

        var props = comp.selectedProperties;
        for (var i = 0; i < props.length; i++) {
            var p = props[i];
            if (p.propertyType !== PropertyType.PROPERTY || p.numKeys === 0) continue;

            var keyIndices = p.selectedKeys;
            // Si no hay keys seleccionados, aplicamos a todos
            if (keyIndices.length === 0) {
                for (var j = 1; j <= p.numKeys; j++) keyIndices.push(j);
            }

            for (var k = 0; k < keyIndices.length; k++) {
                var idx = keyIndices[k];
                try {
                    if (type === 'linear') {
                        p.setInterpolationTypeAtKey(idx, KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR);
                    } else if (type === 'hold') {
                        p.setInterpolationTypeAtKey(idx, KeyframeInterpolationType.HOLD, KeyframeInterpolationType.HOLD);
                    } else if (type === 'bezier') {
                        p.setInterpolationTypeAtKey(idx, KeyframeInterpolationType.BEZIER, KeyframeInterpolationType.BEZIER);
                        if (p.setTemporalAutoBezierAtKey) p.setTemporalAutoBezierAtKey(idx, true);
                        if (p.isSpatial && p.isTimeVarying) p.setSpatialAutoBezierAtKey(idx, true);
                    }
                } catch (e) { }
            }
        }
        app.endUndoGroup();
    };

    /**
     * Aplica una curva como EXPRESIÓN en el segmento entre dos keyframes.
     * jsonStr: { type, points:[{t,y}...] } con t,y normalizados 0..1.
     * La expresión interpola desde el valor del key inicial al final usando la curva y.
     */
    _GRAPHEDITOR.applyExpressionSegment = function (jsonStr) {
        app.beginUndoGroup('GraphEditor Expr');
        var data;
        try {
            data = JSON.parse(jsonStr);
        } catch (e1) {
            try {
                data = eval('(' + jsonStr + ')');
            } catch (e2) {
                app.endUndoGroup();
                return 'JSON';
            }
        }
        if (!data || !data.points || data.points.length < 2) {
            app.endUndoGroup();
            return 'PUNTOS';
        }

        var comp = app.project.activeItem;
        if (!comp || !(comp instanceof CompItem)) {
            app.endUndoGroup();
            return 'NO COMP';
        }

        var pts = data.points;
        var type = data.type || 'custom';
        var params = data.params || {};
        var ptsStr;
        try {
            ptsStr = pts.toSource();
        } catch (eS) {
            // fallback manual
            var s = '[';
            for (var i0 = 0; i0 < pts.length; i0++) {
                if (i0 > 0) s += ',';
                s += '{t:' + pts[i0].t + ',y:' + pts[i0].y + '}';
            }
            s += ']';
            ptsStr = s;
        }

        function buildExpr(kStart, kEnd, pointsLiteral, typeStr, paramsLiteral) {
            // IMPORTANT:
            // In AE expressions, valueAtTime() takes exactly ONE argument.
            // Use key(i).time / key(i).value to avoid recursion safely.
            var expr = '';
            // IMPORTANT: use real newlines (\n), not literal "\\n"
            expr += 'var __ge_k0=' + kStart + ';\n';
            expr += 'var __ge_k1=' + kEnd + ';\n';
            expr += 'var __ge_type=' + typeStr + ';\n';
            expr += 'var __ge_params=' + paramsLiteral + ';\n';
            expr += 'var __ge_pts=' + pointsLiteral + ';\n';
            expr += 'function __ge_clamp01(v){return Math.max(0,Math.min(1,v));}\n';
            expr += 'function __ge_y(u){\n';
            expr += '  u=__ge_clamp01(u);\n';
            expr += '  var p=__ge_pts;\n';
            expr += '  for(var i=0;i<p.length-1;i++){\n';
            expr += '    if(u>=p[i].t && u<=p[i+1].t){\n';
            expr += '      var dt=p[i+1].t-p[i].t;\n';
            expr += '      var a=(dt<1e-6)?0:(u-p[i].t)/dt;\n';
            expr += '      return p[i].y+(p[i+1].y-p[i].y)*a;\n';
            expr += '    }\n';
            expr += '  }\n';
            expr += '  return p[p.length-1].y;\n';
            expr += '}\n';
            expr += 'var __ge_t0=key(__ge_k0).time;\n';
            expr += 'var __ge_t1=key(__ge_k1).time;\n';
            expr += 'var __ge_dt=Math.max(1e-6,(__ge_t1-__ge_t0));\n';
            expr += 'var __ge_u=__ge_clamp01((time-__ge_t0)/__ge_dt);\n';
            expr += 'var __ge_k=__ge_y(__ge_u);\n';
            expr += 'var __ge_v0=key(__ge_k0).value;\n';
            expr += 'var __ge_v1=key(__ge_k1).value;\n';
            expr += 'if(__ge_v0 instanceof Array){\n';
            expr += '  var out=[];\n';
            expr += '  for(var d=0;d<__ge_v0.length;d++){out[d]=__ge_v0[d]+(__ge_v1[d]-__ge_v0[d])*__ge_k;}\n';
            expr += '  out;\n';
            expr += '}else{\n';
            expr += '  __ge_v0+(__ge_v1-__ge_v0)*__ge_k;\n';
            expr += '}\n';
            return expr;
        }

        function segmentKeysFromSelected(prop) {
            var keyIndices = prop.selectedKeys;
            if (!keyIndices || keyIndices.length === 0) return null;
            var kStart, kEnd;
            if (keyIndices.length === 1) {
                kEnd = keyIndices[0];
                kStart = (kEnd > 1) ? kEnd - 1 : 1;
                if (kStart === kEnd) {
                    if (kEnd < prop.numKeys) kEnd = kStart + 1;
                    else return null;
                }
            } else {
                var ka = keyIndices[0];
                var kb = keyIndices[1];
                kStart = (ka < kb) ? ka : kb;
                kEnd = (ka < kb) ? kb : ka;
            }
            if (!(kEnd > kStart)) return null;
            return { kStart: kStart, kEnd: kEnd };
        }

        function segmentKeysAroundCTI(prop, tNow) {
            var nk = prop.numKeys;
            if (nk < 2) return null;
            var tFirst = prop.keyTime(1);
            var tLast = prop.keyTime(nk);
            if (tNow <= tFirst) return { kStart: 1, kEnd: 2 };
            if (tNow >= tLast) return { kStart: nk - 1, kEnd: nk };
            for (var k = 1; k < nk; k++) {
                var ta = prop.keyTime(k);
                var tb = prop.keyTime(k + 1);
                if (tNow >= ta && tNow <= tb) return { kStart: k, kEnd: k + 1 };
            }
            return null;
        }

        var typeStr;
        try { typeStr = '"' + String(type).replace(/"/g, '\\"') + '"'; } catch (eT) { typeStr = '"custom"'; }
        var paramsStr;
        try { paramsStr = params.toSource(); } catch (eP) { paramsStr = '({})'; }

        var modified = 0;
        var skipped = 0;
        var lastErr = '';
        var props = comp.selectedProperties;
        var tNow = comp.time;
        for (var n = 0; n < props.length; n++) {
            var prop = props[n];
            if (prop.propertyType !== PropertyType.PROPERTY || prop.numKeys < 2) continue;

            var seg = segmentKeysFromSelected(prop);
            if (!seg) seg = segmentKeysAroundCTI(prop, tNow);
            if (!seg) continue;

            try {
                if (prop.canSetExpression === false) { skipped++; continue; }
                var expr = buildExpr(seg.kStart, seg.kEnd, ptsStr, typeStr, paramsStr);
                prop.expression = expr;
                prop.expressionEnabled = true;
                modified++;
            } catch (eE) {
                lastErr = eE && eE.toString ? eE.toString() : String(eE);
            }
        }

        app.endUndoGroup();
        if (modified < 1) {
            if (lastErr) return 'ERR:' + lastErr;
            if (skipped > 0) return 'ERR:NO_EXPR';
        }
        return 'OK:' + modified;
    };

    /**
     * Lee una curva aplicada como expresión (por GraphEditor) y devuelve type/params/points.
     */
    _GRAPHEDITOR.getSelectedCurveFromExpression = function () {
        var comp = app.project.activeItem;
        if (!comp || !(comp instanceof CompItem)) return JSON.stringify({ found: false, reason: 'NO_COMP' });
        var props = comp.selectedProperties;
        if (!props || props.length === 0) return JSON.stringify({ found: false, reason: 'NO_PROPS' });

        for (var i = 0; i < props.length; i++) {
            var p = props[i];
            if (p.propertyType !== PropertyType.PROPERTY) continue;
            if (!p.canSetExpression) continue;
            var ex = p.expression;
            if (!ex || ex.indexOf('__ge_pts') === -1) continue;

            function grabVar(name) {
                var re = new RegExp('var\\\\s+' + name + '\\\\s*=\\\\s*([^;]+);');
                var m = ex.match(re);
                return (m && m[1]) ? m[1] : null;
            }

            var typeLit = grabVar('__ge_type');
            var paramsLit = grabVar('__ge_params');
            var ptsLit = grabVar('__ge_pts');
            if (!ptsLit) continue;

            var typeVal = 'custom';
            var paramsVal = {};
            var ptsVal = null;
            try { typeVal = eval(typeLit); } catch (eT) { typeVal = 'custom'; }
            try { paramsVal = paramsLit ? eval(paramsLit) : {}; } catch (eP) { paramsVal = {}; }
            try { ptsVal = eval(ptsLit); } catch (ePts) { ptsVal = null; }

            if (!ptsVal || !ptsVal.length) continue;
            return JSON.stringify({
                found: true,
                type: typeVal,
                params: paramsVal,
                points: ptsVal,
                expressionEnabled: !!p.expressionEnabled
            });
        }
        return JSON.stringify({ found: false, reason: 'NO_GE_EXPR' });
    };

    /**
     * Hornea valores en el segmento entre dos keyframes (escalar o array homogéneo, p. ej. Escala 3D).
     * jsonStr: JSON con { type: 'elastic'|'bounce'|'step'|'custom', points: [{t,y}, ...] }
     * t,y normalizados 0..1 (tiempo relativo del segmento, valor relativo v0->v1).
     */
    _GRAPHEDITOR.applyBakedSegment = function (jsonStr) {
        app.beginUndoGroup('GraphEditor Bake');
        var data;
        try {
            data = JSON.parse(jsonStr);
        } catch (e1) {
            try {
                data = eval('(' + jsonStr + ')');
            } catch (e2) {
                app.endUndoGroup();
                return 'JSON';
            }
        }
        if (!data || !data.points || data.points.length < 2) {
            app.endUndoGroup();
            return 'PUNTOS';
        }

        var comp = app.project.activeItem;
        if (!comp || !(comp instanceof CompItem)) {
            app.endUndoGroup();
            return 'NO COMP';
        }

        var props = comp.selectedProperties;
        var pts = data.points;
        var modified = 0;
        var timeEps = 0.0002;

        function canBlendKeyframeValues(v0, v1) {
            if (v0 instanceof Array && v1 instanceof Array) {
                return v0.length === v1.length && v0.length > 0;
            }
            if (!(v0 instanceof Array) && !(v1 instanceof Array)) {
                return !isNaN(parseFloat(v0)) && !isNaN(parseFloat(v1));
            }
            return false;
        }

        function blendKeyframeValues(v0, v1, y) {
            if (v0 instanceof Array && v1 instanceof Array) {
                var out = [];
                var d;
                for (d = 0; d < v0.length; d++) {
                    out.push(parseFloat(v0[d]) + (parseFloat(v1[d]) - parseFloat(v0[d])) * y);
                }
                return out;
            }
            return parseFloat(v0) + (parseFloat(v1) - parseFloat(v0)) * y;
        }

        for (var n = 0; n < props.length; n++) {
            var prop = props[n];
            if (prop.propertyType !== PropertyType.PROPERTY || prop.numKeys < 2) continue;
            var dimSep = false;
            try {
                dimSep = !!prop.dimensionsSeparated;
            } catch (eSep) {
                dimSep = false;
            }
            if (prop.isSpatial && prop.isTimeVarying && !dimSep) continue;

            var keyIndices = prop.selectedKeys;
            if (!keyIndices || keyIndices.length === 0) continue;

            var kStart, kEnd;
            if (keyIndices.length === 1) {
                kEnd = keyIndices[0];
                kStart = (kEnd > 1) ? kEnd - 1 : 1;
                if (kStart === kEnd) {
                    if (kEnd < prop.numKeys) kEnd = kStart + 1;
                    else continue;
                }
            } else {
                var ka = keyIndices[0];
                var kb = keyIndices[1];
                kStart = (ka < kb) ? ka : kb;
                kEnd = (ka < kb) ? kb : ka;
            }
            if (kStart >= kEnd) continue;

            var v0 = prop.keyValue(kStart);
            var v1 = prop.keyValue(kEnd);
            if (!canBlendKeyframeValues(v0, v1)) continue;

            var t0 = prop.keyTime(kStart);
            var t1 = prop.keyTime(kEnd);
            if (t1 <= t0) continue;

            while (prop.numKeys > kStart + 1) {
                var nextT = prop.keyTime(kStart + 1);
                if (nextT >= t1 - 0.00005) break;
                try {
                    prop.removeKey(kStart + 1);
                } catch (eR2) {
                    break;
                }
            }

            var kEndNow = prop.nearestKeyIndex(t1);
            var i, u, y, tAbs, val, nk, existingT;
            for (i = 1; i < pts.length - 1; i++) {
                u = parseFloat(pts[i].t);
                y = parseFloat(pts[i].y);
                if (isNaN(u) || isNaN(y)) continue;
                if (u <= 0 || u >= 1) continue;
                tAbs = t0 + u * (t1 - t0);
                val = blendKeyframeValues(v0, v1, y);
                try {
                    nk = prop.nearestKeyIndex(tAbs);
                    existingT = prop.keyTime(nk);
                    if (Math.abs(existingT - tAbs) < timeEps) {
                        prop.setValueAtKey(nk, val);
                        prop.setInterpolationTypeAtKey(nk, KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR);
                    } else {
                        prop.addKey(tAbs);
                        nk = prop.nearestKeyIndex(tAbs);
                        prop.setValueAtKey(nk, val);
                        prop.setInterpolationTypeAtKey(nk, KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR);
                    }
                } catch (eK) { }
            }

            try {
                prop.setInterpolationTypeAtKey(kStart, KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR);
                kEndNow = prop.nearestKeyIndex(t1);
                prop.setInterpolationTypeAtKey(kEndNow, KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR);
                modified++;
            } catch (eI) { }
        }
        app.endUndoGroup();
        return 'OK:' + modified;
    };
})();