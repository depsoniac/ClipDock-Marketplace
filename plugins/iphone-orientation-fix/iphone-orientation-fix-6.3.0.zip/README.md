# iPhone Orientation Fix v6.3.0

Panel CEP para Premiere Pro empaquetado para ClipDock.

## Cambios v6.3.0

- Rediseño completo del panel con estilo ClipDock.
- Header nuevo, cards nuevas, consola nueva y botones más claros.
- Botón **Restablecer selección**.
- El botón Restablecer limpia en los clips seleccionados:
  - Rotación a 0
  - Escala a 100
  - Posición al centro de la secuencia
  - Punto de anclaje al centro del clip, cuando Premiere expone dimensiones
  - Opacidad a 100, cuando Premiere expone el parámetro
- Mantiene las mejoras de v6.2.2:
  - Reconectar rápido y no bloqueante
  - Descubrimiento de servidor vía ClipDock
  - Fallback de rotación por container corregido
  - Mejor soporte para clips con 1, 2 o múltiples segmentos
  - Mejor soporte multi-clip

## Uso rápido

1. Instala el ZIP desde ClipDock.
2. Abre Premiere Pro.
3. Ve a **Ventana → Extensiones → iPhone Orientation Fix**.
4. En ClipDock, enciende el servidor de análisis si no está activo.
5. En el panel, usa **Reconectar** si el servidor no aparece.
6. Selecciona uno o varios clips de video.
7. Pulsa **Analizar**.
8. Pulsa **Aplicar** para corregir rotación + zoom.

## Botón Restablecer selección

Selecciona los clips en el timeline y pulsa **Restablecer selección**.

No intenta “deshacer” la operación anterior. Solo limpia valores básicos del clip para regresar Motion/Movimiento a un estado normal.

Esto es útil si una corrección no quedó bien y quieres dejar los clips listos para volver a analizarlos o corregirlos manualmente.

## Dependencias

- Python 3.7+
- Flask
- Flask-CORS
- ExifTool instalado en `C:\Program Files\exiftool\exiftool.exe`


## Nota para ClipDock Marketplace

Este ZIP ya incluye `plugin.json` para que ClipDock lo pueda listar/instalar desde el catálogo remoto. También conserva `depso.manifest.json` por compatibilidad con el empaquetado anterior.

Para mayor compatibilidad, `servidor_analisis.py` también está copiado dentro de `cep/`, así una instalación CEP simple no deja fuera el servidor local.
