// ExtendScript for Adobe// Premiere Pro File Manager Extension - ExtendScript Host
// This script runs in the Premiere Pro ExtendScript environment

// Platform detection
var IS_WINDOWS = ($.os.toLowerCase().indexOf('windows') >= 0);
var IS_MAC = !IS_WINDOWS;

// Platform-specific configuration
var PLATFORM_CONFIG = {
    // File stability check wait time (ms)
    fileStabilityWait: IS_WINDOWS ? 5000 : 3000, // Windows needs longer wait

    // File open mode for lock detection
    fileOpenMode: IS_WINDOWS ? 'r' : 'a', // Windows: read, Mac: append

    // Path separator
    pathSeparator: IS_WINDOWS ? '\\' : '/'
};

// Global blacklist for files that failed to import
// This prevents auto-import from retrying incompatible files in a loop
var FAILED_IMPORTS_BLACKLIST = {};
var FM_FAILED_IMPORTS_FILENAME = '.premiere-file-manager-failed-imports.json';
var FM_FAILED_IMPORTS_VERSION = 1;
var FM_FAILED_IMPORTS_TTL_MS = 7 * 24 * 60 * 60 * 1000; // 7 days
var FM_LAST_PROJECT_ROOT_FOR_BLACKLIST = '';

// Incremental scan cache settings
var FM_SCAN_CACHE_VERSION = 1;
var FM_SCAN_CACHE_FILENAME = '.premiere-file-manager-scan-cache.json';

// Host log level configuration
var FM_LOG_LEVELS = {
    debug: 10,
    info: 20,
    warn: 30,
    error: 40
};
var FM_LOG_LEVEL = 'info';

// Check if a log should be emitted at current level
function shouldLogPlatform(level) {
    var normalizedLevel = level || 'info';
    var currentLevelValue = FM_LOG_LEVELS[FM_LOG_LEVEL] || FM_LOG_LEVELS.info;
    var requestedLevelValue = FM_LOG_LEVELS[normalizedLevel] || FM_LOG_LEVELS.info;
    return requestedLevelValue >= currentLevelValue;
}

// Helper function to log platform-specific behavior
function logPlatform(message, level) {
    var normalizedLevel = level || 'info';
    if (!shouldLogPlatform(normalizedLevel)) {
        return;
    }
    $.writeln('[' + (IS_WINDOWS ? 'WIN' : 'MAC') + '][' + normalizedLevel.toUpperCase() + '] ' + message);
}

// Allow the panel to tune host logging verbosity
function FileManager_setLogLevel(level) {
    try {
        var normalized = (level || '').toString().toLowerCase();
        if (!FM_LOG_LEVELS.hasOwnProperty(normalized)) {
            normalized = 'info';
        }
        FM_LOG_LEVEL = normalized;
        return JSON.stringify({ success: true, logLevel: FM_LOG_LEVEL });
    } catch (e) {
        return JSON.stringify({ success: false, error: e.toString() });
    }
}

// Helper function to decode URI-encoded paths (e.g., %20 -> space)
function decodeURIPath(path) {
    if (!path) return path;
    try {
        // Decode URI components (e.g., %20 -> space)
        return decodeURI(path);
    } catch (e) {
        // If decoding fails, return original path
        return path;
    }
}

// Normalize any path as a stable lowercase key for lookups/caches
function normalizePathKey(pathValue) {
    if (!pathValue) {
        return '';
    }
    return pathValue.replace(/\\/g, '/').toLowerCase();
}

// Cache Windows drive mappings (e.g. Z: -> \\NAS\Share) for NAS path normalization
var FM_WINDOWS_DRIVE_MAP_CACHE = null;
var FM_WINDOWS_DRIVE_MAP_CACHE_TS = 0;
var FM_WINDOWS_DRIVE_MAP_CACHE_TTL_MS = 60 * 1000; // Refresh every minute

// Normalize path into a comparable canonical form across slash styles and URI forms
function normalizeComparablePath(pathValue) {
    if (!pathValue) {
        return '';
    }

    var normalized = decodeURIPath(pathValue.toString());

    // Handle file URI formats if they appear in ExtendScript APIs
    if (normalized.indexOf('file:///') === 0) {
        normalized = normalized.substring(8);
    } else if (normalized.indexOf('file://') === 0) {
        normalized = normalized.substring(7);
    }

    normalized = normalized.replace(/\\/g, '/');

    // Preserve UNC prefix on Windows network paths (//server/share/...)
    var isUncPath = normalized.indexOf('//') === 0;
    if (isUncPath) {
        normalized = '//' + normalized.substring(2).replace(/\/+/g, '/');
    } else {
        normalized = normalized.replace(/\/+/g, '/');
    }

    // Normalize Windows drive notations (/c/path, /c:/path -> c:/path)
    if (IS_WINDOWS && !isUncPath) {
        if (/^\/[a-zA-Z]\//.test(normalized)) {
            normalized = normalized.charAt(1) + ':/' + normalized.substring(3);
        } else if (/^\/[a-zA-Z]:\//.test(normalized)) {
            normalized = normalized.substring(1);
        }
    }

    // Remove trailing slash for stable comparisons (except "/" and "x:/")
    if (!/^[a-zA-Z]:\/$/.test(normalized) && !/^\/\/[^\/]+\/[^\/]+\/?$/.test(normalized)) {
        while (normalized.length > 1 && normalized.charAt(normalized.length - 1) === '/') {
            normalized = normalized.substring(0, normalized.length - 1);
        }
    }

    return normalized.toLowerCase();
}

// Best-effort retrieval of mapped drive -> UNC mappings on Windows (used for NAS comparisons)
function getWindowsDriveMappings() {
    if (!IS_WINDOWS) {
        return {};
    }

    var nowMs = new Date().getTime();
    if (FM_WINDOWS_DRIVE_MAP_CACHE && (nowMs - FM_WINDOWS_DRIVE_MAP_CACHE_TS) < FM_WINDOWS_DRIVE_MAP_CACHE_TTL_MS) {
        return FM_WINDOWS_DRIVE_MAP_CACHE;
    }

    var mappings = {};
    try {
        if (typeof system !== 'undefined' && system.callSystem) {
            var output = system.callSystem('cmd.exe /d /c "net use"');
            if (output && output !== '') {
                var lines = output.split(/\r?\n/);
                for (var i = 0; i < lines.length; i++) {
                    var line = lines[i];
                    // Example: "OK   L:   \\NAS\Share\Folder With Spaces   Microsoft Windows Network"
                    // Capture UNC path up to the next 2+ spaces separator (or end of line)
                    var match = line.match(/\b([A-Za-z]:)\s+(\\\\.+?)(?:\s{2,}|\s*$)/);
                    if (match && match[1] && match[2]) {
                        var drive = match[1].toLowerCase();
                        var uncRootRaw = match[2].replace(/\s+$/, '');
                        var uncRoot = normalizeComparablePath(uncRootRaw);
                        if (uncRoot !== '') {
                            mappings[drive] = uncRoot;
                        }
                    }
                }
            }
        }
    } catch (e) {
        // Ignore mapping lookup failures and fallback to standard normalization
    }

    FM_WINDOWS_DRIVE_MAP_CACHE = mappings;
    FM_WINDOWS_DRIVE_MAP_CACHE_TS = nowMs;
    return mappings;
}

// Expand a mapped drive path into its UNC equivalent when available
function expandMappedDriveComparablePath(normalizedPath) {
    if (!IS_WINDOWS || !normalizedPath) {
        return '';
    }

    var driveMatch = normalizedPath.match(/^([a-z]:)(\/.*)?$/);
    if (!driveMatch) {
        return '';
    }

    var drive = driveMatch[1];
    var rest = driveMatch[2] || '';
    var mappings = getWindowsDriveMappings();
    if (!mappings.hasOwnProperty(drive)) {
        return '';
    }

    var uncRoot = mappings[drive];
    return normalizeComparablePath(uncRoot + rest);
}

// Extract lowercase extension with dot (e.g. ".mp4"), empty string when missing
function getFileExtension(pathValue) {
    if (!pathValue) {
        return '';
    }
    var normalized = pathValue.replace(/\\/g, '/');
    var lastSlash = normalized.lastIndexOf('/');
    var fileName = lastSlash >= 0 ? normalized.substring(lastSlash + 1) : normalized;
    var lastDot = fileName.lastIndexOf('.');
    if (lastDot < 0) {
        return '';
    }
    return fileName.substring(lastDot).toLowerCase();
}

// Build a deterministic media signature (name + size + mtime) for dedup/matching
function buildMediaSignature(fileName, size, modified) {
    var normalizedName = (fileName || '').toLowerCase();
    var normalizedSize = (typeof size === 'number') ? size : -1;
    var normalizedModified = (typeof modified === 'number') ? modified : 0;

    if (!normalizedName || normalizedSize < 0 || normalizedModified <= 0) {
        return '';
    }

    return normalizedName + '|' + normalizedSize + '|' + normalizedModified;
}

// Return full cache file path inside the project root
function getScanCacheFilePath(projectRoot) {
    return projectRoot + '/' + FM_SCAN_CACHE_FILENAME;
}

// Return full failed-import blacklist file path inside the project root
function getFailedImportsFilePath(projectRoot) {
    return projectRoot + '/' + FM_FAILED_IMPORTS_FILENAME;
}

// Drop expired blacklist entries and normalize legacy values
function pruneFailedImportsBlacklist(entries, nowMs) {
    var pruned = {};
    var changed = false;

    if (!entries) {
        return { entries: pruned, changed: false };
    }

    for (var key in entries) {
        if (!entries.hasOwnProperty(key)) {
            continue;
        }

        var rawValue = entries[key];
        var timestamp = 0;

        if (typeof rawValue === 'number') {
            timestamp = rawValue;
        } else if (rawValue === true) {
            // Legacy boolean entry: keep it from now and convert to timestamp
            timestamp = nowMs;
            changed = true;
        } else if (rawValue && typeof rawValue === 'object' && typeof rawValue.ts === 'number') {
            timestamp = rawValue.ts;
            changed = true;
        }

        if (timestamp <= 0 || (nowMs - timestamp) > FM_FAILED_IMPORTS_TTL_MS) {
            changed = true;
            continue;
        }

        pruned[key] = timestamp;
    }

    return { entries: pruned, changed: changed };
}

// Load failed-import blacklist for current project root
function loadFailedImportsBlacklist(projectRoot) {
    var nowMs = new Date().getTime();
    var loadedEntries = {};
    var changedOnLoad = false;

    if (!projectRoot || projectRoot === '') {
        FAILED_IMPORTS_BLACKLIST = {};
        FM_LAST_PROJECT_ROOT_FOR_BLACKLIST = '';
        return FAILED_IMPORTS_BLACKLIST;
    }

    try {
        var blacklistFile = new File(getFailedImportsFilePath(projectRoot));
        if (blacklistFile.exists && blacklistFile.open('r')) {
            var content = blacklistFile.read();
            blacklistFile.close();

            if (content && content !== '') {
                var parsed = JSON.parse(content);
                if (parsed && parsed.entries) {
                    loadedEntries = parsed.entries;
                } else if (parsed && typeof parsed === 'object') {
                    // Legacy structure fallback
                    loadedEntries = parsed;
                    changedOnLoad = true;
                }
            }
        }
    } catch (e) {
        loadedEntries = {};
    }

    var pruneResult = pruneFailedImportsBlacklist(loadedEntries, nowMs);
    FAILED_IMPORTS_BLACKLIST = pruneResult.entries;
    FM_LAST_PROJECT_ROOT_FOR_BLACKLIST = projectRoot;

    if (changedOnLoad || pruneResult.changed) {
        saveFailedImportsBlacklist(projectRoot, FAILED_IMPORTS_BLACKLIST);
    }

    return FAILED_IMPORTS_BLACKLIST;
}

// Save failed-import blacklist for current project root
function saveFailedImportsBlacklist(projectRoot, entries) {
    if (!projectRoot || projectRoot === '') {
        return false;
    }

    try {
        var blacklistFile = new File(getFailedImportsFilePath(projectRoot));
        if (!blacklistFile.open('w')) {
            return false;
        }

        blacklistFile.write(JSON.stringify({
            version: FM_FAILED_IMPORTS_VERSION,
            ttlMs: FM_FAILED_IMPORTS_TTL_MS,
            entries: entries || {}
        }));
        blacklistFile.close();
        return true;
    } catch (e) {
        return false;
    }
}

// Load incremental scan cache from disk (best effort, safe fallback)
function loadScanCache(projectRoot) {
    var defaultCache = {
        version: FM_SCAN_CACHE_VERSION,
        root: normalizePathKey(projectRoot),
        entries: {}
    };

    try {
        var cacheFile = new File(getScanCacheFilePath(projectRoot));
        if (!cacheFile.exists) {
            return defaultCache;
        }

        if (!cacheFile.open('r')) {
            return defaultCache;
        }

        var content = cacheFile.read();
        cacheFile.close();

        if (!content || content === '') {
            return defaultCache;
        }

        var parsed = JSON.parse(content);
        if (!parsed || parsed.version !== FM_SCAN_CACHE_VERSION || !parsed.entries) {
            return defaultCache;
        }

        return parsed;
    } catch (e) {
        return defaultCache;
    }
}

// Save incremental scan cache to disk (best effort)
function saveScanCache(projectRoot, cacheData) {
    try {
        var cacheFile = new File(getScanCacheFilePath(projectRoot));
        if (!cacheFile.open('w')) {
            return false;
        }

        cacheFile.write(JSON.stringify(cacheData));
        cacheFile.close();
        return true;
    } catch (e) {
        return false;
    }
}

// Classify import errors to decide if extension can be auto-added to banlist
function isLikelyIncompatibleImportError(errorText) {
    if (!errorText) {
        return false;
    }

    var msg = errorText.toLowerCase();

    // Corruption/IO style errors must NOT trigger extension auto-ban
    var corruptionOrIoKeywords = [
        'corrupt',
        'damaged',
        'truncated',
        'incomplete',
        'end of file',
        'i/o',
        'io error',
        'read error',
        'permission',
        'locked',
        'network',
        'offline',
        'not found',
        'does not exist'
    ];

    for (var i = 0; i < corruptionOrIoKeywords.length; i++) {
        if (msg.indexOf(corruptionOrIoKeywords[i]) >= 0) {
            return false;
        }
    }

    // Unsupported-format style errors can trigger extension auto-ban
    var incompatibleKeywords = [
        'unsupported',
        'not supported',
        'unknown format',
        'unrecognized format',
        'invalid format',
        'not a valid media',
        'cannot import this file type',
        'file type is not supported',
        'importer'
    ];

    for (var j = 0; j < incompatibleKeywords.length; j++) {
        if (msg.indexOf(incompatibleKeywords[j]) >= 0) {
            return true;
        }
    }

    return false;
}

// Build extension auto-ban suggestion details from an import error
function getImportFailureInfo(filePath, errorText) {
    var ext = getFileExtension(filePath);
    var incompatibleFormat = ext !== '' && isLikelyIncompatibleImportError(errorText);

    return {
        incompatibleFormat: incompatibleFormat,
        suggestedBanExtension: incompatibleFormat ? ext : ''
    };
}

// Get current project path
function FileManager_getProjectPath() {
    if (app.project && app.project.path) {
        return app.project.path;
    }
    return null;
}

// Get bin path recursively
function getBinPath(item) {
    var path = [];
    var current = item;
    var maxDepth = 20; // Safety limit
    var depth = 0;

    // Traverse up the hierarchy until we reach the root
    while (current && depth < maxDepth) {
        depth++;

        try {
            // Check if this item has a name (root doesn't)
            if (!current.name) {
                break; // We've reached the root
            }

            // Check if it's a bin by checking the type
            // In Premiere, bins have type === 2 (ProjectItemType.BIN)
            var isBin = false;
            try {
                isBin = (current.type === ProjectItemType.BIN);
            } catch (e) {
                // If type check fails, try another method
                // Bins have children, files don't
                isBin = (current.children && current.children.numItems !== undefined);
            }

            if (isBin) {
                path.unshift(current.name);
            }
        } catch (e) {
            // If we can't access properties, stop
            break;
        }

        current = current.parent;
    }

    return path.join('/');
}

// Analyze all project items recursively with bin path tracking
function analyzeProjectItems(item, fileList, currentBinPath) {
    if (!item) return;

    // Build the current bin path
    var binPath = currentBinPath || '';

    // If this item is a bin, add it to the path
    if (item.type === ProjectItemType.BIN && item.name) {
        binPath = binPath ? (binPath + '/' + item.name) : item.name;
    }

    // If it's a file (not a bin), add it to the list
    if (item.type === ProjectItemType.FILE || item.type === ProjectItemType.CLIP) {
        try {
            var filePath = item.getMediaPath();
            if (filePath && filePath !== '') {
                fileList.push({
                    name: item.name,
                    path: filePath,
                    binPath: binPath,
                    type: item.type.toString()
                });
            }
        } catch (e) {
            // Skip items without media path
        }
    }

    // Recurse into children (bins or files)
    if (item.children && item.children.numItems > 0) {
        for (var i = 0; i < item.children.numItems; i++) {
            analyzeProjectItems(item.children[i], fileList, binPath);
        }
    }
}

// Main function to analyze the entire project
function analyzeProject() {
    try {
        var project = app.project;

        if (!project) {
            return JSON.stringify({ error: "No active project" });
        }

        var fileList = [];
        var rootItem = project.rootItem;

        // Analyze all items starting from root with empty bin path
        analyzeProjectItems(rootItem, fileList, '');

        var result = {
            projectPath: FileManager_getProjectPath(),
            projectRoot: FileManager_getProjectRootPath(0), // Default to 0 (same folder as project)
            files: fileList,
            totalFiles: fileList.length
        };

        return JSON.stringify(result);

    } catch (e) {
        return JSON.stringify({ error: e.toString() });
    }
}

// Check if a file is outside the project folder
function isFileExternal(filePath, projectRoot) {
    if (!filePath || !projectRoot) return false;

    // Build candidate comparisons from raw + canonical fsName + mapped-drive expansion
    var fileCandidates = {};
    var rootCandidates = {};

    function addCandidate(map, value) {
        if (!value || value === '') return;
        map[value] = true;
    }

    var normalizedFile = normalizeComparablePath(filePath);
    var normalizedRoot = normalizeComparablePath(projectRoot);
    addCandidate(fileCandidates, normalizedFile);
    addCandidate(rootCandidates, normalizedRoot);

    // fsName often gives a more canonical path on Windows/NAS
    try {
        var fileFsName = normalizeComparablePath((new File(filePath)).fsName);
        addCandidate(fileCandidates, fileFsName);
    } catch (e) {
        // Ignore path canonicalization errors
    }
    try {
        var rootFsName = normalizeComparablePath((new Folder(projectRoot)).fsName);
        addCandidate(rootCandidates, rootFsName);
    } catch (e) {
        // Ignore path canonicalization errors
    }

    // Add mapped-drive expansions (e.g. z:/project -> /nas/share/project)
    addCandidate(fileCandidates, expandMappedDriveComparablePath(normalizedFile));
    addCandidate(rootCandidates, expandMappedDriveComparablePath(normalizedRoot));

    for (var fileCandidate in fileCandidates) {
        if (!fileCandidates.hasOwnProperty(fileCandidate)) continue;

        for (var rootCandidate in rootCandidates) {
            if (!rootCandidates.hasOwnProperty(rootCandidate)) continue;

            var rootWithSlash = rootCandidate;
            if (rootWithSlash.charAt(rootWithSlash.length - 1) !== '/') {
                rootWithSlash += '/';
            }

            if (fileCandidate === rootCandidate || fileCandidate.indexOf(rootWithSlash) === 0) {
                return false; // File is inside project root
            }
        }
    }

    // Debug aid for NAS/UNC mismatch investigations on Windows
    if (shouldLogPlatform('debug')) {
        var sampleFileCandidate = '';
        var sampleRootCandidate = '';
        for (var fc in fileCandidates) {
            if (fileCandidates.hasOwnProperty(fc)) {
                sampleFileCandidate = fc;
                break;
            }
        }
        for (var rc in rootCandidates) {
            if (rootCandidates.hasOwnProperty(rc)) {
                sampleRootCandidate = rc;
                break;
            }
        }
        logPlatform('EXTERNAL CHECK: treating as external. file=' + sampleFileCandidate + ' root=' + sampleRootCandidate, 'debug');
    }

    return true;
}

// Get files that need to be synchronized
function FileManager_getFilesToSync(rootPath, excludedFoldersJson) {
    try {
        var analysisResult = JSON.parse(analyzeProject());

        if (analysisResult.error) {
            return JSON.stringify(analysisResult);
        }

        var projectRoot = rootPath || analysisResult.projectRoot;
        if (!projectRoot) {
            return JSON.stringify({ error: "Cannot determine project root path" });
        }

        // Parse excluded folders list
        var excludedFolders = [];
        try {
            if (excludedFoldersJson) {
                excludedFolders = JSON.parse(excludedFoldersJson);
            }
        } catch (e) {
            // If parsing fails, use empty array
            excludedFolders = [];
        }

        var filesToSync = [];

        for (var i = 0; i < analysisResult.files.length; i++) {
            var file = analysisResult.files[i];

            if (isFileExternal(file.path, projectRoot)) {
                // Check if file is in an excluded folder
                var isExcluded = false;
                if (file.binPath && excludedFolders.length > 0) {
                    for (var j = 0; j < excludedFolders.length; j++) {
                        var excludedFolder = excludedFolders[j];
                        // Check if binPath starts with excluded folder name
                        if (file.binPath === excludedFolder ||
                            file.binPath.indexOf(excludedFolder + '/') === 0) {
                            isExcluded = true;
                            break;
                        }
                    }
                }

                // Skip if excluded
                if (isExcluded) {
                    continue;
                }

                // Extract filename from full path
                var sourceFile = new File(file.path);
                var fileName = decodeURIPath(sourceFile.name);  // Decode filename to prevent %20

                // Build target path properly
                var targetPath;
                if (file.binPath && file.binPath !== '') {
                    // Replace forward slashes with platform-specific separators
                    var binPathNormalized = file.binPath.replace(/\//g, '/');
                    targetPath = projectRoot + '/' + binPathNormalized + '/' + fileName;
                } else {
                    // File is at root level
                    targetPath = projectRoot + '/' + fileName;
                }

                filesToSync.push({
                    name: fileName,
                    currentPath: file.path,
                    binPath: file.binPath,
                    targetPath: targetPath
                });
            }
        }

        return JSON.stringify({
            rootPath: FileManager_getProjectRootPath(0), // Default to 0 (same folder as project)
            filesToSync: filesToSync,
            totalExternal: filesToSync.length
        });

    } catch (e) {
        return JSON.stringify({ error: e.toString() });
    }
}

// Relink media after copying
function relinkMedia(oldPath, newPath) {
    try {
        if (!app.project || !app.project.rootItem) {
            return JSON.stringify({ success: false, error: "No project open" });
        }

        // Normalize paths for comparison (convert backslashes to forward slashes)
        var normalizedOldPath = oldPath.replace(/\\/g, '/').toLowerCase();

        // For changeMediaPath, we need to keep the original format
        // On Windows, Premiere expects backslashes
        var relinkPath = newPath;
        if (IS_WINDOWS) {
            // Ensure Windows path format (backslashes)
            relinkPath = newPath.replace(/\//g, '\\');
        }

        // Find the project item with the old path
        function findItemByPath(item, targetPath) {
            if (!item) return null;

            if (item.type === ProjectItemType.FILE || item.type === ProjectItemType.CLIP) {
                try {
                    var itemPath = item.getMediaPath();
                    if (itemPath && itemPath !== '') {
                        // Normalize item path for comparison
                        var normalizedItemPath = itemPath.replace(/\\/g, '/').toLowerCase();
                        if (normalizedItemPath === targetPath) {
                            return item;
                        }
                    }
                } catch (e) {
                    // Skip items without media path
                }
            }

            if (item.children && item.children.numItems > 0) {
                for (var i = 0; i < item.children.numItems; i++) {
                    var found = findItemByPath(item.children[i], targetPath);
                    if (found) return found;
                }
            }

            return null;
        }

        var projectItem = findItemByPath(app.project.rootItem, normalizedOldPath);

        if (!projectItem) {
            return JSON.stringify({
                success: false,
                error: "Item not found in project: " + oldPath
            });
        }

        // Change path to new location
        // suppressWarnings = true to avoid dialog boxes
        try {
            projectItem.changeMediaPath(relinkPath, true);
            logPlatform('Relinked: ' + oldPath + ' -> ' + relinkPath);
            return JSON.stringify({ success: true });
        } catch (relinkError) {
            // If relink fails, provide detailed error
            logPlatform('Relink failed: ' + relinkError.toString());
            return JSON.stringify({
                success: false,
                error: "Relink failed: " + relinkError.toString()
            });
        }

    } catch (e) {
        return JSON.stringify({
            success: false,
            error: e.toString()
        });
    }
}
// Batch relink multiple files
function FileManager_batchRelinkMedia(relinkList) {
    try {
        var results = [];
        var list = JSON.parse(relinkList);

        for (var i = 0; i < list.length; i++) {
            var item = list[i];
            var success = relinkMedia(item.oldPath, item.newPath);
            results.push({
                file: item.name,
                success: success
            });
        }

        return JSON.stringify({ results: results });

    } catch (e) {
        return JSON.stringify({ error: e.toString() });
    }
}

// Select folder dialog
function FileManager_selectFolder() {
    var folder = Folder.selectDialog("Sélectionner le dossier racine du projet");
    if (folder) {
        return folder.fsName;
    }
    return null;
}

// Get files to sync (export from project to folder)
function FileManager_getFilesToSync(rootPath, excludedFoldersJson, levels) {
    try {
        var analysisResult = JSON.parse(analyzeProject());

        if (analysisResult.error) {
            return JSON.stringify(analysisResult);
        }

        // Use provided levels or default to 0
        var levelsToUse = (levels !== undefined && levels !== null) ? levels : 0;

        var projectRoot = rootPath || FileManager_getProjectRootPath(levelsToUse);
        if (!projectRoot) {
            return JSON.stringify({ error: "Cannot determine project root path" });
        }

        // Parse excluded folders list
        var excludedFolders = [];
        try {
            if (excludedFoldersJson) {
                excludedFolders = JSON.parse(excludedFoldersJson);
            }
        } catch (e) {
            // If parsing fails, use empty array
            excludedFolders = [];
        }

        var filesToSync = [];

        for (var i = 0; i < analysisResult.files.length; i++) {
            var file = analysisResult.files[i];

            if (isFileExternal(file.path, projectRoot)) {
                // Check if file is in an excluded folder
                var isExcluded = false;
                if (file.binPath && excludedFolders.length > 0) {
                    for (var j = 0; j < excludedFolders.length; j++) {
                        var excludedFolder = excludedFolders[j];
                        // Check if binPath starts with excluded folder name
                        if (file.binPath === excludedFolder ||
                            file.binPath.indexOf(excludedFolder + '/') === 0) {
                            isExcluded = true;
                            break;
                        }
                    }
                }

                // Skip if excluded
                if (isExcluded) {
                    continue;
                }

                // Extract filename from full path
                var sourceFile = new File(file.path);
                var fileName = decodeURIPath(sourceFile.name);  // Decode filename to prevent %20

                // Build target path properly
                var targetPath;
                if (file.binPath && file.binPath !== '') {
                    // Replace forward slashes with platform-specific separators
                    var binPathNormalized = file.binPath.replace(/\//g, '/');
                    targetPath = projectRoot + '/' + binPathNormalized + '/' + fileName;
                } else {
                    // File is at root level
                    targetPath = projectRoot + '/' + fileName;
                }

                filesToSync.push({
                    name: fileName,
                    currentPath: file.path,
                    binPath: file.binPath,
                    targetPath: targetPath
                });
            }
        }

        return JSON.stringify({
            rootPath: FileManager_getProjectRootPath(levelsToUse), // Use the determined levels
            filesToSync: filesToSync,
            totalExternal: filesToSync.length
        });

    } catch (e) {
        return JSON.stringify({ error: e.toString() });
    }
}


// Get project info
function FileManager_getProjectInfo(levels) {
    try {
        var project = app.project;

        if (!project) {
            return JSON.stringify({ error: "No active project" });
        }

        var info = {
            name: project.name,
            path: project.path || null,
            rootPath: FileManager_getProjectRootPath(levels),
            sequences: project.sequences.numSequences,
            rootItems: project.rootItem.children.numItems
        };

        return JSON.stringify(info);

    } catch (e) {
        return JSON.stringify({ error: e.toString() });
    }
}

// Import-related functions for v2.0

// Split a bin path into clean segments (portable across OS path separators)
function splitPathSegments(pathValue) {
    if (!pathValue || pathValue === '') {
        return [];
    }

    var normalizedPath = pathValue.replace(/\\/g, '/');
    var rawSegments = normalizedPath.split('/');
    var segments = [];

    for (var i = 0; i < rawSegments.length; i++) {
        if (rawSegments[i] && rawSegments[i] !== '') {
            segments.push(rawSegments[i]);
        }
    }

    return segments;
}

// Find the first segment index matching a value (case-sensitive, use uppercase inputs)
function findSegmentIndex(segments, value, startIndex) {
    var start = (typeof startIndex === 'number' && startIndex >= 0) ? startIndex : 0;
    for (var i = start; i < segments.length; i++) {
        if (segments[i] === value) {
            return i;
        }
    }
    return -1;
}

// Find the first segment index starting with a prefix (case-sensitive, use uppercase inputs)
function findSegmentPrefixIndex(segments, prefix, startIndex) {
    var start = (typeof startIndex === 'number' && startIndex >= 0) ? startIndex : 0;
    for (var i = start; i < segments.length; i++) {
        if (segments[i].indexOf(prefix) === 0) {
            return i;
        }
    }
    return -1;
}

// Find the first segment index ending with a suffix (case-sensitive, use uppercase inputs)
function findSegmentSuffixIndex(segments, suffix, startIndex) {
    var start = (typeof startIndex === 'number' && startIndex >= 0) ? startIndex : 0;
    for (var i = start; i < segments.length; i++) {
        var segment = segments[i];
        if (segment.length >= suffix.length &&
            segment.substring(segment.length - suffix.length) === suffix) {
            return i;
        }
    }
    return -1;
}

// Check if a file extension is in the allowed list
function isExtensionAllowed(extension, allowedExtensions) {
    if (!allowedExtensions || allowedExtensions.length === 0) {
        return true;
    }

    for (var i = 0; i < allowedExtensions.length; i++) {
        if (extension === allowedExtensions[i]) {
            return true;
        }
    }

    return false;
}

// Detect known camera folder structures and return normalized import behavior
function detectCameraStructure(binPath) {
    var segments = splitPathSegments(binPath);
    var upperSegments = [];
    var i;

    for (i = 0; i < segments.length; i++) {
        upperSegments.push(segments[i].toUpperCase());
    }

    var info = {
        isCameraStructure: false,
        cameraType: '',
        normalizedBinPath: binPath || '',
        allowedExtensions: null
    };

    if (segments.length === 0) {
        return info;
    }

    // AVCHD: /PRIVATE/AVCHD/BDMV/STREAM/*.MTS
    var idxPrivate = findSegmentIndex(upperSegments, 'PRIVATE');
    var idxAvchd = findSegmentIndex(upperSegments, 'AVCHD');
    if (idxPrivate >= 0 && idxAvchd > idxPrivate) {
        info.isCameraStructure = true;
        info.cameraType = 'AVCHD';
        info.normalizedBinPath = segments.slice(0, idxPrivate).join('/');
        info.allowedExtensions = ['.mts', '.m2ts'];
        return info;
    }

    // Sony a7S XAVC: /PRIVATE/M4ROOT/CLIP/*.MP4
    var idxM4Root = findSegmentIndex(upperSegments, 'M4ROOT');
    if (idxPrivate >= 0 && idxM4Root > idxPrivate) {
        info.isCameraStructure = true;
        info.cameraType = 'Sony a7S';
        info.normalizedBinPath = segments.slice(0, idxPrivate).join('/');
        info.allowedExtensions = ['.mp4'];
        return info;
    }

    // Canon XF: /CONTENTS/CLIPS001/*.MXF (and CLIPSxxx variants)
    var idxContents = findSegmentIndex(upperSegments, 'CONTENTS');
    if (idxContents >= 0) {
        var idxCanonClips = findSegmentPrefixIndex(upperSegments, 'CLIPS', idxContents + 1);
        if (idxCanonClips > idxContents) {
            info.isCameraStructure = true;
            info.cameraType = 'Canon XF';
            info.normalizedBinPath = segments.slice(0, idxContents).join('/');
            info.allowedExtensions = ['.mxf'];
            return info;
        }

        // Panasonic P2: /CONTENTS/VIDEO/*.MXF
        var idxVideo = findSegmentIndex(upperSegments, 'VIDEO', idxContents + 1);
        if (idxVideo > idxContents) {
            info.isCameraStructure = true;
            info.cameraType = 'Panasonic P2';
            info.normalizedBinPath = segments.slice(0, idxContents).join('/');
            info.allowedExtensions = ['.mxf'];
            return info;
        }
    }

    // XDCAM-EX: /BPAV/CLPR/.../*.MP4
    var idxBpav = findSegmentIndex(upperSegments, 'BPAV');
    if (idxBpav >= 0) {
        info.isCameraStructure = true;
        info.cameraType = 'XDCAM-EX';
        info.normalizedBinPath = segments.slice(0, idxBpav).join('/');
        info.allowedExtensions = ['.mp4'];
        return info;
    }

    // XDCAM-HD: /XDROOT/CLIP/*.MXF
    var idxXdroot = findSegmentIndex(upperSegments, 'XDROOT');
    if (idxXdroot >= 0) {
        info.isCameraStructure = true;
        info.cameraType = 'XDCAM-HD';
        info.normalizedBinPath = segments.slice(0, idxXdroot).join('/');
        info.allowedExtensions = ['.mxf', '.mp4'];
        return info;
    }

    // XDCAM-HD legacy structure: /PROAV/CLPR/*.MXF
    var idxProav = findSegmentIndex(upperSegments, 'PROAV');
    if (idxProav >= 0) {
        info.isCameraStructure = true;
        info.cameraType = 'XDCAM-HD';
        info.normalizedBinPath = segments.slice(0, idxProav).join('/');
        info.allowedExtensions = ['.mxf', '.mp4'];
        return info;
    }

    // DCIM card structure: /DCIM/xxx/*.MP4|*.MOV
    var idxDcim = findSegmentIndex(upperSegments, 'DCIM');
    if (idxDcim >= 0) {
        info.isCameraStructure = true;
        info.cameraType = 'DCIM';
        info.normalizedBinPath = segments.slice(0, idxDcim).join('/');
        info.allowedExtensions = ['.mp4', '.mov', '.mxf', '.mts', '.m2ts', '.m2t'];
        return info;
    }

    // ARRIRAW folder backups: /ARRIRAW/.../*.ARI
    var idxArriRaw = findSegmentIndex(upperSegments, 'ARRIRAW');
    if (idxArriRaw >= 0) {
        info.isCameraStructure = true;
        info.cameraType = 'ARRIRAW';
        info.normalizedBinPath = segments.slice(0, idxArriRaw).join('/');
        info.allowedExtensions = ['.ari'];
        return info;
    }

    // RED folder backups: /RED/.../*.R3D, /RDM/... sidecar folders, or *.RDC clip folders
    var idxRed = findSegmentIndex(upperSegments, 'RED');
    var idxRdm = findSegmentIndex(upperSegments, 'RDM');
    var idxRdc = findSegmentSuffixIndex(upperSegments, '.RDC');
    if (idxRed >= 0 || idxRdm >= 0 || idxRdc >= 0) {
        var idxRedMarker = idxRed;
        if (idxRedMarker < 0 || (idxRdm >= 0 && idxRdm < idxRedMarker)) {
            idxRedMarker = idxRdm;
        }
        if (idxRedMarker < 0 || (idxRdc >= 0 && idxRdc < idxRedMarker)) {
            idxRedMarker = idxRdc;
        }

        info.isCameraStructure = true;
        info.cameraType = 'RED';
        info.normalizedBinPath = segments.slice(0, idxRedMarker).join('/');
        info.allowedExtensions = ['.r3d'];
        return info;
    }

    // Sony HDV folder backups (typically *.M2T)
    var idxHdv = findSegmentIndex(upperSegments, 'HDV');
    if (idxHdv >= 0) {
        info.isCameraStructure = true;
        info.cameraType = 'Sony HDV';
        info.normalizedBinPath = segments.slice(0, idxHdv).join('/');
        info.allowedExtensions = ['.m2t', '.m2ts'];
        return info;
    }

    return info;
}

// Recursively scan folder for all media files
function scanFolder(folder, fileList, currentPath, bannedExtensionsLookup, excludedFolderNamesLookup) {
    if (!folder || !folder.exists) return;

    try {
        var files = folder.getFiles();
        for (var i = 0; i < files.length; i++) {
            try {
                var item = files[i];

                if (item instanceof Folder) {
                    // Check if folder name is excluded
                    var folderName = decodeURIPath(item.name);  // Decode folder name
                    var folderNameLower = folderName ? folderName.toLowerCase() : '';
                    var isExcludedName = excludedFolderNamesLookup[folderName] === true ||
                        excludedFolderNamesLookup[folderNameLower] === true;

                    if (!isExcludedName) {
                        // Recursively scan subfolder
                        var subPath = currentPath ? (currentPath + '/' + folderName) : folderName;
                        scanFolder(item, fileList, subPath, bannedExtensionsLookup, excludedFolderNamesLookup);
                    }
                } else if (item instanceof File) {
                    // Skip system files by name
                    var fileName = decodeURIPath(item.name);  // Decode filename
                    if (fileName === '.DS_Store' ||
                        fileName === 'Thumbs.db' ||
                        fileName === 'desktop.ini' ||
                        fileName.indexOf('.') === 0) { // Skip hidden files starting with .
                        continue;
                    }

                    // Check if extension is banned
                    var dotIndex = fileName.lastIndexOf('.');
                    var ext = dotIndex >= 0 ? fileName.substring(dotIndex).toLowerCase() : '';
                    var isBanned = bannedExtensionsLookup[ext] === true;

                    // Detect known camera structures to flatten technical folders
                    var cameraInfo = detectCameraStructure(currentPath || '');

                    // In camera folders, import only true media files and skip sidecar/metadata files
                    if (cameraInfo.isCameraStructure && !isExtensionAllowed(ext, cameraInfo.allowedExtensions)) {
                        continue;
                    }

                    if (!isBanned && item.exists) {
                        fileList.push({
                            name: fileName,
                            path: decodeURIPath(item.fsName),  // Decode file path
                            binPath: cameraInfo.isCameraStructure ? cameraInfo.normalizedBinPath : (currentPath || ''),
                            size: item.length || 0,
                            modified: item.modified ? item.modified.getTime() : 0
                        });
                    }
                }
            } catch (fileError) {
                // Skip files that cause errors (permissions, etc.)
                continue;
            }
        }
    } catch (e) {
        // Skip folders that cause errors
        return;
    }
}

// Check if file is stable (not being copied/written)
// This is critical for auto-import to avoid importing incomplete files
// Uses platform-specific configuration for optimal behavior
function isLikelyTransferTempName(filePath) {
    var normalized = filePath ? filePath.toLowerCase() : '';
    return normalized.indexOf('.crdownload') >= 0 ||
        normalized.indexOf('.download') >= 0 ||
        normalized.indexOf('.filepart') >= 0 ||
        normalized.indexOf('.partial') >= 0 ||
        normalized.indexOf('.part') >= 0 ||
        normalized.indexOf('.tmp') >= 0;
}

function isFileStable(filePath) {
    try {
        // Transfer-temp filenames should never be imported
        if (isLikelyTransferTempName(filePath)) {
            logPlatform('File looks like a transfer-temp file: ' + filePath, 'warn');
            return false;
        }

        // Check 1: Try to open file exclusively (detects if file is locked)
        var testFile = new File(filePath);
        if (!testFile.exists) {
            return false;
        }

        // Try to open file - mode depends on platform
        // Windows: 'r' (read) works better for lock detection
        // Mac: 'a' (append) works better for lock detection
        var canOpen = testFile.open(PLATFORM_CONFIG.fileOpenMode);
        if (!canOpen) {
            // File is locked (being written)
            logPlatform('File locked: ' + filePath, 'debug');
            return false;
        }
        testFile.close();

        // Check 2: Record initial size and modification time
        var size1 = testFile.length;
        var modified1 = testFile.modified ? testFile.modified.getTime() : 0;

        // Check if file is empty (still being created)
        if (size1 === 0) {
            logPlatform('File empty: ' + filePath, 'debug');
            return false;
        }

        // Longer age threshold: only trust very old files immediately
        // This avoids importing files that are still transferring on slow NAS links
        var now = new Date().getTime();
        var fileAge = now - modified1;
        var oldEnoughThreshold = IS_WINDOWS ? 180000 : 120000; // 3 min Win, 2 min Mac
        if (fileAge > oldEnoughThreshold) {
            logPlatform('File old enough, assuming stable: ' + filePath, 'debug');
            return true;
        }

        // File is recent, do a stability check with wait
        // Wait for file to stabilize - platform-specific duration
        // Windows: 5 seconds (often shows full size immediately but still writing)
        // Mac: 3 seconds (more accurate file system updates)
        logPlatform('File recent, checking stability: ' + filePath, 'debug');
        $.sleep(PLATFORM_CONFIG.fileStabilityWait);

        // Check 3: Verify size and modification time haven't changed
        testFile = new File(filePath);
        if (!testFile.exists) {
            return false;
        }

        var size2 = testFile.length;
        var modified2 = testFile.modified ? testFile.modified.getTime() : 0;

        // File is stable only if both size AND modification time are unchanged
        if (size1 !== size2 || modified1 !== modified2) {
            logPlatform('File still changing: ' + filePath, 'debug');
            return false;
        }

        // Check 4: Final verification - try to open again
        canOpen = testFile.open(PLATFORM_CONFIG.fileOpenMode);
        if (!canOpen) {
            logPlatform('File locked on recheck: ' + filePath, 'debug');
            return false;
        }
        testFile.close();

        // Extra pass for very recent files to avoid importing while transfer still finalizing
        var veryRecentThreshold = IS_WINDOWS ? 60000 : 45000; // 60s Win, 45s Mac
        if (fileAge <= veryRecentThreshold) {
            logPlatform('File very recent, running extra stability pass: ' + filePath, 'debug');
            $.sleep(PLATFORM_CONFIG.fileStabilityWait);

            testFile = new File(filePath);
            if (!testFile.exists) {
                return false;
            }

            var size3 = testFile.length;
            var modified3 = testFile.modified ? testFile.modified.getTime() : 0;

            if (size2 !== size3 || modified2 !== modified3) {
                logPlatform('File changed during extra pass: ' + filePath, 'debug');
                return false;
            }

            canOpen = testFile.open(PLATFORM_CONFIG.fileOpenMode);
            if (!canOpen) {
                logPlatform('File locked on extra pass: ' + filePath, 'debug');
                return false;
            }
            testFile.close();
        }

        // All checks passed, file is stable
        logPlatform('File stable: ' + filePath, 'debug');
        return true;
    } catch (e) {
        // Any error means file is not stable
        logPlatform('File stability check error: ' + e.toString(), 'warn');
        return false;
    }
}

// Get project root path based on project file location
// levels: how many parent levels to go up from the .prproj file folder
// 0 = same folder as .prproj, 1 = parent, 2 = grandparent, etc.
function FileManager_getProjectRootPath(levels) {
    if (!app.project) {
        return null;
    }

    // Explicit type checking and default to 0
    if (typeof levels !== 'number' || levels < 0) {
        levels = 0;
    }

    // Get project file path
    var projectPath = app.project.path;
    if (!projectPath || projectPath === '') {
        return null;
    }

    // Normalize path separators (handle both Windows \ and Mac/Linux /)
    projectPath = projectPath.replace(/\\/g, '/');

    // Get the folder containing the .prproj file
    var projectFolder = projectPath.substring(0, projectPath.lastIndexOf('/'));

    // If levels is 0, return the project folder itself
    if (levels === 0) {
        return projectFolder;
    }

    // Go up the specified number of parent levels
    var currentPath = projectFolder;
    for (var i = 0; i < levels; i++) {
        var lastSlash = currentPath.lastIndexOf('/');
        if (lastSlash === -1) {
            // Can't go up anymore, return what we have
            break;
        }
        currentPath = currentPath.substring(0, lastSlash);
    }

    return currentPath;
}

// Helper function to get relative path from project root
// This makes file comparison portable across different computers/locations
function getRelativePath(absolutePath, projectRoot) {
    if (!absolutePath || !projectRoot) {
        return absolutePath;
    }

    // Normalize both paths (convert backslashes to forward slashes, lowercase)
    var normAbsolute = absolutePath.replace(/\\/g, '/').toLowerCase();
    var normRoot = projectRoot.replace(/\\/g, '/').toLowerCase();

    // Ensure root ends with /
    if (normRoot.charAt(normRoot.length - 1) !== '/') {
        normRoot += '/';
    }

    // Check if path starts with root
    if (normAbsolute.indexOf(normRoot) === 0) {
        // Return relative path from project root
        return normAbsolute.substring(normRoot.length);
    }

    // Fallback for files outside project root: return filename only
    // This handles edge cases where media is stored outside the project folder
    var lastSlash = normAbsolute.lastIndexOf('/');
    return lastSlash >= 0 ? normAbsolute.substring(lastSlash + 1) : normAbsolute;
}

// Get indexed list of files already in project (relative paths + media signatures)
function getProjectFilesIndex(projectRoot) {
    var index = {
        relativePaths: [],
        relativePathLookup: {},
        signatureLookup: {}
    };

    if (!app.project || !app.project.rootItem) {
        return index;
    }

    function addProjectFiles(item) {
        if (!item) return;

        if (item.type === ProjectItemType.FILE || item.type === ProjectItemType.CLIP) {
            try {
                var mediaPath = item.getMediaPath();
                if (mediaPath && mediaPath !== '') {
                    // Decode URI-encoded path
                    mediaPath = decodeURIPath(mediaPath);

                    // Convert to relative path for portable comparison
                    var relativePath = getRelativePath(mediaPath, projectRoot);
                    index.relativePaths.push(relativePath);
                    index.relativePathLookup[relativePath] = true;

                    // Build robust signature fallback (name + size + mtime)
                    var mediaFile = new File(mediaPath);
                    var mediaSize = -1;
                    var mediaModified = 0;

                    if (mediaFile && mediaFile.exists) {
                        mediaSize = mediaFile.length || 0;
                        mediaModified = mediaFile.modified ? mediaFile.modified.getTime() : 0;
                    }

                    var mediaName = relativePath.substring(relativePath.lastIndexOf('/') + 1);
                    var signature = buildMediaSignature(mediaName, mediaSize, mediaModified);
                    if (signature !== '') {
                        index.signatureLookup[signature] = true;
                    }

                    // Debug: Log conversion
                    logPlatform('PROJECT FILE: ' + mediaPath + ' -> ' + relativePath, 'debug');
                }
            } catch (e) {
                // Skip items without media path
            }
        }

        if (item.children && item.children.numItems > 0) {
            for (var i = 0; i < item.children.numItems; i++) {
                addProjectFiles(item.children[i]);
            }
        }
    }

    addProjectFiles(app.project.rootItem);
    return index;
}

// Scan for new files not in project
function FileManager_scanForNewFiles(rootPath, excludedFoldersJson, bannedExtensionsJson, excludedFolderNamesJson, levels) {
    try {
        // Use provided levels or default to 0
        var levelsToUse = (levels !== undefined && levels !== null) ? levels : 0;

        var projectRoot = rootPath || FileManager_getProjectRootPath(levelsToUse);
        if (!projectRoot) {
            return JSON.stringify({ error: "Cannot determine project root path" });
        }

        // Parse excluded folders
        var excludedFolders = [];
        try {
            if (excludedFoldersJson) {
                excludedFolders = JSON.parse(excludedFoldersJson);
            }
        } catch (e) {
            excludedFolders = [];
        }

        // Parse banned extensions
        var bannedExtensions = [];
        try {
            if (bannedExtensionsJson) {
                bannedExtensions = JSON.parse(bannedExtensionsJson);
            }
        } catch (e) {
            bannedExtensions = [];
        }

        // Parse excluded folder names
        var excludedFolderNames = [];
        try {
            if (excludedFolderNamesJson) {
                excludedFolderNames = JSON.parse(excludedFolderNamesJson);
            }
        } catch (e) {
            excludedFolderNames = [];
        }

        // Build fast lookup maps for O(1) exclusion checks during recursive scan
        var bannedExtensionsLookup = {};
        for (var be = 0; be < bannedExtensions.length; be++) {
            var bannedExt = (bannedExtensions[be] || '').toString().toLowerCase();
            if (bannedExt !== '' && bannedExt.charAt(0) !== '.') {
                bannedExt = '.' + bannedExt;
            }
            if (bannedExt !== '' && bannedExt !== '.') {
                bannedExtensionsLookup[bannedExt] = true;
            }
        }

        var excludedFolderNamesLookup = {};
        for (var ef = 0; ef < excludedFolderNames.length; ef++) {
            var excludedName = excludedFolderNames[ef] || '';
            if (excludedName !== '') {
                excludedFolderNamesLookup[excludedName] = true;
                excludedFolderNamesLookup[excludedName.toLowerCase()] = true;
            }
        }

        // Get project root
        var projectRoot = rootPath || FileManager_getProjectRootPath(levelsToUse);
        if (!projectRoot) {
            return JSON.stringify({ error: 'Could not determine project root' });
        }

        // Load persistent failed-import blacklist for this project root
        loadFailedImportsBlacklist(projectRoot);

        // Debug: Log project root
        logPlatform('========================================', 'info');
        logPlatform('PROJECT ROOT: ' + projectRoot, 'info');
        logPlatform('========================================', 'info');

        // Scan folder
        var rootFolder = new Folder(projectRoot);
        var scannedFiles = [];
        scanFolder(rootFolder, scannedFiles, '', bannedExtensionsLookup, excludedFolderNamesLookup);

        logPlatform('Total scanned files: ' + scannedFiles.length, 'info');

        // Get indexed list of files already in project
        var projectIndex = getProjectFilesIndex(projectRoot);
        var projectFiles = projectIndex.relativePaths;
        var projectFilePaths = projectIndex.relativePathLookup;
        var projectFileSignatures = projectIndex.signatureLookup;

        logPlatform('Total project files: ' + projectFiles.length, 'info');
        logPlatform('========================================', 'info');

        // Load incremental cache for scan decisions
        var scanCache = loadScanCache(projectRoot);
        if (!scanCache.entries) {
            scanCache.entries = {};
        }
        var scanCacheEntries = scanCache.entries;
        var scanCacheSeenKeys = {};
        var cacheDirty = false;

        // Stats for diagnostics
        var cacheHits = 0;
        var stableChecks = 0;
        var stableChecksSkipped = 0;
        var dedupeSkippedByPath = 0;
        var dedupeSkippedBySignature = 0;

        // Dedup trackers for this scan batch
        var newFilesByPath = {};
        var newFilesBySignature = {};

        // Update one cache row consistently and flag dirty only when values changed
        function updateScanCacheEntry(cacheKey, fingerprint, relativePath, decision, stableValue, fileData) {
            scanCacheSeenKeys[cacheKey] = true;

            var nextEntry = {
                fingerprint: fingerprint,
                relativePath: relativePath,
                decision: decision,
                stable: stableValue === true,
                size: fileData.size || 0,
                modified: fileData.modified || 0,
                binPath: fileData.binPath || ''
            };

            var existing = scanCacheEntries[cacheKey];
            var unchanged = existing &&
                existing.fingerprint === nextEntry.fingerprint &&
                existing.relativePath === nextEntry.relativePath &&
                existing.decision === nextEntry.decision &&
                existing.stable === nextEntry.stable &&
                existing.size === nextEntry.size &&
                existing.modified === nextEntry.modified &&
                existing.binPath === nextEntry.binPath;

            if (!unchanged) {
                scanCacheEntries[cacheKey] = nextEntry;
                cacheDirty = true;
            }
        }

        // Find new files
        var newFiles = [];
        for (var i = 0; i < scannedFiles.length; i++) {
            var file = scannedFiles[i];
            var normalizedAbsolutePath = normalizePathKey(file.path);
            var relativeFilePath = getRelativePath(file.path, projectRoot);
            var fingerprint = (file.size || 0) + '|' + (file.modified || 0) + '|' + (file.binPath || '');
            var cacheEntry = scanCacheEntries[normalizedAbsolutePath];
            var cacheHit = cacheEntry && cacheEntry.fingerprint === fingerprint;

            if (cacheHit) {
                cacheHits++;
            }

            // Check if in excluded folder
            var isExcluded = false;
            if (file.binPath && excludedFolders.length > 0) {
                for (var j = 0; j < excludedFolders.length; j++) {
                    var excludedFolder = excludedFolders[j];
                    if (file.binPath === excludedFolder ||
                        file.binPath.indexOf(excludedFolder + '/') === 0) {
                        isExcluded = true;
                        break;
                    }
                }
            }

            if (isExcluded) {
                updateScanCacheEntry(normalizedAbsolutePath, fingerprint, relativeFilePath, 'excluded', false, file);
                continue;
            }

            // Debug: Log conversion and comparison
            logPlatform('SCANNED FILE: ' + file.path + ' -> ' + relativeFilePath, 'debug');

            // Primary comparison: relative path
            var alreadyInProject = projectFilePaths[relativeFilePath] === true;

            // Fallback comparison: robust media signature (name + size + mtime)
            // This avoids false positives from filename-only matching
            if (!alreadyInProject) {
                var scannedSignature = buildMediaSignature(file.name, file.size, file.modified);
                if (scannedSignature !== '') {
                    alreadyInProject = projectFileSignatures[scannedSignature] === true;
                }

                if (alreadyInProject) {
                    logPlatform('✓ MATCH (by signature): ' + relativeFilePath, 'debug');
                }
            }

            // Check blacklist with normalized absolute path and legacy relative key
            var isBlacklisted = FAILED_IMPORTS_BLACKLIST.hasOwnProperty(normalizedAbsolutePath) ||
                FAILED_IMPORTS_BLACKLIST.hasOwnProperty(relativeFilePath);

            // Debug: Log comparison result
            if (alreadyInProject) {
                logPlatform('✓ MATCH: File already in project (relative): ' + relativeFilePath, 'debug');
            } else {
                logPlatform('✗ NEW: File not in project: ' + relativeFilePath, 'debug');
            }

            if (isBlacklisted) {
                logPlatform('BLACKLIST CHECK: File is blacklisted: ' + relativeFilePath, 'debug');
            }

            if (alreadyInProject) {
                updateScanCacheEntry(normalizedAbsolutePath, fingerprint, relativeFilePath, 'in_project', false, file);
                continue;
            }

            if (isBlacklisted) {
                logPlatform('Skipping blacklisted file: ' + relativeFilePath, 'debug');
                updateScanCacheEntry(normalizedAbsolutePath, fingerprint, relativeFilePath, 'blacklisted', false, file);
                continue;
            }

            // Cache hit with previously stable file can skip expensive stability re-check
            var stable = false;
            if (cacheHit && cacheEntry.stable === true && cacheEntry.decision === 'stable') {
                stable = true;
                stableChecksSkipped++;
            } else {
                stableChecks++;
                stable = isFileStable(file.path);
            }

            if (!stable) {
                updateScanCacheEntry(normalizedAbsolutePath, fingerprint, relativeFilePath, 'unstable', false, file);
                continue;
            }

            // Advanced dedup #1: same absolute source path should only appear once
            if (newFilesByPath[normalizedAbsolutePath] === true) {
                dedupeSkippedByPath++;
                updateScanCacheEntry(normalizedAbsolutePath, fingerprint, relativeFilePath, 'dedupe_path', true, file);
                continue;
            }

            // Advanced dedup #2: same clip signature (name+size+mtime) should only appear once
            var dedupeSignature = (file.name || '').toLowerCase() + '|' + (file.size || 0) + '|' + (file.modified || 0);
            if (newFilesBySignature[dedupeSignature] === true) {
                dedupeSkippedBySignature++;
                updateScanCacheEntry(normalizedAbsolutePath, fingerprint, relativeFilePath, 'dedupe_signature', true, file);
                continue;
            }

            newFilesByPath[normalizedAbsolutePath] = true;
            newFilesBySignature[dedupeSignature] = true;
            newFiles.push(file);
            updateScanCacheEntry(normalizedAbsolutePath, fingerprint, relativeFilePath, 'stable', true, file);
        }

        // Remove stale cache rows for files no longer present in project root
        var removedCacheEntries = 0;
        for (var cacheKey in scanCacheEntries) {
            if (scanCacheEntries.hasOwnProperty(cacheKey)) {
                if (scanCacheSeenKeys[cacheKey] !== true) {
                    delete scanCacheEntries[cacheKey];
                    removedCacheEntries++;
                    cacheDirty = true;
                }
            }
        }

        scanCache.version = FM_SCAN_CACHE_VERSION;
        scanCache.root = normalizePathKey(projectRoot);
        var cacheSaved = true;
        if (cacheDirty) {
            cacheSaved = saveScanCache(projectRoot, scanCache);
        }

        return JSON.stringify({
            projectRoot: projectRoot,
            newFiles: newFiles,
            totalNew: newFiles.length,
            debug: {
                projectRoot: projectRoot,
                totalScanned: scannedFiles.length,
                totalInProject: projectFiles.length,
                cacheHits: cacheHits,
                stableChecks: stableChecks,
                stableChecksSkipped: stableChecksSkipped,
                dedupeSkippedByPath: dedupeSkippedByPath,
                dedupeSkippedBySignature: dedupeSkippedBySignature,
                removedCacheEntries: removedCacheEntries,
                cacheDirty: cacheDirty,
                cacheSaved: cacheSaved,
                sampleProjectFiles: projectFiles.slice(0, 3), // First 3 files in project (relative paths)
                sampleScannedFiles: (function () {
                    var samples = [];
                    var limit = Math.min(3, scannedFiles.length);
                    for (var i = 0; i < limit; i++) {
                        samples.push({
                            absolute: scannedFiles[i].path,
                            relative: getRelativePath(scannedFiles[i].path, projectRoot)
                        });
                    }
                    return samples;
                })()
            }
        });

    } catch (e) {
        return JSON.stringify({ error: e.toString() });
    }
}

// Create or get bin by path
function getOrCreateBin(binPath) {
    if (!binPath || binPath === '') {
        return app.project.rootItem;
    }

    var parts = binPath.split('/');
    var currentBin = app.project.rootItem;

    for (var i = 0; i < parts.length; i++) {
        var binName = parts[i];
        var found = false;

        // Search for existing bin
        if (currentBin.children && currentBin.children.numItems > 0) {
            for (var j = 0; j < currentBin.children.numItems; j++) {
                var child = currentBin.children[j];
                if (child.type === ProjectItemType.BIN && child.name === binName) {
                    currentBin = child;
                    found = true;
                    break;
                }
            }
        }

        // Create bin if not found
        if (!found) {
            currentBin = currentBin.createBin(binName);
        }
    }

    return currentBin;
}

// Import files to project
function FileManager_importFilesToProject(filesJson) {
    try {
        var files = JSON.parse(filesJson);
        if (!files || !(files instanceof Array)) {
            return JSON.stringify({ error: 'Invalid files payload' });
        }

        var results = [];
        var resultsByIndex = {};
        var blacklistDirty = false;
        var blacklistRoot = FM_LAST_PROJECT_ROOT_FOR_BLACKLIST || FileManager_getProjectRootPath(0);
        var importGroups = {};
        var importGroupOrder = [];

        if (blacklistRoot && blacklistRoot !== '') {
            loadFailedImportsBlacklist(blacklistRoot);
        }

        // Record one success result with stable shape
        function recordSuccess(file, index) {
            resultsByIndex[index] = {
                name: file.name,
                success: true,
                binPath: file.binPath
            };
        }

        // Record one failure result, update failed-import blacklist, and emit diagnostics
        function recordFailure(file, index, errorText) {
            var safeErrorText = errorText || 'Unknown import error';
            var failureInfo = getImportFailureInfo(file.path, safeErrorText);
            var normalizedPath = normalizePathKey(file.path);
            FAILED_IMPORTS_BLACKLIST[normalizedPath] = new Date().getTime();
            blacklistDirty = true;

            logPlatform('BLACKLIST ADD: Added to blacklist: ' + file.path, 'warn');
            logPlatform('BLACKLIST ADD: Normalized path: ' + normalizedPath, 'debug');
            logPlatform('BLACKLIST ADD: Error was: ' + safeErrorText, 'warn');
            if (failureInfo.incompatibleFormat) {
                logPlatform('BLACKLIST EXTENSION SUGGESTION: ' + failureInfo.suggestedBanExtension, 'warn');
            }

            resultsByIndex[index] = {
                name: file.name,
                success: false,
                incompatibleFormat: failureInfo.incompatibleFormat,
                suggestedBanExtension: failureInfo.suggestedBanExtension,
                error: safeErrorText
            };
        }

        // Import one file into a resolved bin
        function importSingleFile(file, index, targetBin) {
            try {
                var singleResult = app.project.importFiles([file.path], true, targetBin, false);
                if (singleResult === false) {
                    recordFailure(file, index, 'Import returned false');
                } else {
                    recordSuccess(file, index);
                }
            } catch (singleImportError) {
                recordFailure(file, index, singleImportError.toString());
            }
        }

        // Check if Premiere already contains the file (by relative path or signature)
        // Used after a failed batch import to avoid duplicate imports on fallback
        function isAlreadyInProjectByIndex(file, projectRoot, projectIndex) {
            if (!projectRoot || !projectIndex) {
                return false;
            }

            var relativePath = getRelativePath(file.path, projectRoot);
            if (projectIndex.relativePathLookup[relativePath] === true) {
                return true;
            }

            var sourceFile = new File(file.path);
            var size = -1;
            var modified = 0;
            if (sourceFile && sourceFile.exists) {
                size = sourceFile.length || 0;
                modified = sourceFile.modified ? sourceFile.modified.getTime() : 0;
            }

            var signature = buildMediaSignature(file.name, size, modified);
            return signature !== '' && projectIndex.signatureLookup[signature] === true;
        }

        // Pre-validate files and group by bin path so each bin can be imported in one call
        for (var i = 0; i < files.length; i++) {
            var file = files[i];
            if (!file || !file.path) {
                resultsByIndex[i] = {
                    name: file && file.name ? file.name : 'Unknown',
                    success: false,
                    incompatibleFormat: false,
                    suggestedBanExtension: '',
                    error: 'Invalid file payload'
                };
                continue;
            }

            var sourceFile = new File(file.path);
            if (!sourceFile.exists) {
                resultsByIndex[i] = {
                    name: file.name,
                    success: false,
                    incompatibleFormat: false,
                    suggestedBanExtension: '',
                    error: 'Source file does not exist: ' + file.path
                };
                continue;
            }

            var groupKey = file.binPath || '';
            if (!importGroups.hasOwnProperty(groupKey)) {
                importGroups[groupKey] = [];
                importGroupOrder.push(groupKey);
            }

            importGroups[groupKey].push({
                file: file,
                index: i
            });
        }

        // Import each bin group in one call, with per-file fallback only when needed
        for (var g = 0; g < importGroupOrder.length; g++) {
            var groupKey = importGroupOrder[g];
            var groupItems = importGroups[groupKey];
            if (!groupItems || groupItems.length === 0) {
                continue;
            }

            var targetBin = null;
            try {
                targetBin = getOrCreateBin(groupKey);
            } catch (binError) {
                for (var bi = 0; bi < groupItems.length; bi++) {
                    recordFailure(groupItems[bi].file, groupItems[bi].index, 'Bin error: ' + binError.toString());
                }
                continue;
            }

            var batchPaths = [];
            for (var bp = 0; bp < groupItems.length; bp++) {
                batchPaths.push(groupItems[bp].file.path);
            }

            var batchFailed = false;
            var batchErrorText = '';
            try {
                var batchResult = app.project.importFiles(batchPaths, true, targetBin, false);
                if (batchResult === false) {
                    batchFailed = true;
                    batchErrorText = 'Batch import returned false';
                }
            } catch (batchError) {
                batchFailed = true;
                batchErrorText = batchError.toString();
            }

            if (!batchFailed) {
                for (var bs = 0; bs < groupItems.length; bs++) {
                    recordSuccess(groupItems[bs].file, groupItems[bs].index);
                }
                continue;
            }

            logPlatform('Batch import failed for bin "' + groupKey + '" (' + groupItems.length + ' files). Fallback to per-file import. Error: ' + batchErrorText, 'warn');

            // Build one snapshot after batch failure to detect files that may already be imported
            var projectRootForFallback = blacklistRoot || FileManager_getProjectRootPath(0);
            var fallbackProjectIndex = null;
            if (projectRootForFallback && projectRootForFallback !== '') {
                fallbackProjectIndex = getProjectFilesIndex(projectRootForFallback);
            }

            for (var sf = 0; sf < groupItems.length; sf++) {
                var groupEntry = groupItems[sf];
                if (fallbackProjectIndex && isAlreadyInProjectByIndex(groupEntry.file, projectRootForFallback, fallbackProjectIndex)) {
                    recordSuccess(groupEntry.file, groupEntry.index);
                    continue;
                }

                importSingleFile(groupEntry.file, groupEntry.index, targetBin);
            }
        }

        // Rebuild ordered results array for client-side mapping/debug stability
        for (var r = 0; r < files.length; r++) {
            if (resultsByIndex.hasOwnProperty(r)) {
                results.push(resultsByIndex[r]);
            } else {
                results.push({
                    name: files[r] && files[r].name ? files[r].name : 'Unknown',
                    success: false,
                    incompatibleFormat: false,
                    suggestedBanExtension: '',
                    error: 'Import result missing'
                });
            }
        }

        // Persist blacklist updates for next Premiere sessions
        if (blacklistDirty && blacklistRoot && blacklistRoot !== '') {
            saveFailedImportsBlacklist(blacklistRoot, FAILED_IMPORTS_BLACKLIST);
        }

        return JSON.stringify({
            results: results,
            totalImported: (function () {
                var count = 0;
                for (var i = 0; i < results.length; i++) {
                    if (results[i].success) count++;
                }
                return count;
            })()
        });

    } catch (e) {
        return JSON.stringify({ error: e.toString() });
    }
}

// Base64 decode helper for ExtendScript
function base64Decode(str) {
    var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
    var output = '';
    var i = 0;

    str = str.replace(/[^A-Za-z0-9\+\/\=]/g, '');

    while (i < str.length) {
        var enc1 = chars.indexOf(str.charAt(i++));
        var enc2 = chars.indexOf(str.charAt(i++));
        var enc3 = chars.indexOf(str.charAt(i++));
        var enc4 = chars.indexOf(str.charAt(i++));

        var chr1 = (enc1 << 2) | (enc2 >> 4);
        var chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
        var chr3 = ((enc3 & 3) << 6) | enc4;

        output = output + String.fromCharCode(chr1);

        if (enc3 != 64) {
            output = output + String.fromCharCode(chr2);
        }
        if (enc4 != 64) {
            output = output + String.fromCharCode(chr3);
        }
    }

    // Decode UTF-8
    var result = '';
    var i = 0;
    var c1, c2, c3;

    while (i < output.length) {
        c1 = output.charCodeAt(i);

        if (c1 < 128) {
            result += String.fromCharCode(c1);
            i++;
        } else if ((c1 > 191) && (c1 < 224)) {
            c2 = output.charCodeAt(i + 1);
            result += String.fromCharCode(((c1 & 31) << 6) | (c2 & 63));
            i += 2;
        } else {
            c2 = output.charCodeAt(i + 1);
            c3 = output.charCodeAt(i + 2);
            result += String.fromCharCode(((c1 & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
            i += 3;
        }
    }

    return result;
}

// Import files using base64 encoded JSON (safer than escaping)
// Import files using base64 encoded JSON (safer for special characters)
function FileManager_importFilesToProjectBase64(base64Json) {
    try {
        var filesJson = base64Decode(base64Json);
        return FileManager_importFilesToProject(filesJson);
    } catch (e) {
        return JSON.stringify({ error: 'Base64 decode error: ' + e.toString() });
    }
}


/* ============================================================================
 * PR Hybrid Organizer — Bloque de ORGANIZACIÓN del panel
 * (Lógica portada de PR Organizer v1.4, con prefijo HO_ para no colisionar
 *  con las funciones de File Manager como getOrCreateBin).
 *
 * Estructura que crea en el panel de proyecto:
 *   Secuencias/Master      <- secuencias cuyo nombre contiene "master"
 *   Secuencias/Anidadas    <- el resto de secuencias
 *   Footage/<EXT>          <- clips con archivo, un bin por extensión
 *   Assets                 <- capas de ajuste, color mattes, ítems sintéticos
 *
 * Esta misma estructura de bins es la que File Manager usará luego como ruta
 * de destino en disco al consolidar (projectRoot/Footage/MP4/archivo.mp4...).
 * ==========================================================================*/

function HO_getOrCreateChildBin(parent, name) {
    for (var i = 0; i < parent.children.numItems; i++) {
        var ch = parent.children[i];
        if (ch.type === ProjectItemType.BIN && ch.name === name) {
            return ch;
        }
    }
    return parent.createBin(name);
}

function HO_getExt(filename) {
    if (!filename) return "";
    var idx = filename.lastIndexOf(".");
    if (idx >= 0 && idx < filename.length - 1) {
        return filename.slice(idx + 1).toUpperCase();
    }
    return "";
}

// Recolecta TODOS los items no-bin del proyecto, recursivamente.
function HO_collectAllItems(folder, out) {
    if (!out) out = [];
    for (var i = 0; i < folder.children.numItems; i++) {
        var ch = folder.children[i];
        if (ch.type === ProjectItemType.BIN) {
            HO_collectAllItems(ch, out);
        } else {
            out.push(ch);
        }
    }
    return out;
}

// Borra recursivamente bins vacíos (post-orden). No toca el root.
function HO_deleteEmptyBins(folder, log) {
    var kids = [];
    for (var i = 0; i < folder.children.numItems; i++) {
        kids.push(folder.children[i]);
    }
    var removed = 0;
    for (var k = 0; k < kids.length; k++) {
        var ch = kids[k];
        if (ch.type !== ProjectItemType.BIN) continue;

        removed += HO_deleteEmptyBins(ch, log);

        if (ch.children.numItems === 0) {
            var nm = "";
            try { nm = ch.name; } catch (e) {}
            try {
                ch.deleteBin();
                removed++;
                if (log) log.push("DEL bin vacio: " + nm);
            } catch (e2) {
                if (log) log.push("ERR borrando " + nm + ": " + e2.toString());
            }
        }
    }
    return removed;
}

/**
 * Organiza el panel de proyecto en la estructura Secuencias / Footage / Assets.
 * masterKeyword: palabra que marca una secuencia como "Master" (default "master").
 * Idempotente: correrla N veces converge a la misma estructura.
 */
function HybridOrganizer_organizeProject(masterKeyword) {
    var log   = [];
    var moved = 0;
    var errs  = 0;
    var keyword = (masterKeyword && masterKeyword !== "") ? ("" + masterKeyword).toLowerCase() : "master";

    try {
        var project = app.project;
        if (!project) {
            return JSON.stringify({ status: "ERROR", message: "No hay proyecto abierto" });
        }
        var root = project.rootItem;

        // 1. Mapa de secuencias { nombre -> "master" | "anidada" }
        var seqMap = {};
        var numSeqs = project.sequences.numSequences;
        log.push("Secuencias encontradas: " + numSeqs);
        for (var s = 0; s < numSeqs; s++) {
            var seq = project.sequences[s];
            var isMaster = (seq.name.toLowerCase().indexOf(keyword) !== -1);
            seqMap[seq.name] = isMaster ? "master" : "anidada";
        }

        // 2. Snapshot recursivo de TODOS los items no-bin.
        var items = HO_collectAllItems(root, []);
        log.push("Items a procesar: " + items.length);

        // 3. Crear/obtener bins canónicos.
        var secBin  = HO_getOrCreateChildBin(root,   "Secuencias");
        var mstBin  = HO_getOrCreateChildBin(secBin, "Master");
        var anisBin = HO_getOrCreateChildBin(secBin, "Anidadas");
        var ftgBin  = HO_getOrCreateChildBin(root,   "Footage");
        var astBin  = HO_getOrCreateChildBin(root,   "Assets");

        // 4. Clasificar y mover cada item.
        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            var name = "";
            try { name = item.name; } catch (eN) { errs++; continue; }

            try {
                // ¿Secuencia?
                if (typeof seqMap[name] !== "undefined") {
                    var isM = (seqMap[name] === "master");
                    item.moveBin(isM ? mstBin : anisBin);
                    moved++;
                    continue;
                }

                // ¿Tiene archivo? -> Footage/<EXT>
                var mediaPath = "";
                try { mediaPath = item.getMediaPath(); } catch (eM) { mediaPath = ""; }

                if (mediaPath && mediaPath.length > 1) {
                    var ext = HO_getExt(name) || HO_getExt(mediaPath) || "OTROS";
                    var extBin = HO_getOrCreateChildBin(ftgBin, ext);
                    item.moveBin(extBin);
                    moved++;
                    continue;
                }

                // Item sintético (capa de ajuste, color matte) -> Assets
                item.moveBin(astBin);
                moved++;

            } catch (moveErr) {
                errs++;
                log.push("ERR [" + name + "]: " + moveErr.toString());
            }
        }

        // 5. Limpieza de bins vacíos.
        var deleted = HO_deleteEmptyBins(root, log);
        log.push("Bins vacios eliminados: " + deleted);

        return JSON.stringify({
            status:  "OK",
            moved:   moved,
            deleted: deleted,
            errors:  errs,
            log:     log.join("\n")
        });

    } catch (e) {
        return JSON.stringify({
            status:  "ERROR",
            message: e.toString(),
            log:     log.join("\n")
        });
    }
}
