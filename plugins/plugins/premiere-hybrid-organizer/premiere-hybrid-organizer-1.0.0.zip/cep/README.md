# PR Hybrid Organizer — Extensión CEP para Adobe Premiere Pro

Híbrido de **PR Organizer** + **Premiere File Manager**.

En un solo panel:

1. **Organiza el panel de proyecto** (como PR Organizer) en una estructura limpia:
   `Secuencias/Master`, `Secuencias/Anidadas`, `Footage/<EXT>`, `Assets`.
2. **Consolida los medios en la carpeta del proyecto** (como Premiere File Manager),
   guardándolos **con esa misma organización** en disco
   (`…/Footage/MP4/…`, `…/Footage/MOV/…`, etc.).
3. Aplica tu regla de oro:
   - Lo que está en **Descargas** → se **MUEVE** (se borra el original).
   - Lo que está en **cualquier otra carpeta** → se **COPIA** (se preserva el original,
     para no perder tus **plantillas**).

---

## 🧠 Cómo decide MOVER o COPIAR

- Un archivo se **MUEVE** si su ruta pasa por una carpeta llamada `Downloads` o `Descargas`,
  o si está dentro de la carpeta Descargas del sistema (detectada automáticamente),
  o si está dentro de alguna carpeta/ruta que agregues en **Configuración → "Carpetas que se MUEVEN"**.
- Cualquier otro archivo se **COPIA** (tu original queda intacto).

> Un archivo solo se borra de su origen cuando ya se copió **y verificó** en el destino,
> **y** se re-enlazó correctamente en Premiere. Si algo falla, no se borra nada.

---

## 📁 Estructura que crea

```
TU_CARPETA_DE_PROYECTO/
├─ Footage/
│   ├─ MP4/   ← clips .mp4 consolidados
│   ├─ MOV/
│   ├─ WAV/
│   └─ …      ← un subfolder por extensión
└─ (las secuencias y Assets viven solo en el panel; no generan archivos en disco)
```

En el **panel de proyecto** de Premiere verás:

```
Secuencias/
  ├─ Master/      ← secuencias con "master" en el nombre
  └─ Anidadas/
Footage/
  └─ MP4 · MOV · WAV · …
Assets/           ← capas de ajuste, color mattes, ítems sintéticos
```

---

## 🛠 Instalación

### 1) Habilitar extensiones sin firmar (solo una vez)

**macOS** (Terminal):
```bash
defaults write com.adobe.CSXS.11 PlayerDebugMode 1
defaults write com.adobe.CSXS.12 PlayerDebugMode 1
```

**Windows** (Editor del Registro `regedit`):
```
HKEY_CURRENT_USER\Software\Adobe\CSXS.11
  → Nuevo valor de cadena: PlayerDebugMode = 1
HKEY_CURRENT_USER\Software\Adobe\CSXS.12
  → Nuevo valor de cadena: PlayerDebugMode = 1
```

### 2) Copiar la carpeta `PremiereHybridOrganizer`

| Sistema | Ruta |
|---------|------|
| **macOS** | `~/Library/Application Support/Adobe/CEP/extensions/` |
| **Windows** | `%APPDATA%\Adobe\CEP\extensions\` |

### 3) Reiniciar Premiere Pro y abrir el panel

`Ventana → Extensiones → PR Hybrid Organizer`

---

## 🚀 Uso

1. Abre y **guarda** tu proyecto (la consolidación necesita saber dónde está el `.prproj`).
2. (Opcional) Abre **Configuración ⚙️** y ajusta la carpeta raíz, niveles, carpetas a mover/excluir.
3. Pulsa **🔍 Analizar**:
   - Reordena el panel (si la opción está activa).
   - Lista los archivos externos con su etiqueta **MOVER** / **COPIAR** y su destino.
4. Revisa/desmarca lo que quieras y pulsa **⬇ Consolidar seleccionados**.
5. Listo: los archivos quedan dentro del proyecto, re-enlazados, y los de Descargas se eliminan de origen.

> ¿Solo quieres ordenar los bins sin tocar archivos? Usa **✦ Solo organizar panel**.

---

## ⚙️ Configuración

- **Niveles arriba desde el archivo del proyecto**: `0` = misma carpeta del `.prproj`,
  `1` = carpeta padre, etc. Define dónde se crea `Footage/…`.
- **Carpeta raíz del proyecto (opcional)**: fuerza una raíz concreta en vez de la detección automática.
- **Palabra "Master"**: qué texto en el nombre de una secuencia la manda a `Secuencias/Master` (por defecto `master`).
- **Carpetas que se MUEVEN**: una por línea. Puede ser una **ruta completa**
  (`D:\Capturas`, `/Volumes/SD/DCIM`) o solo un **nombre** de carpeta (`render_temp`).
  `Downloads` y `Descargas` ya están incluidas siempre.
- **Bins excluidos de la consolidación**: clips dentro de esos bins no se copian ni mueven
  (útil para bins de plantillas que prefieres dejar enlazados en su sitio).
- **Re-enlazar automáticamente**: tras consolidar, apunta los clips de Premiere a la nueva ruta.
  Si lo desactivas, los archivos de Descargas se **copiarán** (no se borran) para no dejar medios offline.
- **Organizar el panel al analizar**: ejecuta la organización de bins cada vez que pulsas Analizar.

---

## ℹ️ Notas técnicas

- La consolidación usa copia por streaming con verificación de tamaño y reintentos,
  pensada también para discos de red / NAS.
- Solo se consolidan los archivos **externos** (fuera de la carpeta del proyecto).
  Lo que ya vive dentro del proyecto se deja como está.
- Los clips **sin conexión** (cuyo archivo de origen ya no existe en disco) **no** aparecen
  como consolidables: no hay nada que mover ni copiar. Se listan aparte como `OFFLINE`
  para que los re-enlaces o los quites del proyecto en Premiere.
- La organización de bins es **idempotente**: puedes correrla las veces que quieras.
- Las **capas de ajuste** y **color mattes** no tienen archivo, por eso van a `Assets` y no se consolidan.
- Compatible con Premiere Pro 2022 en adelante. Si tu versión es anterior y no carga el panel,
  edita `CSXS/manifest.xml` y baja el rango `<Host Name="PPRO" Version="[22.0,99.9]"/>`
  (por ejemplo a `[15.0,99.9]`).

---

## 🔧 Personalización rápida

- Criterio de "Master": ajústalo desde Configuración o edita `HybridOrganizer_organizeProject` en `host/index.jsx`.
- Regla mover/copiar: lógica en `fm_isMoveSource` dentro de `client/js/fileOperations.js`.
