(function (global) {
  function CSInterface() {}
  CSInterface.prototype.evalScript = function (script, callback) {
    if (global.__adobe_cep__) global.__adobe_cep__.evalScript(script, callback || function () {});
  };
  CSInterface.prototype.getHostEnvironment = function () {
    try { return JSON.parse(global.__adobe_cep__.getHostEnvironment()); } catch (_) { return {}; }
  };
  global.CSInterface = CSInterface;
}(this));
